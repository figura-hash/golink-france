---
name: App.tsx duplicate blocks
description: Como reconhecer e tratar cópias completas concatenadas antes de corrigir declarações duplicadas isoladas.
---

Quando um arquivo React/TypeScript acusa uma declaração duplicada em um ponto inesperado, verificar primeiro se cópias completas do módulo foram concatenadas; corrigir a unidade duplicada preserva a primeira implementação e evita alterações funcionais acidentais.

**Why:** Declarações repetidas de tipos, clientes e roteadores podem ser apenas sintomas de módulos inteiros repetidos, e corrigir somente o primeiro símbolo não resolve o parser.

**How to apply:** Usar busca por símbolos e por limites de módulo, comparar os blocos antes de editar e validar com typecheck e preview após remover ou neutralizar as cópias extras.