import {
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
  useState,
} from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  House,
  Info,
  MapPin,
  MessageCircle,
  Menu,
  Package,
  Plus,
  Route as RouteIcon,
  ShieldCheck,
  Sparkles,
  Truck,
  UserRound,
  X,
} from "lucide-react";
import {
  Link,
  Route,
  Switch,
  Router as WouterRouter,
  useLocation,
} from "wouter";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

type Shipment = {
  id: string;
  reference: string;
  customerName: string;
  customerCompany: string;
  senderAddress: string;
  senderCity: string;
  senderPostalCode: string;
  receiverAddress: string;
  receiverCity: string;
  receiverPostalCode: string;
  date: string;
  pickupDate: string;
  deliveryDate: string;
  goodsType: string;
  weight: string;
  packageCount: string;
  vehicleType: string;
  offeredPrice: string;
  photos: ShipmentPhoto[];
  status: ShipmentStatus;
  transporterName?: string;
  transporterCompany?: string;
};

type ShipmentPhoto = {
  id: string;
  name: string;
  url: string;
};

type Proposal = {
  id: string;
  shipmentId: string;
  transporterName: string;
  transporterCompany: string;
  price: string;
  message: string;
  status: ProposalStatus;
};

type ShipmentStatus =
  | "Recherche de transporteur"
  | "Transporteur confirmé"
  | "En collecte"
  | "En transit"
  | "Livré";
type ProposalStatus = "En attente" | "Acceptée" | "Refusée";

const starterShipment: Shipment = {
  id: "shipment-starter-047",
  reference: "GL-240618-047",
  customerName: "Claire Renaud",
  customerCompany: "Atelier Rivoli",
  senderAddress: "18 rue de Charonne",
  senderCity: "Paris 11e",
  senderPostalCode: "75011",
  receiverAddress: "7 rue Mercière",
  receiverCity: "Lyon 2e",
  receiverPostalCode: "69002",
  date: "18 juin 2024",
  pickupDate: "18 juin 2024",
  deliveryDate: "19 juin 2024",
  goodsType: "Mobilier professionnel",
  weight: "180 kg",
  packageCount: "3",
  vehicleType: "Fourgon",
  offeredPrice: "420",
  photos: [],
  status: "Recherche de transporteur",
};

function createId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function BrandMark({ dark = false }: { dark?: boolean }) {
  return (
    <Link
      href="/"
      className="focus-ring inline-flex items-center gap-3"
      data-testid="link-brand-home"
    >
      <span
        className={`relative grid h-10 w-10 place-items-center rounded-xl ${dark ? "bg-[#f4a261] text-[#14263a]" : "bg-[#17344f] text-[#f8f4ea]"}`}
      >
        <span className="absolute left-[9px] top-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span className="absolute bottom-[9px] right-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span
          className={`absolute h-[2px] w-5 rotate-45 ${dark ? "bg-[#14263a]" : "bg-[#f4a261]"}`}
        />
      </span>
      <span
        className={`display-font text-[1.45rem] font-bold tracking-[-.05em] ${dark ? "text-[#f8f4ea]" : "text-[#17344f]"}`}
      >
        GoLink <span className="text-[#df8550]">France</span>
      </span>
    </Link>
  );
}

function IconButton({
  label,
  children,
  onClick,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white/70 text-[#526579] transition hover:border-[#9cbbba] hover:bg-[#e7f0ee] hover:text-[#17344f]"
      data-testid={`button-${label.toLowerCase().replaceAll(" ", "-")}`}
    >
      {children}
    </button>
  );
}

function StatusBadge({
  children,
  tone = "teal",
}: {
  children: ReactNode;
  tone?: "teal" | "orange" | "muted";
}) {
  const classes =
    tone === "orange"
      ? "bg-[#fff0e5] text-[#a9582d]"
      : tone === "muted"
        ? "bg-[#eef0ef] text-[#63727e]"
        : "bg-[#e3f0ed] text-[#28645e]";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${classes}`}
      data-testid="status-badge"
    >
      {tone === "teal" ? (
        <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />
      ) : null}
      {children}
    </span>
  );
}

function formatEuro(value: string) {
  return value.includes("€") ? value : `${value} €`;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTransporter = location.startsWith("/transporteur/");
  const isDashboard =
    isTransporter ||
    [
      "/tableau-de-bord",
      "/mes-expeditions",
      "/nouvelle-expedition",
      "/expedition-publiee",
      "/messages",
      "/profil",
    ].includes(location);
  if (!isDashboard) return <>{children}</>;

  const nav = isTransporter
    ? [
        {
          href: "/transporteur/tableau-de-bord",
          label: "Accueil",
          icon: House,
        },
        { href: "/transporteur/cargaisons", label: "Cargaisons", icon: Box },
        {
          href: "/transporteur/mes-transports",
          label: "Mes transports",
          icon: Truck,
        },
        {
          href: "/transporteur/messages",
          label: "Messages",
          icon: MessageCircle,
        },
        { href: "/transporteur/profil", label: "Profil", icon: UserRound },
      ]
    : [
        { href: "/tableau-de-bord", label: "Accueil", icon: House },
        { href: "/mes-expeditions", label: "Mes expéditions", icon: Package },
        {
          href: "/nouvelle-expedition",
          label: "Créer une expédition",
          icon: Plus,
        },
        { href: "/messages", label: "Messages", icon: MessageCircle },
        { href: "/profil", label: "Profil", icon: UserRound },
      ];
  const sectionTitle = isTransporter
    ? location === "/transporteur/cargaison"
      ? "Détail de la cargaison"
      : location === "/transporteur/proposition"
        ? "Faire une proposition"
        : location === "/transporteur/proposition-envoyee"
          ? "Proposition envoyée"
          : (nav.find((item) => item.href === location)?.label ?? "Accueil")
    : location === "/nouvelle-expedition"
      ? "Créer une expédition"
      : location === "/expedition-publiee"
        ? "Expédition publiée"
        : (nav.find((item) => item.href === location)?.label ?? "Accueil");

  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[250px] flex-col bg-[#17344f] px-5 py-6 text-[#f7f5ef] lg:flex">
        <BrandMark dark />
        <div className="mt-12">
          <p className="mono-font mb-4 px-3 text-[10px] uppercase tracking-[.16em] text-[#96b5b5]">
            {isTransporter ? "Espace transporteur" : "Espace client"}
          </p>
          <nav className="space-y-1.5">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition ${active ? "bg-[#e0efeb] text-[#17344f]" : "text-[#b9c9c9] hover:bg-[#25445f] hover:text-white"}`}
                  data-testid={`link-nav-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  <Icon size={17} strokeWidth={active ? 2.5 : 1.8} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.07] p-4">
          <ShieldCheck size={19} className="text-[#8bc2b6]" />
          <p className="mt-3 text-sm font-bold">
            {isTransporter
              ? "Des trajets bien choisis."
              : "Vos envois, bien cadrés."}
          </p>
          <p className="mt-1 text-xs leading-5 text-[#a8bcbc]">
            {isTransporter
              ? "Trouvez les cargaisons qui correspondent à votre activité."
              : "Chaque étape est documentée et visible par votre équipe."}
          </p>
        </div>
        <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-5">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#f4a261] text-xs font-extrabold text-[#17344f]">
            {isTransporter ? "TM" : "CR"}
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-bold">
              {isTransporter ? "Thomas Martin" : "Claire Renaud"}
            </p>
            <p className="truncate text-[11px] text-[#a8bcbc]">
              {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
            </p>
          </div>
          <ChevronDown size={14} className="ml-auto text-[#a8bcbc]" />
        </div>
      </aside>

      <div className="lg:pl-[250px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#e1e3de] bg-[#f7f5ef]/90 px-5 backdrop-blur-md sm:px-8">
          <div className="flex items-center gap-3">
            <button
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white text-[#17344f] lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Ouvrir le menu"
              data-testid="button-open-menu"
            >
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
            <div className="lg:hidden">
              <BrandMark />
            </div>
            <span className="hidden text-sm text-[#7b8a92] sm:block">
              {sectionTitle}
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <IconButton label="Aide">
              <CircleHelp size={18} />
            </IconButton>
            <IconButton label="Notifications">
              <Bell size={18} />
            </IconButton>
            <span className="hidden h-6 w-px bg-[#d8dfdf] sm:block" />
            <span className="grid h-9 w-9 place-items-center rounded-full bg-[#d8e9e6] text-xs font-extrabold text-[#28645e] sm:hidden">
              {isTransporter ? "TM" : "CR"}
            </span>
            <span className="hidden text-right sm:block">
              <span className="block text-xs font-bold">
                {isTransporter ? "Thomas Martin" : "Claire Renaud"}
              </span>
              <span className="block text-[11px] text-[#819099]">
                {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
              </span>
            </span>
          </div>
        </header>
        {mobileOpen ? (
          <div className="fixed inset-x-0 top-[76px] z-20 border-b border-[#dfe5e1] bg-[#f7f5ef] p-4 shadow-lg lg:hidden">
            <nav className="grid gap-2">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="focus-ring rounded-xl bg-white px-4 py-3 text-sm font-bold text-[#17344f]"
                  data-testid={`link-mobile-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        ) : null}
        <main>{children}</main>
      </div>
    </div>
  );
}

function RouteDiagram() {
  return (
    <div className="relative h-[310px] overflow-hidden rounded-[2rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:h-[360px] sm:p-10">
      <div className="absolute inset-0 opacity-20 page-grid" />
      <div className="absolute -right-20 -top-16 h-64 w-64 rounded-full border border-[#9cc6bd]/30" />
      <div className="absolute -right-8 top-0 h-48 w-48 rounded-full border border-[#9cc6bd]/20" />
      <div className="absolute bottom-8 left-1/2 h-[1px] w-[72%] -translate-x-1/2 rotate-[22deg] bg-[#f4a261]/60 sm:w-[66%]" />
      <div className="absolute bottom-[102px] left-[21%] h-3 w-3 rounded-full bg-[#f4a261] ring-8 ring-[#f4a261]/15 sm:left-[24%]" />
      <div className="absolute right-[18%] top-[88px] h-3 w-3 rounded-full bg-[#9cc6bd] ring-8 ring-[#9cc6bd]/15 sm:right-[23%]" />
      <div className="absolute bottom-[64px] left-[17%] sm:left-[20%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Départ
        </p>
        <p className="mt-1 text-sm font-bold">Paris 11e</p>
      </div>
      <div className="absolute right-[10%] top-[48px] text-right sm:right-[15%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Arrivée
        </p>
        <p className="mt-1 text-sm font-bold">Lyon 2e</p>
      </div>
      <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between sm:bottom-8 sm:left-10 sm:right-10">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Distance estimée
          </p>
          <p className="display-font mt-1 text-2xl font-bold">465 km</p>
        </div>
        <Truck
          className="route-pulse text-[#f4a261]"
          size={34}
          strokeWidth={1.3}
        />
        <div className="text-right">
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Délai cible
          </p>
          <p className="display-font mt-1 text-2xl font-bold">J + 1</p>
        </div>
      </div>
    </div>
  );
}

function WelcomePage() {
  return (
    <div className="noise-overlay min-h-[100dvh] overflow-hidden bg-[#f7f5ef] text-[#17344f]">
      <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <span className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
          Le transport, côté confiance
        </span>
      </header>
      <main>
        <section className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 pb-20 pt-10 sm:px-8 md:grid-cols-[1.03fr_.97fr] md:gap-10 md:pb-28 md:pt-20">
          <div className="relative z-10">
            <div
              className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.11em] text-[#28645e]"
              data-testid="status-hero"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />{" "}
              Transport professionnel, simplement
            </div>
            <h1 className="display-font animate-rise animate-rise-delay-1 mt-7 max-w-[660px] text-[3.45rem] font-bold leading-[.98] tracking-[-.065em] text-[#17344f] sm:text-[5.2rem] lg:text-[6.1rem]">
              Votre colis.
              <br />
              <span className="text-[#df8550]">Notre trajet.</span>
            </h1>
            <p className="animate-rise animate-rise-delay-2 mt-7 max-w-[500px] text-base leading-7 text-[#5d707a] sm:text-lg">
              GoLink France coordonne vos expéditions avec des transporteurs
              vérifiés, pour que chaque livraison avance avec clarté.
            </p>
            <div className="animate-rise animate-rise-delay-3 mt-9 grid gap-3 sm:grid-cols-2">
              <Link
                href="/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl bg-[#df8550] px-4 py-4 text-left text-[#17344f] shadow-[0_12px_26px_rgba(223,133,80,.22)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
                data-testid="link-choix-expediteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  📦
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je veux expédier
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#5d4b3d]">
                    Je cherche un transporteur
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="transition group-hover:translate-x-1"
                />
              </Link>
              <Link
                href="/transporteur/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl border border-[#cad8d5] bg-white/70 px-4 py-4 text-left text-[#17344f] transition hover:-translate-y-0.5 hover:border-[#9abdb4] hover:bg-[#e8f1ed]"
                data-testid="link-choix-transporteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  🚛
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je suis transporteur
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#71828a]">
                    Je cherche des cargaisons
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="text-[#28645e] transition group-hover:translate-x-1"
                />
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap items-center gap-x-7 gap-y-3 text-xs font-semibold text-[#71828a]">
              <span className="flex items-center gap-2">
                <BadgeCheck size={16} className="text-[#4f9e91]" />{" "}
                Transporteurs vérifiés
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#4f9e91]" /> Suivi à
                chaque étape
              </span>
            </div>
          </div>
          <div className="animate-rise animate-rise-delay-2 relative md:pl-6">
            <div className="absolute -right-8 -top-7 hidden h-36 w-36 rounded-full border border-[#d2a17f]/50 md:block" />
            <RouteDiagram />
            <div className="card-shadow absolute -bottom-7 left-5 flex w-[calc(100%-40px)] items-center gap-3 rounded-2xl border border-[#e1e9e5] bg-white p-4 sm:left-10 sm:w-auto sm:min-w-[290px]">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e3f0ed] text-[#28645e]">
                <Check size={20} strokeWidth={2.5} />
              </span>
              <div>
                <p className="text-xs font-extrabold text-[#17344f]">
                  Une livraison qui se précise
                </p>
                <p className="mt-1 text-[11px] text-[#819099]">
                  Notification envoyée au destinataire
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="border-y border-[#e1e3de] bg-[#eef2ec]">
          <div className="mx-auto grid max-w-[1240px] gap-8 px-5 py-14 sm:px-8 md:grid-cols-[.85fr_1.15fr] md:items-center md:gap-16 md:py-20">
            <div>
              <p className="mono-font text-[10px] font-medium uppercase tracking-[.16em] text-[#6b8f8a]">
                Pensé pour le terrain
              </p>
              <h2 className="display-font mt-4 text-3xl font-bold tracking-[-.04em] text-[#17344f] sm:text-4xl">
                La logistique, sans la zone grise.
              </h2>
            </div>
            <div className="grid gap-7 sm:grid-cols-3">
              <div>
                <span className="mono-font text-2xl text-[#df8550]">01</span>
                <h3 className="mt-3 text-sm font-extrabold">Décrivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Votre besoin est cadré en quelques minutes.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">02</span>
                <h3 className="mt-3 text-sm font-extrabold">Choisissez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Des professionnels adaptés à votre trajet.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">03</span>
                <h3 className="mt-3 text-sm font-extrabold">Suivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Une livraison documentée, jusqu’à la remise.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="mx-auto flex max-w-[1240px] flex-col justify-between gap-6 px-5 py-14 sm:flex-row sm:items-center sm:px-8 sm:py-16">
          <div>
            <p className="display-font text-xl font-bold tracking-[-.03em]">
              Une route plus lisible commence ici.
            </p>
            <p className="mt-2 text-sm text-[#71828a]">
              Expédiez ou transportez avec un espace conçu pour votre activité.
            </p>
          </div>
        </section>
      </main>
      <footer className="border-t border-[#e1e3de] px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-3 text-xs text-[#819099] sm:flex-row">
          <span>© 2024 GoLink France</span>
          <span>Le transport, côté confiance.</span>
        </div>
      </footer>
    </div>
  );
}

function ProfilePage() {
  const [hovered, setHovered] = useState<string | null>(null);
  const profiles = [
    {
      id: "client",
      href: "/tableau-de-bord",
      icon: Package,
      eyebrow: "Pour vos marchandises",
      title: "Je veux expédier",
      text: "Je cherche un transporteur",
      action: "Accéder à mon espace",
    },
    {
      id: "transporter",
      href: "/transporteur/tableau-de-bord",
      icon: Truck,
      eyebrow: "Pour votre activité",
      title: "Je suis transporteur",
      text: "Je cherche des cargaisons",
      action: "Accéder à mon espace",
    },
  ];
  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <header className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <Link
          href="/"
          className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-[#687a82] transition hover:text-[#17344f]"
          data-testid="link-retour-accueil"
        >
          <ArrowLeft size={15} /> Retour à l’accueil
        </Link>
      </header>
      <main className="mx-auto max-w-[1000px] px-5 pb-16 pt-12 sm:px-8 sm:pt-20">
        <div className="mx-auto max-w-[650px] text-center">
          <span className="mono-font text-[10px] uppercase tracking-[.16em] text-[#6b8f8a]">
            Première étape
          </span>
          <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.055em] sm:text-6xl">
            Par où commence-t-on ?
          </h1>
          <p className="mt-5 text-base leading-7 text-[#6e7d83]">
            Choisissez votre parcours. GoLink France s’adapte à votre façon de
            travailler.
          </p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {profiles.map((profile) => {
            const Icon = profile.icon;
            const active = hovered === profile.id;
            return (
              <Link
                key={profile.id}
                href={profile.href}
                onMouseEnter={() => setHovered(profile.id)}
                onMouseLeave={() => setHovered(null)}
                className={`focus-ring group relative overflow-hidden rounded-[1.6rem] border p-7 transition duration-300 sm:p-9 ${active ? "border-[#6da99d] bg-[#e7f1ed] shadow-[0_18px_44px_rgba(40,100,94,.12)]" : "border-[#dbe3de] bg-white hover:border-[#a6c8c0]"}`}
                data-testid={`link-profil-${profile.id}`}
              >
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl transition ${active ? "bg-[#17344f] text-[#f4a261]" : "bg-[#e7f1ed] text-[#28645e]"}`}
                >
                  <Icon size={26} strokeWidth={1.8} />
                </span>
                <p className="mono-font mt-10 text-[10px] uppercase tracking-[.15em] text-[#6b8f8a]">
                  {profile.eyebrow}
                </p>
                <h2 className="display-font mt-3 text-2xl font-bold tracking-[-.035em] sm:text-3xl">
                  {profile.title}
                </h2>
                <p className="mt-4 max-w-[380px] text-sm leading-6 text-[#6e7d83]">
                  {profile.text}
                </p>
                <span className="mt-8 inline-flex items-center gap-2 text-sm font-extrabold text-[#28645e]">
                  {profile.action}
                  <ArrowRight
                    size={16}
                    className={`transition ${active ? "translate-x-1" : ""}`}
                  />
                </span>
                <span className="absolute -bottom-12 -right-10 h-32 w-32 rounded-full border border-[#b6d4cd]" />
              </Link>
            );
          })}
        </div>
        <div className="mx-auto mt-12 flex max-w-[560px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4 text-left">
          <Info size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
          <p className="text-xs leading-5 text-[#71828a]">
            Chaque choix ouvre un espace dédié à votre activité. Ce prototype ne
            demande aucune inscription.
          </p>
        </div>
      </main>
    </div>
  );
}

function DashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Mardi 18 juin 2024 · Paris
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Claire<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Voici où en sont vos expéditions.
          </p>
        </div>
        <Link
          href="/nouvelle-expedition"
          className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#df8550] px-4 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_9px_20px_rgba(223,133,80,.18)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
          data-testid="link-nouvelle-expedition"
        >
          <Plus size={18} /> Nouvelle expédition
        </Link>
      </div>
      <div className="animate-rise animate-rise-delay-1 mt-9 grid gap-4 sm:grid-cols-3">
        {[
          {
            label: "En cours",
            value: "03",
            note: "dont 1 à confirmer",
            accent: "teal",
          },
          {
            label: "Livrées ce mois",
            value: "12",
            note: "+ 3 vs. mai",
            accent: "orange",
          },
          {
            label: "Délai moyen",
            value: "1,4 j",
            note: "sur les 30 derniers jours",
            accent: "navy",
          },
        ].map((metric) => (
          <div
            key={metric.label}
            className="card-shadow rounded-2xl border border-[#e0e5e0] bg-white p-5"
          >
            <div className="flex items-start justify-between">
              <p className="text-xs font-bold text-[#71828a]">{metric.label}</p>
              <span
                className={`h-2 w-2 rounded-full ${metric.accent === "orange" ? "bg-[#df8550]" : metric.accent === "navy" ? "bg-[#17344f]" : "bg-[#6da99d]"}`}
              />
            </div>
            <p className="display-font mt-4 text-3xl font-bold tracking-[-.05em]">
              {metric.value}
            </p>
            <p className="mt-2 text-[11px] text-[#8a9699]">{metric.note}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <section className="animate-rise animate-rise-delay-2 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                À suivre
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Vos expéditions
              </h2>
            </div>
            <button
              className="focus-ring text-xs font-bold text-[#28645e] hover:underline"
              onClick={() =>
                window.alert(
                  "Dans la version complète, cette vue affiche tout l’historique.",
                )
              }
              data-testid="button-voir-tout"
            >
              Voir tout
            </button>
          </div>
          <div className="mt-7 divide-y divide-[#edf0eb]">
            {[
              {
                ref: shipment.reference,
                route: `${shipment.senderCity} → ${shipment.receiverCity}`,
                desc: shipment.goodsType,
                status: "Recherche en cours",
                tone: "orange" as const,
                date: "Créée il y a 12 min",
              },
              {
                ref: "GL-240616-038",
                route: "Boulogne → Lille",
                desc: "Pièces détachées · 420 kg",
                status: "Transport confirmé",
                tone: "teal" as const,
                date: "Livraison demain",
              },
              {
                ref: "GL-240612-021",
                route: "Nantes → Bordeaux",
                desc: "Mobilier · 2,1 m³",
                status: "Livrée",
                tone: "muted" as const,
                date: "12 juin 2024",
              },
            ].map((item, index) => (
              <div
                key={item.ref}
                className="group flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
                data-testid={`row-expedition-${index}`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${index === 0 ? "bg-[#fff0e5] text-[#b7683c]" : "bg-[#e8f0ed] text-[#477d75]"}`}
                  >
                    <RouteIcon size={17} />
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold">{item.route}</p>
                      <StatusBadge tone={item.tone}>{item.status}</StatusBadge>
                    </div>
                    <p className="mt-1 text-xs text-[#8a9699]">
                      {item.ref} · {item.desc}
                    </p>
                  </div>
                </div>
                <p className="pl-12 text-[11px] font-semibold text-[#8a9699] sm:pl-0">
                  {item.date}
                </p>
              </div>
            ))}
          </div>
        </section>
        <section className="animate-rise animate-rise-delay-3 rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
                Votre activité
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Ce mois-ci
              </h2>
            </div>
            <Sparkles size={19} className="text-[#f4a261]" />
          </div>
          <div className="mt-8 grid grid-cols-2 gap-y-7">
            <div>
              <p className="text-3xl font-bold">15</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">expéditions créées</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                98<span className="text-lg">%</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">remises à temps</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                4,8<span className="text-lg">/5</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">satisfaction</p>
            </div>
            <div>
              <p className="text-3xl font-bold">8</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">
                transporteurs utilisés
              </p>
            </div>
          </div>
          <div className="mt-9 border-t border-white/10 pt-5">
            <p className="text-xs leading-5 text-[#b5c7c4]">
              Votre réseau s’agrandit. Les trajets réguliers peuvent être
              enregistrés pour aller plus vite.
            </p>
            <button
              className="focus-ring mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#f4a261] hover:text-[#ffc08f]"
              onClick={() =>
                window.alert(
                  "Les trajets favoris seront disponibles prochainement.",
                )
              }
              data-testid="button-decouvrir-favoris"
            >
              Découvrir les favoris <ArrowRight size={14} />
            </button>
          </div>
        </section>
      </div>
      <section className="mt-7 rounded-[1.4rem] border border-[#e0e5e0] bg-[#eef3ef] p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-[#28645e]">
              <FileText size={18} />
            </span>
            <div>
              <p className="text-sm font-extrabold">
                Besoin d’un coup de main ?
              </p>
              <p className="mt-1 text-xs text-[#71828a]">
                Notre guide explique comment préparer une expédition sans oubli.
              </p>
            </div>
          </div>
          <button
            className="focus-ring w-fit rounded-lg border border-[#bfd2cb] bg-white px-3.5 py-2.5 text-xs font-bold text-[#28645e] transition hover:bg-[#e3f0ed]"
            onClick={() =>
              window.alert("Le guide de préparation est en cours de rédaction.")
            }
            data-testid="button-guide"
          >
            Lire le guide
          </button>
        </div>
      </section>
    </div>
  );
}

function WorkspaceSectionPage({
  role,
  section,
}: {
  role: "client" | "transporter";
  section: "messages" | "profil" | "mes-transports";
}) {
  const isTransporter = role === "transporter";
  const content =
    section === "messages"
      ? {
          eyebrow: "Échanges",
          title: "Messages",
          description: isTransporter
            ? "Retrouvez les échanges liés à vos propositions et à vos transports."
            : "Retrouvez les échanges liés à vos expéditions et aux transporteurs.",
        }
      : section === "profil"
        ? {
            eyebrow: "Votre espace",
            title: "Profil",
            description: isTransporter
              ? "Gérez les informations de Transport Martin."
              : "Gérez les informations de votre entreprise et vos préférences.",
          }
        : {
            eyebrow: "Votre activité",
            title: "Mes transports",
            description:
              "Retrouvez les trajets pour lesquels vous avez envoyé une proposition.",
          };
  return (
    <div className="mx-auto max-w-[980px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise max-w-[620px]">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          {content.eyebrow}
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          {content.title}
        </h1>
        <p className="mt-3 text-sm leading-6 text-[#71828a]">
          {content.description}
        </p>
      </div>
      <section className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-6 sm:p-8">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e8f0ed] text-[#28645e]">
          {section === "messages" ? (
            <MessageCircle size={22} />
          ) : section === "profil" ? (
            <UserRound size={22} />
          ) : (
            <Truck size={22} />
          )}
        </span>
        <h2 className="display-font mt-6 text-2xl font-bold tracking-[-.035em]">
          Cette vue sera bientôt disponible.
        </h2>
        <p className="mt-3 max-w-[560px] text-sm leading-6 text-[#71828a]">
          Le prototype garde votre espace{" "}
          {isTransporter ? "transporteur" : "client"} séparé. Les
          fonctionnalités principales restent accessibles depuis votre
          navigation.
        </p>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-extrabold text-[#526579]">
        {label}
        {required ? <span className="ml-1 text-[#df8550]">*</span> : null}
      </span>
      <input
        name={name}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        type={type}
        required={required}
        className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
        data-testid={`input-${name}`}
      />
    </label>
  );
}

function ShipmentPhotoPicker({
  photos,
  onAdd,
  onRemove,
}: {
  photos: ShipmentPhoto[];
  onAdd: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemove: (photoId: string) => void;
}) {
  return (
    <section
      className="mt-6 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7"
      aria-labelledby="photos-marchandise-title"
    >
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <p
            id="photos-marchandise-title"
            className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
          >
            Photos de la marchandise
          </p>
          <p className="mt-2 text-xs leading-5 text-[#819099]">
            Ajoutez plusieurs vues pour aider le transporteur à préparer son
            trajet.
          </p>
        </div>
        <label
          className="focus-ring inline-flex w-fit cursor-pointer items-center gap-2 rounded-xl border border-[#c8d8d3] bg-[#f7fbf8] px-4 py-3 text-sm font-extrabold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-ajouter-photo"
        >
          <Plus size={16} /> Ajouter une photo
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={onAdd}
            className="sr-only"
            data-testid="input-photos"
          />
        </label>
      </div>
      {photos.length ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1]"
            >
              <img
                src={photo.url}
                alt={photo.name}
                className="aspect-[4/3] w-full object-cover"
              />
              <button
                type="button"
                onClick={() => onRemove(photo.id)}
                className="focus-ring absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-[#17344f]/85 text-white opacity-100 transition hover:bg-[#17344f] sm:opacity-0 sm:group-hover:opacity-100"
                aria-label={`Supprimer ${photo.name}`}
                data-testid={`button-supprimer-photo-${photo.id}`}
              >
                <X size={15} />
              </button>
              <p className="truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                {photo.name}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-6 flex items-center gap-3 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-xs leading-5 text-[#71828a]">
          <Package size={17} className="shrink-0 text-[#6b8f8a]" /> Aucun
          fichier ajouté pour le moment.
        </div>
      )}
    </section>
  );
}

function NewShipmentPage({
  onPublish,
}: {
  onPublish: (shipment: Shipment) => void;
}) {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Shipment>({
    reference: "GL-240618-047",
    senderAddress: "",
    senderCity: "",
    senderPostalCode: "",
    receiverAddress: "",
    receiverCity: "",
    receiverPostalCode: "",
    date: "À convenir",
    goodsType: "",
    weight: "",
    packageCount: "",
    vehicleType: "",
    offeredPrice: "",
    photos: [],
  });
  const update = (key: keyof Shipment) => (value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
  };
  const addPhotos = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []).filter((file) =>
      file.type.startsWith("image/"),
    );
    if (!files.length) return;
    const newPhotos = files.map((file, index) => ({
      id: `${file.name}-${file.lastModified}-${index}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }));
    setForm((current) => ({
      ...current,
      photos: [...current.photos, ...newPhotos],
    }));
    event.target.value = "";
  };
  const removePhoto = (photoId: string) => {
    setForm((current) => {
      const photo = current.photos.find((item) => item.id === photoId);
      if (photo) URL.revokeObjectURL(photo.url);
      return {
        ...current,
        photos: current.photos.filter((item) => item.id !== photoId),
      };
    });
  };
  const nextStep = (event: FormEvent) => {
    event.preventDefault();
    if (
      !form.senderAddress ||
      !form.senderCity ||
      !form.senderPostalCode ||
      !form.receiverAddress ||
      !form.receiverCity ||
      !form.receiverPostalCode
    ) {
      setError("Renseignez toutes les informations du trajet pour continuer.");
      return;
    }
    setError("");
    setStep(2);
  };
  const submit = () => {
    if (
      !form.goodsType ||
      !form.weight ||
      !form.packageCount ||
      !form.vehicleType ||
      !form.offeredPrice
    ) {
      setError("Complétez les informations de la cargaison avant de publier.");
      return;
    }
    onPublish({
      ...form,
      weight: `${form.weight} kg`,
      offeredPrice: `${form.offeredPrice} €`,
    });
    setLocation("/expedition-publiee");
  };
  return (
    <div className="mx-auto max-w-[1020px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise">
        <Link
          href="/tableau-de-bord"
          className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
          data-testid="link-retour-dashboard"
        >
          <ArrowLeft size={14} /> Retour au tableau de bord
        </Link>
        <div className="mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              Nouvelle expédition
            </p>
            <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
              Préparons votre trajet.
            </h1>
            <p className="mt-2 text-sm text-[#71828a]">
              Décrivez votre besoin en deux étapes simples.
            </p>
          </div>
          <span className="mono-font text-xs text-[#71828a]">
            Réf. {form.reference}
          </span>
        </div>
      </div>
      <div className="mt-9 grid gap-8 lg:grid-cols-[1fr_280px]">
        <div>
          <div className="mb-7 flex items-center gap-2 sm:gap-4">
            {["Le trajet", "La cargaison"].map((label, index) => {
              const number = index + 1;
              return (
                <div
                  key={label}
                  className="flex flex-1 items-center gap-2 sm:gap-3"
                >
                  <span
                    className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-extrabold ${step >= number ? "bg-[#17344f] text-[#f7f5ef]" : "border border-[#d4dfda] bg-white text-[#9aa8aa]"}`}
                  >
                    {step > number ? <Check size={15} /> : number}
                  </span>
                  <span
                    className={`hidden text-xs font-bold sm:block ${step >= number ? "text-[#17344f]" : "text-[#9aa8aa]"}`}
                  >
                    {label}
                  </span>
                  {number < 2 ? (
                    <span
                      className={`h-px flex-1 ${step > number ? "bg-[#6da99d]" : "bg-[#dce3df]"}`}
                    />
                  ) : null}
                </div>
              );
            })}
          </div>
          <form
            onSubmit={nextStep}
            className="rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
            data-testid="form-nouvelle-expedition"
          >
            {step === 1 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
                    <RouteIcon size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">Le trajet</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Indiquez les deux points de votre expédition.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-8 md:grid-cols-2">
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de collecte
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de collecte"
                        name="adresse-collecte"
                        value={form.senderAddress}
                        onChange={update("senderAddress")}
                        placeholder="Ex. 18 rue de Charonne"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-collecte"
                        value={form.senderCity}
                        onChange={update("senderCity")}
                        placeholder="Ex. Paris"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-collecte"
                        value={form.senderPostalCode}
                        onChange={update("senderPostalCode")}
                        placeholder="Ex. 75011"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de livraison
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de livraison"
                        name="adresse-livraison"
                        value={form.receiverAddress}
                        onChange={update("receiverAddress")}
                        placeholder="Ex. 7 rue Mercière"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-livraison"
                        value={form.receiverCity}
                        onChange={update("receiverCity")}
                        placeholder="Ex. Lyon"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-livraison"
                        value={form.receiverPostalCode}
                        onChange={update("receiverPostalCode")}
                        placeholder="Ex. 69002"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
            {step === 2 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
                    <Box size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">La cargaison</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Donnez aux transporteurs les informations utiles pour
                      répondre.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-5 md:grid-cols-2">
                  <Field
                    label="Type de marchandise"
                    name="type-marchandise"
                    value={form.goodsType}
                    onChange={update("goodsType")}
                    placeholder="Ex. Mobilier professionnel"
                    required
                  />
                  <Field
                    label="Poids en kg"
                    name="poids"
                    value={form.weight}
                    onChange={update("weight")}
                    placeholder="Ex. 180"
                    type="number"
                    required
                  />
                  <Field
                    label="Nombre de colis"
                    name="nombre-colis"
                    value={form.packageCount}
                    onChange={update("packageCount")}
                    placeholder="Ex. 3"
                    type="number"
                    required
                  />
                  <label className="block">
                    <span className="mb-2 block text-xs font-extrabold text-[#526579]">
                      Type de véhicule
                      <span className="ml-1 text-[#df8550]">*</span>
                    </span>
                    <select
                      name="type-vehicule"
                      value={form.vehicleType}
                      onChange={(event) =>
                        update("vehicleType")(event.target.value)
                      }
                      required
                      className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition focus:border-[#6da99d] focus:bg-white"
                      data-testid="select-type-vehicule"
                    >
                      <option value="">Sélectionnez un véhicule</option>
                      <option>Fourgon</option>
                      <option>Camion porteur</option>
                      <option>Poids lourd</option>
                      <option>Véhicule avec hayon</option>
                    </select>
                  </label>
                  <Field
                    label="Prix proposé en €"
                    name="prix-propose"
                    value={form.offeredPrice}
                    onChange={update("offeredPrice")}
                    placeholder="Ex. 420"
                    type="number"
                    required
                  />
                </div>
                <div className="mt-6 flex items-start gap-2 rounded-xl bg-[#f1f5f1] p-3 text-xs leading-5 text-[#71828a]">
                  <Info size={15} className="mt-0.5 shrink-0 text-[#6b8f8a]" />{" "}
                  Votre prix proposé sera visible par les transporteurs
                  intéressés par ce trajet.
                </div>
              </div>
            ) : null}
            {error ? (
              <p
                className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
                role="alert"
                data-testid="text-form-error"
              >
                {error}
              </p>
            ) : null}
            <div className="mt-8 flex flex-col-reverse justify-between gap-3 border-t border-[#edf0eb] pt-6 sm:flex-row sm:items-center">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    setError("");
                    setStep(1);
                  }}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-bold text-[#71828a] transition hover:bg-[#f1f4f0] hover:text-[#17344f]"
                  data-testid="button-etape-precedente"
                >
                  <ArrowLeft size={16} /> Étape précédente
                </button>
              ) : (
                <span className="hidden sm:block text-xs text-[#98a4a6]">
                  * Champs obligatoires
                </span>
              )}
              {step === 1 ? (
                <button
                  type="submit"
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                  data-testid="button-continuer"
                >
                  Continuer <ArrowRight size={16} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={submit}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
                  data-testid="button-publier-cargaison"
                >
                  Publier la cargaison <ArrowRight size={16} />
                </button>
              )}
            </div>
          </form>
          {step === 2 ? (
            <ShipmentPhotoPicker
              photos={form.photos}
              onAdd={addPhotos}
              onRemove={removePhoto}
            />
          ) : null}
        </div>
        <aside className="hidden lg:block">
          <div className="sticky top-[105px] rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Bon à savoir
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Vous gardez le cap.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Votre annonce reste modifiable jusqu’à sa publication.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <MapPin size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Un trajet précis aide à obtenir des propositions adaptées.
                </p>
              </div>
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Les transporteurs voient les informations nécessaires avant de
                  répondre.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ShipmentPhotosSection({ photos }: { photos: ShipmentPhoto[] }) {
  const [selectedPhoto, setSelectedPhoto] = useState<ShipmentPhoto | null>(
    null,
  );

  return (
    <>
      <section
        className="border-t border-[#edf0eb] px-5 py-6 sm:px-7"
        aria-labelledby="photos-cargaison-title"
      >
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
            <Package size={18} />
          </span>
          <div>
            <p
              id="photos-cargaison-title"
              className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
            >
              Photos de la marchandise
            </p>
            <p className="mt-2 text-xs text-[#819099]">
              Consultez les photos ajoutées par le client avant de répondre.
            </p>
          </div>
        </div>
        {photos.length ? (
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {photos.map((photo) => (
              <button
                type="button"
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="focus-ring group overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1] text-left"
                aria-label={`Agrandir ${photo.name}`}
                data-testid={`button-agrandir-photo-${photo.id}`}
              >
                <img
                  src={photo.url}
                  alt={photo.name}
                  className="aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-[1.03]"
                />
                <span className="block truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                  {photo.name}
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div
            className="mt-5 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-sm font-semibold text-[#71828a]"
            data-testid="text-aucune-photo"
          >
            Aucune photo disponible
          </div>
        )}
      </section>
      {selectedPhoto ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#10263a]/80 p-5 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo agrandie : ${selectedPhoto.name}`}
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelectedPhoto(null);
          }}
        >
          <div className="relative max-h-[90vh] max-w-[min(900px,calc(100vw-2.5rem))] overflow-hidden rounded-2xl bg-white p-2 shadow-2xl">
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="focus-ring absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-[#17344f]/90 text-white transition hover:bg-[#17344f]"
              aria-label="Fermer la photo agrandie"
              data-testid="button-fermer-photo"
            >
              <X size={18} />
            </button>
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.name}
              className="max-h-[82vh] max-w-full rounded-xl object-contain"
            />
            <p className="px-2 pb-1 pt-2 text-xs font-semibold text-[#526579]">
              {selectedPhoto.name}
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}

function PublishedPage({ shipment }: { shipment: Shipment }) {
  const [, setLocation] = useLocation();
  return (
    <div className="mx-auto max-w-[980px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[720px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Expédition publiée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre expédition a été publiée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[540px] text-base leading-7 text-[#71828a]">
          Votre cargaison est maintenant visible par les transporteurs
          intéressés par ce trajet.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[820px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="flex flex-col justify-between gap-3 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Résumé de l’expédition
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.reference}</p>
          </div>
          <StatusBadge>Recherche de transporteur</StatusBadge>
        </div>
        <div className="grid gap-0 sm:grid-cols-[1fr_80px_1fr] sm:items-center">
          <div className="p-6 sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Collecte
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.senderCity} · {shipment.senderPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.senderAddress}
            </p>
          </div>
          <div className="hidden justify-center sm:flex">
            <div className="h-px w-10 bg-[#b9d2cc]" />
            <Truck size={18} className="mx-[-4px] text-[#df8550]" />
            <div className="h-px w-10 bg-[#b9d2cc]" />
          </div>
          <div className="border-t border-[#edf0eb] p-6 sm:border-t-0 sm:border-l sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Livraison
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.receiverCity} · {shipment.receiverPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.receiverAddress}
            </p>
          </div>
        </div>
        <div className="grid gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] p-5 sm:grid-cols-4 sm:px-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Marchandise
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.goodsType}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Poids
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.weight}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Colis
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.packageCount}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.offeredPrice}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
          <Truck size={15} className="text-[#6b8f8a]" /> Véhicule souhaité :{" "}
          <strong>{shipment.vehicleType}</strong>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[760px] gap-3 sm:grid-cols-2">
        <button
          onClick={() => setLocation("/tableau-de-bord")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-voir-tableau"
        >
          Voir mon tableau de bord <ArrowRight size={16} />
        </button>
        <button
          onClick={() => setLocation("/nouvelle-expedition")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-nouvelle-apres-publication"
        >
          <Plus size={16} /> Créer une autre expédition
        </button>
      </div>
      <div className="mx-auto mt-12 flex max-w-[600px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4">
        <Clock3 size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
        <p className="text-xs leading-5 text-[#71828a]">
          <strong className="text-[#526579]">Et maintenant ?</strong> Les
          transporteurs intéressés peuvent consulter votre annonce. Consultez
          votre tableau de bord pour suivre les réponses.
        </p>
      </div>
    </div>
  );
}

function TransporterDashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1240px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Espace transporteur · Aujourd’hui
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Thomas<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Des trajets qui correspondent à votre activité.
          </p>
        </div>
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-2 text-xs font-bold text-[#28645e]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" /> Profil
          transporteur actif
        </span>
      </div>

      <section className="animate-rise animate-rise-delay-1 mt-10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              À saisir
            </p>
            <h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em] sm:text-3xl">
              Cargaisons disponibles
            </h2>
            <p className="mt-2 max-w-[560px] text-sm leading-6 text-[#71828a]">
              Découvrez les expéditions à proximité et proposez un transport
              adapté.
            </p>
          </div>
          <span className="text-xs font-bold text-[#819099]">
            1 nouvelle cargaison
          </span>
        </div>

        <div className="mt-7 grid gap-6 xl:grid-cols-[1fr_280px]">
          <article className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
            <div className="flex flex-col justify-between gap-4 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge tone="orange">Nouvelle</StatusBadge>
                  <span className="mono-font text-[10px] tracking-[.12em] text-[#819099]">
                    {shipment.reference}
                  </span>
                </div>
                <p className="display-font mt-3 text-2xl font-bold tracking-[-.04em]">
                  {shipment.senderCity}{" "}
                  <span className="text-[#df8550]">→</span>{" "}
                  {shipment.receiverCity}
                </p>
              </div>
              <Link
                href="/transporteur/cargaison"
                className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#17344f] px-4 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                data-testid="button-voir-cargaison"
              >
                Voir la cargaison <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid gap-0 sm:grid-cols-2 lg:grid-cols-4">
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Date
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.date}</p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 lg:border-b-0 lg:border-r">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Marchandise
                </p>
                <p className="mt-2 text-sm font-extrabold">
                  {shipment.goodsType}
                </p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Poids
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.weight}</p>
              </div>
              <div className="p-5">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Prix proposé
                </p>
                <p className="mt-2 text-sm font-extrabold text-[#b7683c]">
                  {formatEuro(shipment.offeredPrice)}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
              <span className="flex items-center gap-2">
                <Truck size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.vehicleType}
              </span>
              <span className="flex items-center gap-2">
                <Box size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.packageCount} colis
              </span>
              <span className="flex items-center gap-2">
                <MapPin size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.senderPostalCode} → {shipment.receiverPostalCode}
              </span>
            </div>
          </article>

          <aside className="rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Votre activité
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Roulez utile.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Les cargaisons sont présentées avec les informations essentielles
              pour décider rapidement.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Des annonces structurées, sans détour.
                </p>
              </div>
              <div className="flex gap-3">
                <RouteIcon size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Une route claire avant de prendre la route.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function ShipmentDetailsPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1000px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/tableau-de-bord"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-cargaisons"
      >
        <ArrowLeft size={14} /> Retour aux cargaisons
      </Link>
      <div className="animate-rise mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Détail de la cargaison
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            {shipment.senderCity} <span className="text-[#df8550]">→</span>{" "}
            {shipment.receiverCity}
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Réf. {shipment.reference} · {shipment.date}
          </p>
        </div>
        <StatusBadge tone="orange">Recherche de transporteur</StatusBadge>
      </div>
      <div className="mt-9 grid gap-6 lg:grid-cols-[1fr_280px]">
        <section className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
          <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Informations du trajet
            </p>
            <p className="mt-2 text-sm font-extrabold">
              De la collecte à la livraison
            </p>
          </div>
          <div className="grid gap-0 sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de collecte
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.senderAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.senderCity} · {shipment.senderPostalCode}
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de livraison
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.receiverAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.receiverCity} · {shipment.receiverPostalCode}
              </p>
            </div>
          </div>
          <div className="grid gap-0 border-t border-[#edf0eb] sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Marchandise
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.goodsType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.weight} · {shipment.packageCount} colis
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Transport
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.vehicleType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                Date : {shipment.date}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] px-6 py-5 sm:px-7">
            <span className="text-sm font-bold text-[#526579]">
              Prix proposé par le client
            </span>
            <span className="display-font text-xl font-bold text-[#b7683c]">
              {formatEuro(shipment.offeredPrice)}
            </span>
          </div>
          <ShipmentPhotosSection photos={shipment.photos} />
        </section>
        <aside className="h-fit rounded-[1.4rem] border border-[#dfe7e2] bg-[#eef3ef] p-6">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre réponse
          </p>
          <h2 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
            Le trajet vous convient ?
          </h2>
          <p className="mt-3 text-xs leading-5 text-[#71828a]">
            Envoyez votre prix et un message au client pour vous positionner sur
            cette cargaison.
          </p>
          <Link
            href="/transporteur/proposition"
            className="focus-ring mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#df8550] px-4 py-3.5 text-sm font-extrabold text-[#17344f] transition hover:bg-[#eb9863]"
            data-testid="button-faire-proposition"
          >
            Faire une proposition <ArrowRight size={16} />
          </Link>
        </aside>
      </div>
    </div>
  );
}

function TransporterProposalPage({
  shipment,
  onSend,
}: {
  shipment: Shipment;
  onSend: (proposal: Proposal) => void;
}) {
  const [, setLocation] = useLocation();
  const [proposal, setProposal] = useState<Proposal>({
    price: "",
    message: "",
  });
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!proposal.price || !proposal.message) {
      setError("Renseignez votre prix et votre message avant d’envoyer.");
      return;
    }
    onSend({ ...proposal, price: `${proposal.price} €` });
    setLocation("/transporteur/proposition-envoyee");
  };
  return (
    <div className="mx-auto max-w-[820px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/cargaison"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-detail-cargaison"
      >
        <ArrowLeft size={14} /> Retour à la cargaison
      </Link>
      <div className="animate-rise mt-7">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Votre proposition
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          Faites avancer le trajet.
        </h1>
        <p className="mt-2 text-sm text-[#71828a]">
          {shipment.senderCity} → {shipment.receiverCity} · {shipment.goodsType}
        </p>
      </div>
      <form
        onSubmit={submit}
        className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
        data-testid="form-proposition"
      >
        <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
            <FileText size={18} />
          </span>
          <div>
            <h2 className="text-base font-extrabold">Répondez au client</h2>
            <p className="mt-1 text-xs text-[#819099]">
              Un prix clair et un message précis font la différence.
            </p>
          </div>
        </div>
        <div className="mt-7 space-y-5">
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Prix proposé par le client
            </span>
            <input
              value={formatEuro(shipment.offeredPrice)}
              readOnly
              className="h-12 w-full cursor-default rounded-xl border border-[#d8e0dc] bg-[#f1f5f1] px-3.5 text-sm font-bold text-[#71828a] outline-none"
              data-testid="input-prix-client"
            />
          </label>
          <Field
            label="Votre prix"
            name="votre-prix"
            value={proposal.price}
            onChange={(value) => {
              setProposal((current) => ({ ...current, price: value }));
              setError("");
            }}
            placeholder="Ex. 390"
            type="number"
            required
          />
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Message<span className="ml-1 text-[#df8550]">*</span>
            </span>
            <textarea
              name="message"
              value={proposal.message}
              onChange={(event) => {
                setProposal((current) => ({
                  ...current,
                  message: event.target.value,
                }));
                setError("");
              }}
              placeholder="Présentez votre disponibilité et vos conditions de transport…"
              className="focus-ring min-h-[140px] w-full resize-y rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 py-3 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
              data-testid="input-message"
            />
          </label>
        </div>
        {error ? (
          <p
            className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
            role="alert"
            data-testid="text-proposition-error"
          >
            {error}
          </p>
        ) : null}
        <div className="mt-8 flex justify-end border-t border-[#edf0eb] pt-6">
          <button
            type="submit"
            className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3.5 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
            data-testid="button-envoyer-proposition"
          >
            Envoyer la proposition <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </div>
  );
}

function ProposalSentPage({
  shipment,
  proposal,
}: {
  shipment: Shipment;
  proposal: Proposal;
}) {
  return (
    <div className="mx-auto max-w-[900px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[700px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Proposition envoyée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre proposition a été envoyée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[520px] text-base leading-7 text-[#71828a]">
          Le client pourra consulter votre offre et revenir vers vous au sujet
          de cette cargaison.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[720px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre offre
          </p>
          <p className="mt-1 text-sm font-extrabold">
            {shipment.senderCity} → {shipment.receiverCity} ·{" "}
            {shipment.reference}
          </p>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé par le client
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#71828a]">
              {formatEuro(shipment.offeredPrice)}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Votre prix
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#b7683c]">
              {proposal.price}
            </p>
          </div>
          <div className="sm:col-span-2">
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Message envoyé
            </p>
            <p className="mt-2 rounded-xl bg-[#fcfdfa] p-4 text-sm leading-6 text-[#526579]">
              {proposal.message}
            </p>
          </div>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[720px] gap-3 sm:grid-cols-2">
        <Link
          href="/transporteur/tableau-de-bord"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-retour-cargaisons"
        >
          Voir les cargaisons disponibles <ArrowRight size={16} />
        </Link>
        <Link
          href="/transporteur/cargaison"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-revoir-cargaison"
        >
          Revoir la cargaison <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}

function Router() {
  const [publishedShipment, setPublishedShipment] =
    useState<Shipment>(starterShipment);
  const [sentProposal, setSentProposal] = useState<Proposal>({
    price: "390 €",
    message:
      "Disponible pour ce trajet avec un fourgon équipé. Je peux prendre en charge les trois colis dans le créneau indiqué.",
  });
  return (
    <AppShell>
      <Switch>
        <Route path="/" component={WelcomePage} />
        <Route path="/choisir-profil" component={ProfilePage} />
        <Route path="/tableau-de-bord">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/mes-expeditions">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/nouvelle-expedition">
          <NewShipmentPage onPublish={setPublishedShipment} />
        </Route>
        <Route path="/expedition-publiee">
          <PublishedPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/tableau-de-bord">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/cargaisons">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/messages">
          <WorkspaceSectionPage role="client" section="messages" />
        </Route>
        <Route path="/profil">
          <WorkspaceSectionPage role="client" section="profil" />
        </Route>
        <Route path="/transporteur/mes-transports">
          <WorkspaceSectionPage role="transporter" section="mes-transports" />
        </Route>
        <Route path="/transporteur/messages">
          <WorkspaceSectionPage role="transporter" section="messages" />
        </Route>
        <Route path="/transporteur/profil">
          <WorkspaceSectionPage role="transporter" section="profil" />
        </Route>
        <Route path="/transporteur/cargaison">
          <ShipmentDetailsPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/proposition">
          <TransporterProposalPage
            shipment={publishedShipment}
            onSend={setSentProposal}
          />
        </Route>
        <Route path="/transporteur/proposition-envoyee">
          <ProposalSentPage
            shipment={publishedShipment}
            proposal={sentProposal}
          />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedErrorBoundary>
            <Router />
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
/*
import {
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
  useState,
} from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  House,
  Info,
  MapPin,
  MessageCircle,
  Menu,
  Package,
  Plus,
  Route as RouteIcon,
  ShieldCheck,
  Sparkles,
  Truck,
  UserRound,
  X,
} from "lucide-react";
import {
  Link,
  Route,
  Switch,
  Router as WouterRouter,
  useLocation,
} from "wouter";

type Shipment = {
  id: string;
  reference: string;
  customerName: string;
  customerCompany: string;
  senderAddress: string;
  senderCity: string;
  senderPostalCode: string;
  receiverAddress: string;
  receiverCity: string;
  receiverPostalCode: string;
  date: string;
  pickupDate: string;
  deliveryDate: string;
  goodsType: string;
  weight: string;
  packageCount: string;
  vehicleType: string;
  offeredPrice: string;
  photos: ShipmentPhoto[];
  status: ShipmentStatus;
  transporterName?: string;
  transporterCompany?: string;
};

type ShipmentPhoto = {
  id: string;
  name: string;
  url: string;
};

type Proposal = {
  id: string;
  shipmentId: string;
  transporterName: string;
  transporterCompany: string;
  price: string;
  message: string;
  status: ProposalStatus;
};

type ShipmentStatus =
  | "Recherche de transporteur"
  | "Transporteur confirmé"
  | "En collecte"
  | "En transit"
  | "Livré";
type ProposalStatus = "En attente" | "Acceptée" | "Refusée";

const starterShipment: Shipment = {
  id: "shipment-starter-047",
  reference: "GL-240618-047",
  customerName: "Claire Renaud",
  customerCompany: "Atelier Rivoli",
  senderAddress: "18 rue de Charonne",
  senderCity: "Paris 11e",
  senderPostalCode: "75011",
  receiverAddress: "7 rue Mercière",
  receiverCity: "Lyon 2e",
  receiverPostalCode: "69002",
  date: "18 juin 2024",
  pickupDate: "18 juin 2024",
  deliveryDate: "19 juin 2024",
  goodsType: "Mobilier professionnel",
  weight: "180 kg",
  packageCount: "3",
  vehicleType: "Fourgon",
  offeredPrice: "420",
  photos: [],
  status: "Recherche de transporteur",
};

function createId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function BrandMark({ dark = false }: { dark?: boolean }) {
  return (
    <Link
      href="/"
      className="focus-ring inline-flex items-center gap-3"
      data-testid="link-brand-home"
    >
      <span
        className={`relative grid h-10 w-10 place-items-center rounded-xl ${dark ? "bg-[#f4a261] text-[#14263a]" : "bg-[#17344f] text-[#f8f4ea]"}`}
      >
        <span className="absolute left-[9px] top-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span className="absolute bottom-[9px] right-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span
          className={`absolute h-[2px] w-5 rotate-45 ${dark ? "bg-[#14263a]" : "bg-[#f4a261]"}`}
        />
      </span>
      <span
        className={`display-font text-[1.45rem] font-bold tracking-[-.05em] ${dark ? "text-[#f8f4ea]" : "text-[#17344f]"}`}
      >
        GoLink <span className="text-[#df8550]">France</span>
      </span>
    </Link>
  );
}

function IconButton({
  label,
  children,
  onClick,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white/70 text-[#526579] transition hover:border-[#9cbbba] hover:bg-[#e7f0ee] hover:text-[#17344f]"
      data-testid={`button-${label.toLowerCase().replaceAll(" ", "-")}`}
    >
      {children}
    </button>
  );
}

function StatusBadge({
  children,
  tone = "teal",
}: {
  children: ReactNode;
  tone?: "teal" | "orange" | "muted";
}) {
  const classes =
    tone === "orange"
      ? "bg-[#fff0e5] text-[#a9582d]"
      : tone === "muted"
        ? "bg-[#eef0ef] text-[#63727e]"
        : "bg-[#e3f0ed] text-[#28645e]";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${classes}`}
      data-testid="status-badge"
    >
      {tone === "teal" ? (
        <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />
      ) : null}
      {children}
    </span>
  );
}

function formatEuro(value: string) {
  return value.includes("€") ? value : `${value} €`;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTransporter = location.startsWith("/transporteur/");
  const isDashboard =
    isTransporter ||
    [
      "/tableau-de-bord",
      "/mes-expeditions",
      "/nouvelle-expedition",
      "/expedition-publiee",
      "/messages",
      "/profil",
    ].includes(location);
  if (!isDashboard) return <>{children}</>;

  const nav = isTransporter
    ? [
        {
          href: "/transporteur/tableau-de-bord",
          label: "Accueil",
          icon: House,
        },
        { href: "/transporteur/cargaisons", label: "Cargaisons", icon: Box },
        {
          href: "/transporteur/mes-transports",
          label: "Mes transports",
          icon: Truck,
        },
        {
          href: "/transporteur/messages",
          label: "Messages",
          icon: MessageCircle,
        },
        { href: "/transporteur/profil", label: "Profil", icon: UserRound },
      ]
    : [
        { href: "/tableau-de-bord", label: "Accueil", icon: House },
        { href: "/mes-expeditions", label: "Mes expéditions", icon: Package },
        {
          href: "/nouvelle-expedition",
          label: "Créer une expédition",
          icon: Plus,
        },
        { href: "/messages", label: "Messages", icon: MessageCircle },
        { href: "/profil", label: "Profil", icon: UserRound },
      ];
  const sectionTitle = isTransporter
    ? location === "/transporteur/cargaison"
      ? "Détail de la cargaison"
      : location === "/transporteur/proposition"
        ? "Faire une proposition"
        : location === "/transporteur/proposition-envoyee"
          ? "Proposition envoyée"
          : (nav.find((item) => item.href === location)?.label ?? "Accueil")
    : location === "/nouvelle-expedition"
      ? "Créer une expédition"
      : location === "/expedition-publiee"
        ? "Expédition publiée"
        : (nav.find((item) => item.href === location)?.label ?? "Accueil");

  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[250px] flex-col bg-[#17344f] px-5 py-6 text-[#f7f5ef] lg:flex">
        <BrandMark dark />
        <div className="mt-12">
          <p className="mono-font mb-4 px-3 text-[10px] uppercase tracking-[.16em] text-[#96b5b5]">
            {isTransporter ? "Espace transporteur" : "Espace client"}
          </p>
          <nav className="space-y-1.5">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition ${active ? "bg-[#e0efeb] text-[#17344f]" : "text-[#b9c9c9] hover:bg-[#25445f] hover:text-white"}`}
                  data-testid={`link-nav-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  <Icon size={17} strokeWidth={active ? 2.5 : 1.8} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.07] p-4">
          <ShieldCheck size={19} className="text-[#8bc2b6]" />
          <p className="mt-3 text-sm font-bold">
            {isTransporter
              ? "Des trajets bien choisis."
              : "Vos envois, bien cadrés."}
          </p>
          <p className="mt-1 text-xs leading-5 text-[#a8bcbc]">
            {isTransporter
              ? "Trouvez les cargaisons qui correspondent à votre activité."
              : "Chaque étape est documentée et visible par votre équipe."}
          </p>
        </div>
        <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-5">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#f4a261] text-xs font-extrabold text-[#17344f]">
            {isTransporter ? "TM" : "CR"}
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-bold">
              {isTransporter ? "Thomas Martin" : "Claire Renaud"}
            </p>
            <p className="truncate text-[11px] text-[#a8bcbc]">
              {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
            </p>
          </div>
          <ChevronDown size={14} className="ml-auto text-[#a8bcbc]" />
        </div>
      </aside>

      <div className="lg:pl-[250px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#e1e3de] bg-[#f7f5ef]/90 px-5 backdrop-blur-md sm:px-8">
          <div className="flex items-center gap-3">
            <button
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white text-[#17344f] lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Ouvrir le menu"
              data-testid="button-open-menu"
            >
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
            <div className="lg:hidden">
              <BrandMark />
            </div>
            <span className="hidden text-sm text-[#7b8a92] sm:block">
              {sectionTitle}
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <IconButton label="Aide">
              <CircleHelp size={18} />
            </IconButton>
            <IconButton label="Notifications">
              <Bell size={18} />
            </IconButton>
            <span className="hidden h-6 w-px bg-[#d8dfdf] sm:block" />
            <span className="grid h-9 w-9 place-items-center rounded-full bg-[#d8e9e6] text-xs font-extrabold text-[#28645e] sm:hidden">
              {isTransporter ? "TM" : "CR"}
            </span>
            <span className="hidden text-right sm:block">
              <span className="block text-xs font-bold">
                {isTransporter ? "Thomas Martin" : "Claire Renaud"}
              </span>
              <span className="block text-[11px] text-[#819099]">
                {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
              </span>
            </span>
          </div>
        </header>
        {mobileOpen ? (
          <div className="fixed inset-x-0 top-[76px] z-20 border-b border-[#dfe5e1] bg-[#f7f5ef] p-4 shadow-lg lg:hidden">
            <nav className="grid gap-2">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="focus-ring rounded-xl bg-white px-4 py-3 text-sm font-bold text-[#17344f]"
                  data-testid={`link-mobile-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        ) : null}
        <main>{children}</main>
      </div>
    </div>
  );
}

function RouteDiagram() {
  return (
    <div className="relative h-[310px] overflow-hidden rounded-[2rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:h-[360px] sm:p-10">
      <div className="absolute inset-0 opacity-20 page-grid" />
      <div className="absolute -right-20 -top-16 h-64 w-64 rounded-full border border-[#9cc6bd]/30" />
      <div className="absolute -right-8 top-0 h-48 w-48 rounded-full border border-[#9cc6bd]/20" />
      <div className="absolute bottom-8 left-1/2 h-[1px] w-[72%] -translate-x-1/2 rotate-[22deg] bg-[#f4a261]/60 sm:w-[66%]" />
      <div className="absolute bottom-[102px] left-[21%] h-3 w-3 rounded-full bg-[#f4a261] ring-8 ring-[#f4a261]/15 sm:left-[24%]" />
      <div className="absolute right-[18%] top-[88px] h-3 w-3 rounded-full bg-[#9cc6bd] ring-8 ring-[#9cc6bd]/15 sm:right-[23%]" />
      <div className="absolute bottom-[64px] left-[17%] sm:left-[20%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Départ
        </p>
        <p className="mt-1 text-sm font-bold">Paris 11e</p>
      </div>
      <div className="absolute right-[10%] top-[48px] text-right sm:right-[15%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Arrivée
        </p>
        <p className="mt-1 text-sm font-bold">Lyon 2e</p>
      </div>
      <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between sm:bottom-8 sm:left-10 sm:right-10">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Distance estimée
          </p>
          <p className="display-font mt-1 text-2xl font-bold">465 km</p>
        </div>
        <Truck
          className="route-pulse text-[#f4a261]"
          size={34}
          strokeWidth={1.3}
        />
        <div className="text-right">
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Délai cible
          </p>
          <p className="display-font mt-1 text-2xl font-bold">J + 1</p>
        </div>
      </div>
    </div>
  );
}

function WelcomePage() {
  return (
    <div className="noise-overlay min-h-[100dvh] overflow-hidden bg-[#f7f5ef] text-[#17344f]">
      <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <span className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
          Le transport, côté confiance
        </span>
      </header>
      <main>
        <section className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 pb-20 pt-10 sm:px-8 md:grid-cols-[1.03fr_.97fr] md:gap-10 md:pb-28 md:pt-20">
          <div className="relative z-10">
            <div
              className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.11em] text-[#28645e]"
              data-testid="status-hero"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />{" "}
              Transport professionnel, simplement
            </div>
            <h1 className="display-font animate-rise animate-rise-delay-1 mt-7 max-w-[660px] text-[3.45rem] font-bold leading-[.98] tracking-[-.065em] text-[#17344f] sm:text-[5.2rem] lg:text-[6.1rem]">
              Votre colis.
              <br />
              <span className="text-[#df8550]">Notre trajet.</span>
            </h1>
            <p className="animate-rise animate-rise-delay-2 mt-7 max-w-[500px] text-base leading-7 text-[#5d707a] sm:text-lg">
              GoLink France coordonne vos expéditions avec des transporteurs
              vérifiés, pour que chaque livraison avance avec clarté.
            </p>
            <div className="animate-rise animate-rise-delay-3 mt-9 grid gap-3 sm:grid-cols-2">
              <Link
                href="/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl bg-[#df8550] px-4 py-4 text-left text-[#17344f] shadow-[0_12px_26px_rgba(223,133,80,.22)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
                data-testid="link-choix-expediteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  📦
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je veux expédier
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#5d4b3d]">
                    Je cherche un transporteur
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="transition group-hover:translate-x-1"
                />
              </Link>
              <Link
                href="/transporteur/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl border border-[#cad8d5] bg-white/70 px-4 py-4 text-left text-[#17344f] transition hover:-translate-y-0.5 hover:border-[#9abdb4] hover:bg-[#e8f1ed]"
                data-testid="link-choix-transporteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  🚛
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je suis transporteur
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#71828a]">
                    Je cherche des cargaisons
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="text-[#28645e] transition group-hover:translate-x-1"
                />
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap items-center gap-x-7 gap-y-3 text-xs font-semibold text-[#71828a]">
              <span className="flex items-center gap-2">
                <BadgeCheck size={16} className="text-[#4f9e91]" />{" "}
                Transporteurs vérifiés
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#4f9e91]" /> Suivi à
                chaque étape
              </span>
            </div>
          </div>
          <div className="animate-rise animate-rise-delay-2 relative md:pl-6">
            <div className="absolute -right-8 -top-7 hidden h-36 w-36 rounded-full border border-[#d2a17f]/50 md:block" />
            <RouteDiagram />
            <div className="card-shadow absolute -bottom-7 left-5 flex w-[calc(100%-40px)] items-center gap-3 rounded-2xl border border-[#e1e9e5] bg-white p-4 sm:left-10 sm:w-auto sm:min-w-[290px]">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e3f0ed] text-[#28645e]">
                <Check size={20} strokeWidth={2.5} />
              </span>
              <div>
                <p className="text-xs font-extrabold text-[#17344f]">
                  Une livraison qui se précise
                </p>
                <p className="mt-1 text-[11px] text-[#819099]">
                  Notification envoyée au destinataire
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="border-y border-[#e1e3de] bg-[#eef2ec]">
          <div className="mx-auto grid max-w-[1240px] gap-8 px-5 py-14 sm:px-8 md:grid-cols-[.85fr_1.15fr] md:items-center md:gap-16 md:py-20">
            <div>
              <p className="mono-font text-[10px] font-medium uppercase tracking-[.16em] text-[#6b8f8a]">
                Pensé pour le terrain
              </p>
              <h2 className="display-font mt-4 text-3xl font-bold tracking-[-.04em] text-[#17344f] sm:text-4xl">
                La logistique, sans la zone grise.
              </h2>
            </div>
            <div className="grid gap-7 sm:grid-cols-3">
              <div>
                <span className="mono-font text-2xl text-[#df8550]">01</span>
                <h3 className="mt-3 text-sm font-extrabold">Décrivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Votre besoin est cadré en quelques minutes.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">02</span>
                <h3 className="mt-3 text-sm font-extrabold">Choisissez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Des professionnels adaptés à votre trajet.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">03</span>
                <h3 className="mt-3 text-sm font-extrabold">Suivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Une livraison documentée, jusqu’à la remise.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="mx-auto flex max-w-[1240px] flex-col justify-between gap-6 px-5 py-14 sm:flex-row sm:items-center sm:px-8 sm:py-16">
          <div>
            <p className="display-font text-xl font-bold tracking-[-.03em]">
              Une route plus lisible commence ici.
            </p>
            <p className="mt-2 text-sm text-[#71828a]">
              Expédiez ou transportez avec un espace conçu pour votre activité.
            </p>
          </div>
        </section>
      </main>
      <footer className="border-t border-[#e1e3de] px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-3 text-xs text-[#819099] sm:flex-row">
          <span>© 2024 GoLink France</span>
          <span>Le transport, côté confiance.</span>
        </div>
      </footer>
    </div>
  );
}

function ProfilePage() {
  const [hovered, setHovered] = useState<string | null>(null);
  const profiles = [
    {
      id: "client",
      href: "/tableau-de-bord",
      icon: Package,
      eyebrow: "Pour vos marchandises",
      title: "Je veux expédier",
      text: "Je cherche un transporteur",
      action: "Accéder à mon espace",
    },
    {
      id: "transporter",
      href: "/transporteur/tableau-de-bord",
      icon: Truck,
      eyebrow: "Pour votre activité",
      title: "Je suis transporteur",
      text: "Je cherche des cargaisons",
      action: "Accéder à mon espace",
    },
  ];
  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <header className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <Link
          href="/"
          className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-[#687a82] transition hover:text-[#17344f]"
          data-testid="link-retour-accueil"
        >
          <ArrowLeft size={15} /> Retour à l’accueil
        </Link>
      </header>
      <main className="mx-auto max-w-[1000px] px-5 pb-16 pt-12 sm:px-8 sm:pt-20">
        <div className="mx-auto max-w-[650px] text-center">
          <span className="mono-font text-[10px] uppercase tracking-[.16em] text-[#6b8f8a]">
            Première étape
          </span>
          <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.055em] sm:text-6xl">
            Par où commence-t-on ?
          </h1>
          <p className="mt-5 text-base leading-7 text-[#6e7d83]">
            Choisissez votre parcours. GoLink France s’adapte à votre façon de
            travailler.
          </p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {profiles.map((profile) => {
            const Icon = profile.icon;
            const active = hovered === profile.id;
            return (
              <Link
                key={profile.id}
                href={profile.href}
                onMouseEnter={() => setHovered(profile.id)}
                onMouseLeave={() => setHovered(null)}
                className={`focus-ring group relative overflow-hidden rounded-[1.6rem] border p-7 transition duration-300 sm:p-9 ${active ? "border-[#6da99d] bg-[#e7f1ed] shadow-[0_18px_44px_rgba(40,100,94,.12)]" : "border-[#dbe3de] bg-white hover:border-[#a6c8c0]"}`}
                data-testid={`link-profil-${profile.id}`}
              >
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl transition ${active ? "bg-[#17344f] text-[#f4a261]" : "bg-[#e7f1ed] text-[#28645e]"}`}
                >
                  <Icon size={26} strokeWidth={1.8} />
                </span>
                <p className="mono-font mt-10 text-[10px] uppercase tracking-[.15em] text-[#6b8f8a]">
                  {profile.eyebrow}
                </p>
                <h2 className="display-font mt-3 text-2xl font-bold tracking-[-.035em] sm:text-3xl">
                  {profile.title}
                </h2>
                <p className="mt-4 max-w-[380px] text-sm leading-6 text-[#6e7d83]">
                  {profile.text}
                </p>
                <span className="mt-8 inline-flex items-center gap-2 text-sm font-extrabold text-[#28645e]">
                  {profile.action}
                  <ArrowRight
                    size={16}
                    className={`transition ${active ? "translate-x-1" : ""}`}
                  />
                </span>
                <span className="absolute -bottom-12 -right-10 h-32 w-32 rounded-full border border-[#b6d4cd]" />
              </Link>
            );
          })}
        </div>
        <div className="mx-auto mt-12 flex max-w-[560px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4 text-left">
          <Info size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
          <p className="text-xs leading-5 text-[#71828a]">
            Chaque choix ouvre un espace dédié à votre activité. Ce prototype ne
            demande aucune inscription.
          </p>
        </div>
      </main>
    </div>
  );
}

function DashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Mardi 18 juin 2024 · Paris
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Claire<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Voici où en sont vos expéditions.
          </p>
        </div>
        <Link
          href="/nouvelle-expedition"
          className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#df8550] px-4 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_9px_20px_rgba(223,133,80,.18)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
          data-testid="link-nouvelle-expedition"
        >
          <Plus size={18} /> Nouvelle expédition
        </Link>
      </div>
      <div className="animate-rise animate-rise-delay-1 mt-9 grid gap-4 sm:grid-cols-3">
        {[
          {
            label: "En cours",
            value: "03",
            note: "dont 1 à confirmer",
            accent: "teal",
          },
          {
            label: "Livrées ce mois",
            value: "12",
            note: "+ 3 vs. mai",
            accent: "orange",
          },
          {
            label: "Délai moyen",
            value: "1,4 j",
            note: "sur les 30 derniers jours",
            accent: "navy",
          },
        ].map((metric) => (
          <div
            key={metric.label}
            className="card-shadow rounded-2xl border border-[#e0e5e0] bg-white p-5"
          >
            <div className="flex items-start justify-between">
              <p className="text-xs font-bold text-[#71828a]">{metric.label}</p>
              <span
                className={`h-2 w-2 rounded-full ${metric.accent === "orange" ? "bg-[#df8550]" : metric.accent === "navy" ? "bg-[#17344f]" : "bg-[#6da99d]"}`}
              />
            </div>
            <p className="display-font mt-4 text-3xl font-bold tracking-[-.05em]">
              {metric.value}
            </p>
            <p className="mt-2 text-[11px] text-[#8a9699]">{metric.note}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <section className="animate-rise animate-rise-delay-2 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                À suivre
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Vos expéditions
              </h2>
            </div>
            <button
              className="focus-ring text-xs font-bold text-[#28645e] hover:underline"
              onClick={() =>
                window.alert(
                  "Dans la version complète, cette vue affiche tout l’historique.",
                )
              }
              data-testid="button-voir-tout"
            >
              Voir tout
            </button>
          </div>
          <div className="mt-7 divide-y divide-[#edf0eb]">
            {[
              {
                ref: shipment.reference,
                route: `${shipment.senderCity} → ${shipment.receiverCity}`,
                desc: shipment.goodsType,
                status: "Recherche en cours",
                tone: "orange" as const,
                date: "Créée il y a 12 min",
              },
              {
                ref: "GL-240616-038",
                route: "Boulogne → Lille",
                desc: "Pièces détachées · 420 kg",
                status: "Transport confirmé",
                tone: "teal" as const,
                date: "Livraison demain",
              },
              {
                ref: "GL-240612-021",
                route: "Nantes → Bordeaux",
                desc: "Mobilier · 2,1 m³",
                status: "Livrée",
                tone: "muted" as const,
                date: "12 juin 2024",
              },
            ].map((item, index) => (
              <div
                key={item.ref}
                className="group flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
                data-testid={`row-expedition-${index}`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${index === 0 ? "bg-[#fff0e5] text-[#b7683c]" : "bg-[#e8f0ed] text-[#477d75]"}`}
                  >
                    <RouteIcon size={17} />
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold">{item.route}</p>
                      <StatusBadge tone={item.tone}>{item.status}</StatusBadge>
                    </div>
                    <p className="mt-1 text-xs text-[#8a9699]">
                      {item.ref} · {item.desc}
                    </p>
                  </div>
                </div>
                <p className="pl-12 text-[11px] font-semibold text-[#8a9699] sm:pl-0">
                  {item.date}
                </p>
              </div>
            ))}
          </div>
        </section>
        <section className="animate-rise animate-rise-delay-3 rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
                Votre activité
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Ce mois-ci
              </h2>
            </div>
            <Sparkles size={19} className="text-[#f4a261]" />
          </div>
          <div className="mt-8 grid grid-cols-2 gap-y-7">
            <div>
              <p className="text-3xl font-bold">15</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">expéditions créées</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                98<span className="text-lg">%</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">remises à temps</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                4,8<span className="text-lg">/5</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">satisfaction</p>
            </div>
            <div>
              <p className="text-3xl font-bold">8</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">
                transporteurs utilisés
              </p>
            </div>
          </div>
          <div className="mt-9 border-t border-white/10 pt-5">
            <p className="text-xs leading-5 text-[#b5c7c4]">
              Votre réseau s’agrandit. Les trajets réguliers peuvent être
              enregistrés pour aller plus vite.
            </p>
            <button
              className="focus-ring mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#f4a261] hover:text-[#ffc08f]"
              onClick={() =>
                window.alert(
                  "Les trajets favoris seront disponibles prochainement.",
                )
              }
              data-testid="button-decouvrir-favoris"
            >
              Découvrir les favoris <ArrowRight size={14} />
            </button>
          </div>
        </section>
      </div>
      <section className="mt-7 rounded-[1.4rem] border border-[#e0e5e0] bg-[#eef3ef] p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-[#28645e]">
              <FileText size={18} />
            </span>
            <div>
              <p className="text-sm font-extrabold">
                Besoin d’un coup de main ?
              </p>
              <p className="mt-1 text-xs text-[#71828a]">
                Notre guide explique comment préparer une expédition sans oubli.
              </p>
            </div>
          </div>
          <button
            className="focus-ring w-fit rounded-lg border border-[#bfd2cb] bg-white px-3.5 py-2.5 text-xs font-bold text-[#28645e] transition hover:bg-[#e3f0ed]"
            onClick={() =>
              window.alert("Le guide de préparation est en cours de rédaction.")
            }
            data-testid="button-guide"
          >
            Lire le guide
          </button>
        </div>
      </section>
    </div>
  );
}

function WorkspaceSectionPage({
  role,
  section,
}: {
  role: "client" | "transporter";
  section: "messages" | "profil" | "mes-transports";
}) {
  const isTransporter = role === "transporter";
  const content =
    section === "messages"
      ? {
          eyebrow: "Échanges",
          title: "Messages",
          description: isTransporter
            ? "Retrouvez les échanges liés à vos propositions et à vos transports."
            : "Retrouvez les échanges liés à vos expéditions et aux transporteurs.",
        }
      : section === "profil"
        ? {
            eyebrow: "Votre espace",
            title: "Profil",
            description: isTransporter
              ? "Gérez les informations de Transport Martin."
              : "Gérez les informations de votre entreprise et vos préférences.",
          }
        : {
            eyebrow: "Votre activité",
            title: "Mes transports",
            description:
              "Retrouvez les trajets pour lesquels vous avez envoyé une proposition.",
          };
  return (
    <div className="mx-auto max-w-[980px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise max-w-[620px]">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          {content.eyebrow}
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          {content.title}
        </h1>
        <p className="mt-3 text-sm leading-6 text-[#71828a]">
          {content.description}
        </p>
      </div>
      <section className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-6 sm:p-8">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e8f0ed] text-[#28645e]">
          {section === "messages" ? (
            <MessageCircle size={22} />
          ) : section === "profil" ? (
            <UserRound size={22} />
          ) : (
            <Truck size={22} />
          )}
        </span>
        <h2 className="display-font mt-6 text-2xl font-bold tracking-[-.035em]">
          Cette vue sera bientôt disponible.
        </h2>
        <p className="mt-3 max-w-[560px] text-sm leading-6 text-[#71828a]">
          Le prototype garde votre espace{" "}
          {isTransporter ? "transporteur" : "client"} séparé. Les
          fonctionnalités principales restent accessibles depuis votre
          navigation.
        </p>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-extrabold text-[#526579]">
        {label}
        {required ? <span className="ml-1 text-[#df8550]">*</span> : null}
      </span>
      <input
        name={name}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        type={type}
        required={required}
        className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
        data-testid={`input-${name}`}
      />
    </label>
  );
}

function ShipmentPhotoPicker({
  photos,
  onAdd,
  onRemove,
}: {
  photos: ShipmentPhoto[];
  onAdd: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemove: (photoId: string) => void;
}) {
  return (
    <section
      className="mt-6 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7"
      aria-labelledby="photos-marchandise-title"
    >
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <p
            id="photos-marchandise-title"
            className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
          >
            Photos de la marchandise
          </p>
          <p className="mt-2 text-xs leading-5 text-[#819099]">
            Ajoutez plusieurs vues pour aider le transporteur à préparer son
            trajet.
          </p>
        </div>
        <label
          className="focus-ring inline-flex w-fit cursor-pointer items-center gap-2 rounded-xl border border-[#c8d8d3] bg-[#f7fbf8] px-4 py-3 text-sm font-extrabold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-ajouter-photo"
        >
          <Plus size={16} /> Ajouter une photo
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={onAdd}
            className="sr-only"
            data-testid="input-photos"
          />
        </label>
      </div>
      {photos.length ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1]"
            >
              <img
                src={photo.url}
                alt={photo.name}
                className="aspect-[4/3] w-full object-cover"
              />
              <button
                type="button"
                onClick={() => onRemove(photo.id)}
                className="focus-ring absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-[#17344f]/85 text-white opacity-100 transition hover:bg-[#17344f] sm:opacity-0 sm:group-hover:opacity-100"
                aria-label={`Supprimer ${photo.name}`}
                data-testid={`button-supprimer-photo-${photo.id}`}
              >
                <X size={15} />
              </button>
              <p className="truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                {photo.name}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-6 flex items-center gap-3 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-xs leading-5 text-[#71828a]">
          <Package size={17} className="shrink-0 text-[#6b8f8a]" /> Aucun
          fichier ajouté pour le moment.
        </div>
      )}
    </section>
  );
}

function NewShipmentPage({
  onPublish,
}: {
  onPublish: (shipment: Shipment) => void;
}) {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Shipment>({
    reference: "GL-240618-047",
    senderAddress: "",
    senderCity: "",
    senderPostalCode: "",
    receiverAddress: "",
    receiverCity: "",
    receiverPostalCode: "",
    date: "À convenir",
    goodsType: "",
    weight: "",
    packageCount: "",
    vehicleType: "",
    offeredPrice: "",
    photos: [],
  });
  const update = (key: keyof Shipment) => (value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
  };
  const addPhotos = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []).filter((file) =>
      file.type.startsWith("image/"),
    );
    if (!files.length) return;
    const newPhotos = files.map((file, index) => ({
      id: `${file.name}-${file.lastModified}-${index}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }));
    setForm((current) => ({
      ...current,
      photos: [...current.photos, ...newPhotos],
    }));
    event.target.value = "";
  };
  const removePhoto = (photoId: string) => {
    setForm((current) => {
      const photo = current.photos.find((item) => item.id === photoId);
      if (photo) URL.revokeObjectURL(photo.url);
      return {
        ...current,
        photos: current.photos.filter((item) => item.id !== photoId),
      };
    });
  };
  const nextStep = (event: FormEvent) => {
    event.preventDefault();
    if (
      !form.senderAddress ||
      !form.senderCity ||
      !form.senderPostalCode ||
      !form.receiverAddress ||
      !form.receiverCity ||
      !form.receiverPostalCode
    ) {
      setError("Renseignez toutes les informations du trajet pour continuer.");
      return;
    }
    setError("");
    setStep(2);
  };
  const submit = () => {
    if (
      !form.goodsType ||
      !form.weight ||
      !form.packageCount ||
      !form.vehicleType ||
      !form.offeredPrice
    ) {
      setError("Complétez les informations de la cargaison avant de publier.");
      return;
    }
    onPublish({
      ...form,
      weight: `${form.weight} kg`,
      offeredPrice: `${form.offeredPrice} €`,
    });
    setLocation("/expedition-publiee");
  };
  return (
    <div className="mx-auto max-w-[1020px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise">
        <Link
          href="/tableau-de-bord"
          className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
          data-testid="link-retour-dashboard"
        >
          <ArrowLeft size={14} /> Retour au tableau de bord
        </Link>
        <div className="mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              Nouvelle expédition
            </p>
            <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
              Préparons votre trajet.
            </h1>
            <p className="mt-2 text-sm text-[#71828a]">
              Décrivez votre besoin en deux étapes simples.
            </p>
          </div>
          <span className="mono-font text-xs text-[#71828a]">
            Réf. {form.reference}
          </span>
        </div>
      </div>
      <div className="mt-9 grid gap-8 lg:grid-cols-[1fr_280px]">
        <div>
          <div className="mb-7 flex items-center gap-2 sm:gap-4">
            {["Le trajet", "La cargaison"].map((label, index) => {
              const number = index + 1;
              return (
                <div
                  key={label}
                  className="flex flex-1 items-center gap-2 sm:gap-3"
                >
                  <span
                    className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-extrabold ${step >= number ? "bg-[#17344f] text-[#f7f5ef]" : "border border-[#d4dfda] bg-white text-[#9aa8aa]"}`}
                  >
                    {step > number ? <Check size={15} /> : number}
                  </span>
                  <span
                    className={`hidden text-xs font-bold sm:block ${step >= number ? "text-[#17344f]" : "text-[#9aa8aa]"}`}
                  >
                    {label}
                  </span>
                  {number < 2 ? (
                    <span
                      className={`h-px flex-1 ${step > number ? "bg-[#6da99d]" : "bg-[#dce3df]"}`}
                    />
                  ) : null}
                </div>
              );
            })}
          </div>
          <form
            onSubmit={nextStep}
            className="rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
            data-testid="form-nouvelle-expedition"
          >
            {step === 1 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
                    <RouteIcon size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">Le trajet</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Indiquez les deux points de votre expédition.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-8 md:grid-cols-2">
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de collecte
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de collecte"
                        name="adresse-collecte"
                        value={form.senderAddress}
                        onChange={update("senderAddress")}
                        placeholder="Ex. 18 rue de Charonne"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-collecte"
                        value={form.senderCity}
                        onChange={update("senderCity")}
                        placeholder="Ex. Paris"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-collecte"
                        value={form.senderPostalCode}
                        onChange={update("senderPostalCode")}
                        placeholder="Ex. 75011"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de livraison
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de livraison"
                        name="adresse-livraison"
                        value={form.receiverAddress}
                        onChange={update("receiverAddress")}
                        placeholder="Ex. 7 rue Mercière"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-livraison"
                        value={form.receiverCity}
                        onChange={update("receiverCity")}
                        placeholder="Ex. Lyon"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-livraison"
                        value={form.receiverPostalCode}
                        onChange={update("receiverPostalCode")}
                        placeholder="Ex. 69002"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
            {step === 2 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
                    <Box size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">La cargaison</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Donnez aux transporteurs les informations utiles pour
                      répondre.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-5 md:grid-cols-2">
                  <Field
                    label="Type de marchandise"
                    name="type-marchandise"
                    value={form.goodsType}
                    onChange={update("goodsType")}
                    placeholder="Ex. Mobilier professionnel"
                    required
                  />
                  <Field
                    label="Poids en kg"
                    name="poids"
                    value={form.weight}
                    onChange={update("weight")}
                    placeholder="Ex. 180"
                    type="number"
                    required
                  />
                  <Field
                    label="Nombre de colis"
                    name="nombre-colis"
                    value={form.packageCount}
                    onChange={update("packageCount")}
                    placeholder="Ex. 3"
                    type="number"
                    required
                  />
                  <label className="block">
                    <span className="mb-2 block text-xs font-extrabold text-[#526579]">
                      Type de véhicule
                      <span className="ml-1 text-[#df8550]">*</span>
                    </span>
                    <select
                      name="type-vehicule"
                      value={form.vehicleType}
                      onChange={(event) =>
                        update("vehicleType")(event.target.value)
                      }
                      required
                      className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition focus:border-[#6da99d] focus:bg-white"
                      data-testid="select-type-vehicule"
                    >
                      <option value="">Sélectionnez un véhicule</option>
                      <option>Fourgon</option>
                      <option>Camion porteur</option>
                      <option>Poids lourd</option>
                      <option>Véhicule avec hayon</option>
                    </select>
                  </label>
                  <Field
                    label="Prix proposé en €"
                    name="prix-propose"
                    value={form.offeredPrice}
                    onChange={update("offeredPrice")}
                    placeholder="Ex. 420"
                    type="number"
                    required
                  />
                </div>
                <div className="mt-6 flex items-start gap-2 rounded-xl bg-[#f1f5f1] p-3 text-xs leading-5 text-[#71828a]">
                  <Info size={15} className="mt-0.5 shrink-0 text-[#6b8f8a]" />{" "}
                  Votre prix proposé sera visible par les transporteurs
                  intéressés par ce trajet.
                </div>
              </div>
            ) : null}
            {error ? (
              <p
                className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
                role="alert"
                data-testid="text-form-error"
              >
                {error}
              </p>
            ) : null}
            <div className="mt-8 flex flex-col-reverse justify-between gap-3 border-t border-[#edf0eb] pt-6 sm:flex-row sm:items-center">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    setError("");
                    setStep(1);
                  }}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-bold text-[#71828a] transition hover:bg-[#f1f4f0] hover:text-[#17344f]"
                  data-testid="button-etape-precedente"
                >
                  <ArrowLeft size={16} /> Étape précédente
                </button>
              ) : (
                <span className="hidden sm:block text-xs text-[#98a4a6]">
                  * Champs obligatoires
                </span>
              )}
              {step === 1 ? (
                <button
                  type="submit"
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                  data-testid="button-continuer"
                >
                  Continuer <ArrowRight size={16} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={submit}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
                  data-testid="button-publier-cargaison"
                >
                  Publier la cargaison <ArrowRight size={16} />
                </button>
              )}
            </div>
          </form>
          {step === 2 ? (
            <ShipmentPhotoPicker
              photos={form.photos}
              onAdd={addPhotos}
              onRemove={removePhoto}
            />
          ) : null}
        </div>
        <aside className="hidden lg:block">
          <div className="sticky top-[105px] rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Bon à savoir
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Vous gardez le cap.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Votre annonce reste modifiable jusqu’à sa publication.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <MapPin size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Un trajet précis aide à obtenir des propositions adaptées.
                </p>
              </div>
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Les transporteurs voient les informations nécessaires avant de
                  répondre.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ShipmentPhotosSection({ photos }: { photos: ShipmentPhoto[] }) {
  const [selectedPhoto, setSelectedPhoto] = useState<ShipmentPhoto | null>(
    null,
  );

  return (
    <>
      <section
        className="border-t border-[#edf0eb] px-5 py-6 sm:px-7"
        aria-labelledby="photos-cargaison-title"
      >
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
            <Package size={18} />
          </span>
          <div>
            <p
              id="photos-cargaison-title"
              className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
            >
              Photos de la marchandise
            </p>
            <p className="mt-2 text-xs text-[#819099]">
              Consultez les photos ajoutées par le client avant de répondre.
            </p>
          </div>
        </div>
        {photos.length ? (
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {photos.map((photo) => (
              <button
                type="button"
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="focus-ring group overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1] text-left"
                aria-label={`Agrandir ${photo.name}`}
                data-testid={`button-agrandir-photo-${photo.id}`}
              >
                <img
                  src={photo.url}
                  alt={photo.name}
                  className="aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-[1.03]"
                />
                <span className="block truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                  {photo.name}
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div
            className="mt-5 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-sm font-semibold text-[#71828a]"
            data-testid="text-aucune-photo"
          >
            Aucune photo disponible
          </div>
        )}
      </section>
      {selectedPhoto ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#10263a]/80 p-5 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo agrandie : ${selectedPhoto.name}`}
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelectedPhoto(null);
          }}
        >
          <div className="relative max-h-[90vh] max-w-[min(900px,calc(100vw-2.5rem))] overflow-hidden rounded-2xl bg-white p-2 shadow-2xl">
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="focus-ring absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-[#17344f]/90 text-white transition hover:bg-[#17344f]"
              aria-label="Fermer la photo agrandie"
              data-testid="button-fermer-photo"
            >
              <X size={18} />
            </button>
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.name}
              className="max-h-[82vh] max-w-full rounded-xl object-contain"
            />
            <p className="px-2 pb-1 pt-2 text-xs font-semibold text-[#526579]">
              {selectedPhoto.name}
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}

function PublishedPage({ shipment }: { shipment: Shipment }) {
  const [, setLocation] = useLocation();
  return (
    <div className="mx-auto max-w-[980px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[720px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Expédition publiée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre expédition a été publiée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[540px] text-base leading-7 text-[#71828a]">
          Votre cargaison est maintenant visible par les transporteurs
          intéressés par ce trajet.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[820px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="flex flex-col justify-between gap-3 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Résumé de l’expédition
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.reference}</p>
          </div>
          <StatusBadge>Recherche de transporteur</StatusBadge>
        </div>
        <div className="grid gap-0 sm:grid-cols-[1fr_80px_1fr] sm:items-center">
          <div className="p-6 sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Collecte
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.senderCity} · {shipment.senderPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.senderAddress}
            </p>
          </div>
          <div className="hidden justify-center sm:flex">
            <div className="h-px w-10 bg-[#b9d2cc]" />
            <Truck size={18} className="mx-[-4px] text-[#df8550]" />
            <div className="h-px w-10 bg-[#b9d2cc]" />
          </div>
          <div className="border-t border-[#edf0eb] p-6 sm:border-t-0 sm:border-l sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Livraison
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.receiverCity} · {shipment.receiverPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.receiverAddress}
            </p>
          </div>
        </div>
        <div className="grid gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] p-5 sm:grid-cols-4 sm:px-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Marchandise
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.goodsType}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Poids
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.weight}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Colis
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.packageCount}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.offeredPrice}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
          <Truck size={15} className="text-[#6b8f8a]" /> Véhicule souhaité :{" "}
          <strong>{shipment.vehicleType}</strong>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[760px] gap-3 sm:grid-cols-2">
        <button
          onClick={() => setLocation("/tableau-de-bord")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-voir-tableau"
        >
          Voir mon tableau de bord <ArrowRight size={16} />
        </button>
        <button
          onClick={() => setLocation("/nouvelle-expedition")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-nouvelle-apres-publication"
        >
          <Plus size={16} /> Créer une autre expédition
        </button>
      </div>
      <div className="mx-auto mt-12 flex max-w-[600px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4">
        <Clock3 size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
        <p className="text-xs leading-5 text-[#71828a]">
          <strong className="text-[#526579]">Et maintenant ?</strong> Les
          transporteurs intéressés peuvent consulter votre annonce. Consultez
          votre tableau de bord pour suivre les réponses.
        </p>
      </div>
    </div>
  );
}

function TransporterDashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1240px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Espace transporteur · Aujourd’hui
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Thomas<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Des trajets qui correspondent à votre activité.
          </p>
        </div>
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-2 text-xs font-bold text-[#28645e]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" /> Profil
          transporteur actif
        </span>
      </div>

      <section className="animate-rise animate-rise-delay-1 mt-10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              À saisir
            </p>
            <h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em] sm:text-3xl">
              Cargaisons disponibles
            </h2>
            <p className="mt-2 max-w-[560px] text-sm leading-6 text-[#71828a]">
              Découvrez les expéditions à proximité et proposez un transport
              adapté.
            </p>
          </div>
          <span className="text-xs font-bold text-[#819099]">
            1 nouvelle cargaison
          </span>
        </div>

        <div className="mt-7 grid gap-6 xl:grid-cols-[1fr_280px]">
          <article className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
            <div className="flex flex-col justify-between gap-4 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge tone="orange">Nouvelle</StatusBadge>
                  <span className="mono-font text-[10px] tracking-[.12em] text-[#819099]">
                    {shipment.reference}
                  </span>
                </div>
                <p className="display-font mt-3 text-2xl font-bold tracking-[-.04em]">
                  {shipment.senderCity}{" "}
                  <span className="text-[#df8550]">→</span>{" "}
                  {shipment.receiverCity}
                </p>
              </div>
              <Link
                href="/transporteur/cargaison"
                className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#17344f] px-4 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                data-testid="button-voir-cargaison"
              >
                Voir la cargaison <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid gap-0 sm:grid-cols-2 lg:grid-cols-4">
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Date
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.date}</p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 lg:border-b-0 lg:border-r">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Marchandise
                </p>
                <p className="mt-2 text-sm font-extrabold">
                  {shipment.goodsType}
                </p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Poids
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.weight}</p>
              </div>
              <div className="p-5">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Prix proposé
                </p>
                <p className="mt-2 text-sm font-extrabold text-[#b7683c]">
                  {formatEuro(shipment.offeredPrice)}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
              <span className="flex items-center gap-2">
                <Truck size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.vehicleType}
              </span>
              <span className="flex items-center gap-2">
                <Box size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.packageCount} colis
              </span>
              <span className="flex items-center gap-2">
                <MapPin size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.senderPostalCode} → {shipment.receiverPostalCode}
              </span>
            </div>
          </article>

          <aside className="rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Votre activité
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Roulez utile.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Les cargaisons sont présentées avec les informations essentielles
              pour décider rapidement.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Des annonces structurées, sans détour.
                </p>
              </div>
              <div className="flex gap-3">
                <RouteIcon size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Une route claire avant de prendre la route.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function ShipmentDetailsPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1000px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/tableau-de-bord"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-cargaisons"
      >
        <ArrowLeft size={14} /> Retour aux cargaisons
      </Link>
      <div className="animate-rise mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Détail de la cargaison
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            {shipment.senderCity} <span className="text-[#df8550]">→</span>{" "}
            {shipment.receiverCity}
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Réf. {shipment.reference} · {shipment.date}
          </p>
        </div>
        <StatusBadge tone="orange">Recherche de transporteur</StatusBadge>
      </div>
      <div className="mt-9 grid gap-6 lg:grid-cols-[1fr_280px]">
        <section className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
          <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Informations du trajet
            </p>
            <p className="mt-2 text-sm font-extrabold">
              De la collecte à la livraison
            </p>
          </div>
          <div className="grid gap-0 sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de collecte
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.senderAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.senderCity} · {shipment.senderPostalCode}
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de livraison
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.receiverAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.receiverCity} · {shipment.receiverPostalCode}
              </p>
            </div>
          </div>
          <div className="grid gap-0 border-t border-[#edf0eb] sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Marchandise
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.goodsType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.weight} · {shipment.packageCount} colis
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Transport
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.vehicleType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                Date : {shipment.date}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] px-6 py-5 sm:px-7">
            <span className="text-sm font-bold text-[#526579]">
              Prix proposé par le client
            </span>
            <span className="display-font text-xl font-bold text-[#b7683c]">
              {formatEuro(shipment.offeredPrice)}
            </span>
          </div>
          <ShipmentPhotosSection photos={shipment.photos} />
        </section>
        <aside className="h-fit rounded-[1.4rem] border border-[#dfe7e2] bg-[#eef3ef] p-6">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre réponse
          </p>
          <h2 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
            Le trajet vous convient ?
          </h2>
          <p className="mt-3 text-xs leading-5 text-[#71828a]">
            Envoyez votre prix et un message au client pour vous positionner sur
            cette cargaison.
          </p>
          <Link
            href="/transporteur/proposition"
            className="focus-ring mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#df8550] px-4 py-3.5 text-sm font-extrabold text-[#17344f] transition hover:bg-[#eb9863]"
            data-testid="button-faire-proposition"
          >
            Faire une proposition <ArrowRight size={16} />
          </Link>
        </aside>
      </div>
    </div>
  );
}

function TransporterProposalPage({
  shipment,
  onSend,
}: {
  shipment: Shipment;
  onSend: (proposal: Proposal) => void;
}) {
  const [, setLocation] = useLocation();
  const [proposal, setProposal] = useState<Proposal>({
    price: "",
    message: "",
  });
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!proposal.price || !proposal.message) {
      setError("Renseignez votre prix et votre message avant d’envoyer.");
      return;
    }
    onSend({ ...proposal, price: `${proposal.price} €` });
    setLocation("/transporteur/proposition-envoyee");
  };
  return (
    <div className="mx-auto max-w-[820px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/cargaison"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-detail-cargaison"
      >
        <ArrowLeft size={14} /> Retour à la cargaison
      </Link>
      <div className="animate-rise mt-7">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Votre proposition
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          Faites avancer le trajet.
        </h1>
        <p className="mt-2 text-sm text-[#71828a]">
          {shipment.senderCity} → {shipment.receiverCity} · {shipment.goodsType}
        </p>
      </div>
      <form
        onSubmit={submit}
        className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
        data-testid="form-proposition"
      >
        <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
            <FileText size={18} />
          </span>
          <div>
            <h2 className="text-base font-extrabold">Répondez au client</h2>
            <p className="mt-1 text-xs text-[#819099]">
              Un prix clair et un message précis font la différence.
            </p>
          </div>
        </div>
        <div className="mt-7 space-y-5">
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Prix proposé par le client
            </span>
            <input
              value={formatEuro(shipment.offeredPrice)}
              readOnly
              className="h-12 w-full cursor-default rounded-xl border border-[#d8e0dc] bg-[#f1f5f1] px-3.5 text-sm font-bold text-[#71828a] outline-none"
              data-testid="input-prix-client"
            />
          </label>
          <Field
            label="Votre prix"
            name="votre-prix"
            value={proposal.price}
            onChange={(value) => {
              setProposal((current) => ({ ...current, price: value }));
              setError("");
            }}
            placeholder="Ex. 390"
            type="number"
            required
          />
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Message<span className="ml-1 text-[#df8550]">*</span>
            </span>
            <textarea
              name="message"
              value={proposal.message}
              onChange={(event) => {
                setProposal((current) => ({
                  ...current,
                  message: event.target.value,
                }));
                setError("");
              }}
              placeholder="Présentez votre disponibilité et vos conditions de transport…"
              className="focus-ring min-h-[140px] w-full resize-y rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 py-3 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
              data-testid="input-message"
            />
          </label>
        </div>
        {error ? (
          <p
            className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
            role="alert"
            data-testid="text-proposition-error"
          >
            {error}
          </p>
        ) : null}
        <div className="mt-8 flex justify-end border-t border-[#edf0eb] pt-6">
          <button
            type="submit"
            className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3.5 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
            data-testid="button-envoyer-proposition"
          >
            Envoyer la proposition <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </div>
  );
}

function ProposalSentPage({
  shipment,
  proposal,
}: {
  shipment: Shipment;
  proposal: Proposal;
}) {
  return (
    <div className="mx-auto max-w-[900px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[700px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Proposition envoyée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre proposition a été envoyée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[520px] text-base leading-7 text-[#71828a]">
          Le client pourra consulter votre offre et revenir vers vous au sujet
          de cette cargaison.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[720px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre offre
          </p>
          <p className="mt-1 text-sm font-extrabold">
            {shipment.senderCity} → {shipment.receiverCity} ·{" "}
            {shipment.reference}
          </p>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé par le client
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#71828a]">
              {formatEuro(shipment.offeredPrice)}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Votre prix
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#b7683c]">
              {proposal.price}
            </p>
          </div>
          <div className="sm:col-span-2">
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Message envoyé
            </p>
            <p className="mt-2 rounded-xl bg-[#fcfdfa] p-4 text-sm leading-6 text-[#526579]">
              {proposal.message}
            </p>
          </div>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[720px] gap-3 sm:grid-cols-2">
        <Link
          href="/transporteur/tableau-de-bord"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-retour-cargaisons"
        >
          Voir les cargaisons disponibles <ArrowRight size={16} />
        </Link>
        <Link
          href="/transporteur/cargaison"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-revoir-cargaison"
        >
          Revoir la cargaison <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}

function Router() {
  const [publishedShipment, setPublishedShipment] =
    useState<Shipment>(starterShipment);
  const [sentProposal, setSentProposal] = useState<Proposal>({
    price: "390 €",
    message:
      "Disponible pour ce trajet avec un fourgon équipé. Je peux prendre en charge les trois colis dans le créneau indiqué.",
  });
  return (
    <AppShell>
      <Switch>
        <Route path="/" component={WelcomePage} />
        <Route path="/choisir-profil" component={ProfilePage} />
        <Route path="/tableau-de-bord">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/mes-expeditions">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/nouvelle-expedition">
          <NewShipmentPage onPublish={setPublishedShipment} />
        </Route>
        <Route path="/expedition-publiee">
          <PublishedPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/tableau-de-bord">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/cargaisons">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/messages">
          <WorkspaceSectionPage role="client" section="messages" />
        </Route>
        <Route path="/profil">
          <WorkspaceSectionPage role="client" section="profil" />
        </Route>
        <Route path="/transporteur/mes-transports">
          <WorkspaceSectionPage role="transporter" section="mes-transports" />
        </Route>
        <Route path="/transporteur/messages">
          <WorkspaceSectionPage role="transporter" section="messages" />
        </Route>
        <Route path="/transporteur/profil">
          <WorkspaceSectionPage role="transporter" section="profil" />
        </Route>
        <Route path="/transporteur/cargaison">
          <ShipmentDetailsPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/proposition">
          <TransporterProposalPage
            shipment={publishedShipment}
            onSend={setSentProposal}
          />
        </Route>
        <Route path="/transporteur/proposition-envoyee">
          <ProposalSentPage
            shipment={publishedShipment}
            proposal={sentProposal}
          />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedErrorBoundary>
            <Router />
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
import {
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
  useState,
} from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  House,
  Info,
  MapPin,
  MessageCircle,
  Menu,
  Package,
  Plus,
  Route as RouteIcon,
  ShieldCheck,
  Sparkles,
  Truck,
  UserRound,
  X,
} from "lucide-react";
import {
  Link,
  Route,
  Switch,
  Router as WouterRouter,
  useLocation,
} from "wouter";

const queryClient = new QueryClient();

type Shipment = {
  id: string;
  reference: string;
  customerName: string;
  customerCompany: string;
  senderAddress: string;
  senderCity: string;
  senderPostalCode: string;
  receiverAddress: string;
  receiverCity: string;
  receiverPostalCode: string;
  date: string;
  pickupDate: string;
  deliveryDate: string;
  goodsType: string;
  weight: string;
  packageCount: string;
  vehicleType: string;
  offeredPrice: string;
  photos: ShipmentPhoto[];
  status: ShipmentStatus;
  transporterName?: string;
  transporterCompany?: string;
};

type ShipmentPhoto = {
  id: string;
  name: string;
  url: string;
};

type Proposal = {
  id: string;
  shipmentId: string;
  transporterName: string;
  transporterCompany: string;
  price: string;
  message: string;
  status: ProposalStatus;
};

type ShipmentStatus =
  | "Recherche de transporteur"
  | "Transporteur confirmé"
  | "En collecte"
  | "En transit"
  | "Livré";
type ProposalStatus = "En attente" | "Acceptée" | "Refusée";

const starterShipment: Shipment = {
  id: "shipment-starter-047",
  reference: "GL-240618-047",
  customerName: "Claire Renaud",
  customerCompany: "Atelier Rivoli",
  senderAddress: "18 rue de Charonne",
  senderCity: "Paris 11e",
  senderPostalCode: "75011",
  receiverAddress: "7 rue Mercière",
  receiverCity: "Lyon 2e",
  receiverPostalCode: "69002",
  date: "18 juin 2024",
  pickupDate: "18 juin 2024",
  deliveryDate: "19 juin 2024",
  goodsType: "Mobilier professionnel",
  weight: "180 kg",
  packageCount: "3",
  vehicleType: "Fourgon",
  offeredPrice: "420",
  photos: [],
  status: "Recherche de transporteur",
};

function createId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function BrandMark({ dark = false }: { dark?: boolean }) {
  return (
    <Link
      href="/"
      className="focus-ring inline-flex items-center gap-3"
      data-testid="link-brand-home"
    >
      <span
        className={`relative grid h-10 w-10 place-items-center rounded-xl ${dark ? "bg-[#f4a261] text-[#14263a]" : "bg-[#17344f] text-[#f8f4ea]"}`}
      >
        <span className="absolute left-[9px] top-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span className="absolute bottom-[9px] right-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span
          className={`absolute h-[2px] w-5 rotate-45 ${dark ? "bg-[#14263a]" : "bg-[#f4a261]"}`}
        />
      </span>
      <span
        className={`display-font text-[1.45rem] font-bold tracking-[-.05em] ${dark ? "text-[#f8f4ea]" : "text-[#17344f]"}`}
      >
        GoLink <span className="text-[#df8550]">France</span>
      </span>
    </Link>
  );
}

function IconButton({
  label,
  children,
  onClick,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white/70 text-[#526579] transition hover:border-[#9cbbba] hover:bg-[#e7f0ee] hover:text-[#17344f]"
      data-testid={`button-${label.toLowerCase().replaceAll(" ", "-")}`}
    >
      {children}
    </button>
  );
}

function StatusBadge({
  children,
  tone = "teal",
}: {
  children: ReactNode;
  tone?: "teal" | "orange" | "muted";
}) {
  const classes =
    tone === "orange"
      ? "bg-[#fff0e5] text-[#a9582d]"
      : tone === "muted"
        ? "bg-[#eef0ef] text-[#63727e]"
        : "bg-[#e3f0ed] text-[#28645e]";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${classes}`}
      data-testid="status-badge"
    >
      {tone === "teal" ? (
        <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />
      ) : null}
      {children}
    </span>
  );
}

function formatEuro(value: string) {
  return value.includes("€") ? value : `${value} €`;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTransporter = location.startsWith("/transporteur/");
  const isDashboard =
    isTransporter ||
    [
      "/tableau-de-bord",
      "/mes-expeditions",
      "/nouvelle-expedition",
      "/expedition-publiee",
      "/messages",
      "/profil",
    ].includes(location);
  if (!isDashboard) return <>{children}</>;

  const nav = isTransporter
    ? [
        {
          href: "/transporteur/tableau-de-bord",
          label: "Accueil",
          icon: House,
        },
        { href: "/transporteur/cargaisons", label: "Cargaisons", icon: Box },
        {
          href: "/transporteur/mes-transports",
          label: "Mes transports",
          icon: Truck,
        },
        {
          href: "/transporteur/messages",
          label: "Messages",
          icon: MessageCircle,
        },
        { href: "/transporteur/profil", label: "Profil", icon: UserRound },
      ]
    : [
        { href: "/tableau-de-bord", label: "Accueil", icon: House },
        { href: "/mes-expeditions", label: "Mes expéditions", icon: Package },
        {
          href: "/nouvelle-expedition",
          label: "Créer une expédition",
          icon: Plus,
        },
        { href: "/messages", label: "Messages", icon: MessageCircle },
        { href: "/profil", label: "Profil", icon: UserRound },
      ];
  const sectionTitle = isTransporter
    ? location === "/transporteur/cargaison"
      ? "Détail de la cargaison"
      : location === "/transporteur/proposition"
        ? "Faire une proposition"
        : location === "/transporteur/proposition-envoyee"
          ? "Proposition envoyée"
          : (nav.find((item) => item.href === location)?.label ?? "Accueil")
    : location === "/nouvelle-expedition"
      ? "Créer une expédition"
      : location === "/expedition-publiee"
        ? "Expédition publiée"
        : (nav.find((item) => item.href === location)?.label ?? "Accueil");

  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[250px] flex-col bg-[#17344f] px-5 py-6 text-[#f7f5ef] lg:flex">
        <BrandMark dark />
        <div className="mt-12">
          <p className="mono-font mb-4 px-3 text-[10px] uppercase tracking-[.16em] text-[#96b5b5]">
            {isTransporter ? "Espace transporteur" : "Espace client"}
          </p>
          <nav className="space-y-1.5">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition ${active ? "bg-[#e0efeb] text-[#17344f]" : "text-[#b9c9c9] hover:bg-[#25445f] hover:text-white"}`}
                  data-testid={`link-nav-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  <Icon size={17} strokeWidth={active ? 2.5 : 1.8} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.07] p-4">
          <ShieldCheck size={19} className="text-[#8bc2b6]" />
          <p className="mt-3 text-sm font-bold">
            {isTransporter
              ? "Des trajets bien choisis."
              : "Vos envois, bien cadrés."}
          </p>
          <p className="mt-1 text-xs leading-5 text-[#a8bcbc]">
            {isTransporter
              ? "Trouvez les cargaisons qui correspondent à votre activité."
              : "Chaque étape est documentée et visible par votre équipe."}
          </p>
        </div>
        <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-5">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#f4a261] text-xs font-extrabold text-[#17344f]">
            {isTransporter ? "TM" : "CR"}
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-bold">
              {isTransporter ? "Thomas Martin" : "Claire Renaud"}
            </p>
            <p className="truncate text-[11px] text-[#a8bcbc]">
              {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
            </p>
          </div>
          <ChevronDown size={14} className="ml-auto text-[#a8bcbc]" />
        </div>
      </aside>

      <div className="lg:pl-[250px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#e1e3de] bg-[#f7f5ef]/90 px-5 backdrop-blur-md sm:px-8">
          <div className="flex items-center gap-3">
            <button
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white text-[#17344f] lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Ouvrir le menu"
              data-testid="button-open-menu"
            >
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
            <div className="lg:hidden">
              <BrandMark />
            </div>
            <span className="hidden text-sm text-[#7b8a92] sm:block">
              {sectionTitle}
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <IconButton label="Aide">
              <CircleHelp size={18} />
            </IconButton>
            <IconButton label="Notifications">
              <Bell size={18} />
            </IconButton>
            <span className="hidden h-6 w-px bg-[#d8dfdf] sm:block" />
            <span className="grid h-9 w-9 place-items-center rounded-full bg-[#d8e9e6] text-xs font-extrabold text-[#28645e] sm:hidden">
              {isTransporter ? "TM" : "CR"}
            </span>
            <span className="hidden text-right sm:block">
              <span className="block text-xs font-bold">
                {isTransporter ? "Thomas Martin" : "Claire Renaud"}
              </span>
              <span className="block text-[11px] text-[#819099]">
                {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
              </span>
            </span>
          </div>
        </header>
        {mobileOpen ? (
          <div className="fixed inset-x-0 top-[76px] z-20 border-b border-[#dfe5e1] bg-[#f7f5ef] p-4 shadow-lg lg:hidden">
            <nav className="grid gap-2">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="focus-ring rounded-xl bg-white px-4 py-3 text-sm font-bold text-[#17344f]"
                  data-testid={`link-mobile-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        ) : null}
        <main>{children}</main>
      </div>
    </div>
  );
}

function RouteDiagram() {
  return (
    <div className="relative h-[310px] overflow-hidden rounded-[2rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:h-[360px] sm:p-10">
      <div className="absolute inset-0 opacity-20 page-grid" />
      <div className="absolute -right-20 -top-16 h-64 w-64 rounded-full border border-[#9cc6bd]/30" />
      <div className="absolute -right-8 top-0 h-48 w-48 rounded-full border border-[#9cc6bd]/20" />
      <div className="absolute bottom-8 left-1/2 h-[1px] w-[72%] -translate-x-1/2 rotate-[22deg] bg-[#f4a261]/60 sm:w-[66%]" />
      <div className="absolute bottom-[102px] left-[21%] h-3 w-3 rounded-full bg-[#f4a261] ring-8 ring-[#f4a261]/15 sm:left-[24%]" />
      <div className="absolute right-[18%] top-[88px] h-3 w-3 rounded-full bg-[#9cc6bd] ring-8 ring-[#9cc6bd]/15 sm:right-[23%]" />
      <div className="absolute bottom-[64px] left-[17%] sm:left-[20%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Départ
        </p>
        <p className="mt-1 text-sm font-bold">Paris 11e</p>
      </div>
      <div className="absolute right-[10%] top-[48px] text-right sm:right-[15%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Arrivée
        </p>
        <p className="mt-1 text-sm font-bold">Lyon 2e</p>
      </div>
      <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between sm:bottom-8 sm:left-10 sm:right-10">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Distance estimée
          </p>
          <p className="display-font mt-1 text-2xl font-bold">465 km</p>
        </div>
        <Truck
          className="route-pulse text-[#f4a261]"
          size={34}
          strokeWidth={1.3}
        />
        <div className="text-right">
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Délai cible
          </p>
          <p className="display-font mt-1 text-2xl font-bold">J + 1</p>
        </div>
      </div>
    </div>
  );
}

function WelcomePage() {
  return (
    <div className="noise-overlay min-h-[100dvh] overflow-hidden bg-[#f7f5ef] text-[#17344f]">
      <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <span className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
          Le transport, côté confiance
        </span>
      </header>
      <main>
        <section className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 pb-20 pt-10 sm:px-8 md:grid-cols-[1.03fr_.97fr] md:gap-10 md:pb-28 md:pt-20">
          <div className="relative z-10">
            <div
              className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.11em] text-[#28645e]"
              data-testid="status-hero"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />{" "}
              Transport professionnel, simplement
            </div>
            <h1 className="display-font animate-rise animate-rise-delay-1 mt-7 max-w-[660px] text-[3.45rem] font-bold leading-[.98] tracking-[-.065em] text-[#17344f] sm:text-[5.2rem] lg:text-[6.1rem]">
              Votre colis.
              <br />
              <span className="text-[#df8550]">Notre trajet.</span>
            </h1>
            <p className="animate-rise animate-rise-delay-2 mt-7 max-w-[500px] text-base leading-7 text-[#5d707a] sm:text-lg">
              GoLink France coordonne vos expéditions avec des transporteurs
              vérifiés, pour que chaque livraison avance avec clarté.
            </p>
            <div className="animate-rise animate-rise-delay-3 mt-9 grid gap-3 sm:grid-cols-2">
              <Link
                href="/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl bg-[#df8550] px-4 py-4 text-left text-[#17344f] shadow-[0_12px_26px_rgba(223,133,80,.22)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
                data-testid="link-choix-expediteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  📦
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je veux expédier
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#5d4b3d]">
                    Je cherche un transporteur
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="transition group-hover:translate-x-1"
                />
              </Link>
              <Link
                href="/transporteur/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl border border-[#cad8d5] bg-white/70 px-4 py-4 text-left text-[#17344f] transition hover:-translate-y-0.5 hover:border-[#9abdb4] hover:bg-[#e8f1ed]"
                data-testid="link-choix-transporteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  🚛
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je suis transporteur
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#71828a]">
                    Je cherche des cargaisons
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="text-[#28645e] transition group-hover:translate-x-1"
                />
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap items-center gap-x-7 gap-y-3 text-xs font-semibold text-[#71828a]">
              <span className="flex items-center gap-2">
                <BadgeCheck size={16} className="text-[#4f9e91]" />{" "}
                Transporteurs vérifiés
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#4f9e91]" /> Suivi à
                chaque étape
              </span>
            </div>
          </div>
          <div className="animate-rise animate-rise-delay-2 relative md:pl-6">
            <div className="absolute -right-8 -top-7 hidden h-36 w-36 rounded-full border border-[#d2a17f]/50 md:block" />
            <RouteDiagram />
            <div className="card-shadow absolute -bottom-7 left-5 flex w-[calc(100%-40px)] items-center gap-3 rounded-2xl border border-[#e1e9e5] bg-white p-4 sm:left-10 sm:w-auto sm:min-w-[290px]">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e3f0ed] text-[#28645e]">
                <Check size={20} strokeWidth={2.5} />
              </span>
              <div>
                <p className="text-xs font-extrabold text-[#17344f]">
                  Une livraison qui se précise
                </p>
                <p className="mt-1 text-[11px] text-[#819099]">
                  Notification envoyée au destinataire
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="border-y border-[#e1e3de] bg-[#eef2ec]">
          <div className="mx-auto grid max-w-[1240px] gap-8 px-5 py-14 sm:px-8 md:grid-cols-[.85fr_1.15fr] md:items-center md:gap-16 md:py-20">
            <div>
              <p className="mono-font text-[10px] font-medium uppercase tracking-[.16em] text-[#6b8f8a]">
                Pensé pour le terrain
              </p>
              <h2 className="display-font mt-4 text-3xl font-bold tracking-[-.04em] text-[#17344f] sm:text-4xl">
                La logistique, sans la zone grise.
              </h2>
            </div>
            <div className="grid gap-7 sm:grid-cols-3">
              <div>
                <span className="mono-font text-2xl text-[#df8550]">01</span>
                <h3 className="mt-3 text-sm font-extrabold">Décrivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Votre besoin est cadré en quelques minutes.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">02</span>
                <h3 className="mt-3 text-sm font-extrabold">Choisissez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Des professionnels adaptés à votre trajet.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">03</span>
                <h3 className="mt-3 text-sm font-extrabold">Suivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Une livraison documentée, jusqu’à la remise.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="mx-auto flex max-w-[1240px] flex-col justify-between gap-6 px-5 py-14 sm:flex-row sm:items-center sm:px-8 sm:py-16">
          <div>
            <p className="display-font text-xl font-bold tracking-[-.03em]">
              Une route plus lisible commence ici.
            </p>
            <p className="mt-2 text-sm text-[#71828a]">
              Expédiez ou transportez avec un espace conçu pour votre activité.
            </p>
          </div>
        </section>
      </main>
      <footer className="border-t border-[#e1e3de] px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-3 text-xs text-[#819099] sm:flex-row">
          <span>© 2024 GoLink France</span>
          <span>Le transport, côté confiance.</span>
        </div>
      </footer>
    </div>
  );
}

function ProfilePage() {
  const [hovered, setHovered] = useState<string | null>(null);
  const profiles = [
    {
      id: "client",
      href: "/tableau-de-bord",
      icon: Package,
      eyebrow: "Pour vos marchandises",
      title: "Je veux expédier",
      text: "Je cherche un transporteur",
      action: "Accéder à mon espace",
    },
    {
      id: "transporter",
      href: "/transporteur/tableau-de-bord",
      icon: Truck,
      eyebrow: "Pour votre activité",
      title: "Je suis transporteur",
      text: "Je cherche des cargaisons",
      action: "Accéder à mon espace",
    },
  ];
  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <header className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <Link
          href="/"
          className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-[#687a82] transition hover:text-[#17344f]"
          data-testid="link-retour-accueil"
        >
          <ArrowLeft size={15} /> Retour à l’accueil
        </Link>
      </header>
      <main className="mx-auto max-w-[1000px] px-5 pb-16 pt-12 sm:px-8 sm:pt-20">
        <div className="mx-auto max-w-[650px] text-center">
          <span className="mono-font text-[10px] uppercase tracking-[.16em] text-[#6b8f8a]">
            Première étape
          </span>
          <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.055em] sm:text-6xl">
            Par où commence-t-on ?
          </h1>
          <p className="mt-5 text-base leading-7 text-[#6e7d83]">
            Choisissez votre parcours. GoLink France s’adapte à votre façon de
            travailler.
          </p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {profiles.map((profile) => {
            const Icon = profile.icon;
            const active = hovered === profile.id;
            return (
              <Link
                key={profile.id}
                href={profile.href}
                onMouseEnter={() => setHovered(profile.id)}
                onMouseLeave={() => setHovered(null)}
                className={`focus-ring group relative overflow-hidden rounded-[1.6rem] border p-7 transition duration-300 sm:p-9 ${active ? "border-[#6da99d] bg-[#e7f1ed] shadow-[0_18px_44px_rgba(40,100,94,.12)]" : "border-[#dbe3de] bg-white hover:border-[#a6c8c0]"}`}
                data-testid={`link-profil-${profile.id}`}
              >
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl transition ${active ? "bg-[#17344f] text-[#f4a261]" : "bg-[#e7f1ed] text-[#28645e]"}`}
                >
                  <Icon size={26} strokeWidth={1.8} />
                </span>
                <p className="mono-font mt-10 text-[10px] uppercase tracking-[.15em] text-[#6b8f8a]">
                  {profile.eyebrow}
                </p>
                <h2 className="display-font mt-3 text-2xl font-bold tracking-[-.035em] sm:text-3xl">
                  {profile.title}
                </h2>
                <p className="mt-4 max-w-[380px] text-sm leading-6 text-[#6e7d83]">
                  {profile.text}
                </p>
                <span className="mt-8 inline-flex items-center gap-2 text-sm font-extrabold text-[#28645e]">
                  {profile.action}
                  <ArrowRight
                    size={16}
                    className={`transition ${active ? "translate-x-1" : ""}`}
                  />
                </span>
                <span className="absolute -bottom-12 -right-10 h-32 w-32 rounded-full border border-[#b6d4cd]" />
              </Link>
            );
          })}
        </div>
        <div className="mx-auto mt-12 flex max-w-[560px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4 text-left">
          <Info size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
          <p className="text-xs leading-5 text-[#71828a]">
            Chaque choix ouvre un espace dédié à votre activité. Ce prototype ne
            demande aucune inscription.
          </p>
        </div>
      </main>
    </div>
  );
}

function DashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Mardi 18 juin 2024 · Paris
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Claire<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Voici où en sont vos expéditions.
          </p>
        </div>
        <Link
          href="/nouvelle-expedition"
          className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#df8550] px-4 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_9px_20px_rgba(223,133,80,.18)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
          data-testid="link-nouvelle-expedition"
        >
          <Plus size={18} /> Nouvelle expédition
        </Link>
      </div>
      <div className="animate-rise animate-rise-delay-1 mt-9 grid gap-4 sm:grid-cols-3">
        {[
          {
            label: "En cours",
            value: "03",
            note: "dont 1 à confirmer",
            accent: "teal",
          },
          {
            label: "Livrées ce mois",
            value: "12",
            note: "+ 3 vs. mai",
            accent: "orange",
          },
          {
            label: "Délai moyen",
            value: "1,4 j",
            note: "sur les 30 derniers jours",
            accent: "navy",
          },
        ].map((metric) => (
          <div
            key={metric.label}
            className="card-shadow rounded-2xl border border-[#e0e5e0] bg-white p-5"
          >
            <div className="flex items-start justify-between">
              <p className="text-xs font-bold text-[#71828a]">{metric.label}</p>
              <span
                className={`h-2 w-2 rounded-full ${metric.accent === "orange" ? "bg-[#df8550]" : metric.accent === "navy" ? "bg-[#17344f]" : "bg-[#6da99d]"}`}
              />
            </div>
            <p className="display-font mt-4 text-3xl font-bold tracking-[-.05em]">
              {metric.value}
            </p>
            <p className="mt-2 text-[11px] text-[#8a9699]">{metric.note}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <section className="animate-rise animate-rise-delay-2 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                À suivre
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Vos expéditions
              </h2>
            </div>
            <button
              className="focus-ring text-xs font-bold text-[#28645e] hover:underline"
              onClick={() =>
                window.alert(
                  "Dans la version complète, cette vue affiche tout l’historique.",
                )
              }
              data-testid="button-voir-tout"
            >
              Voir tout
            </button>
          </div>
          <div className="mt-7 divide-y divide-[#edf0eb]">
            {[
              {
                ref: shipment.reference,
                route: `${shipment.senderCity} → ${shipment.receiverCity}`,
                desc: shipment.goodsType,
                status: "Recherche en cours",
                tone: "orange" as const,
                date: "Créée il y a 12 min",
              },
              {
                ref: "GL-240616-038",
                route: "Boulogne → Lille",
                desc: "Pièces détachées · 420 kg",
                status: "Transport confirmé",
                tone: "teal" as const,
                date: "Livraison demain",
              },
              {
                ref: "GL-240612-021",
                route: "Nantes → Bordeaux",
                desc: "Mobilier · 2,1 m³",
                status: "Livrée",
                tone: "muted" as const,
                date: "12 juin 2024",
              },
            ].map((item, index) => (
              <div
                key={item.ref}
                className="group flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
                data-testid={`row-expedition-${index}`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${index === 0 ? "bg-[#fff0e5] text-[#b7683c]" : "bg-[#e8f0ed] text-[#477d75]"}`}
                  >
                    <RouteIcon size={17} />
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold">{item.route}</p>
                      <StatusBadge tone={item.tone}>{item.status}</StatusBadge>
                    </div>
                    <p className="mt-1 text-xs text-[#8a9699]">
                      {item.ref} · {item.desc}
                    </p>
                  </div>
                </div>
                <p className="pl-12 text-[11px] font-semibold text-[#8a9699] sm:pl-0">
                  {item.date}
                </p>
              </div>
            ))}
          </div>
        </section>
        <section className="animate-rise animate-rise-delay-3 rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
                Votre activité
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Ce mois-ci
              </h2>
            </div>
            <Sparkles size={19} className="text-[#f4a261]" />
          </div>
          <div className="mt-8 grid grid-cols-2 gap-y-7">
            <div>
              <p className="text-3xl font-bold">15</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">expéditions créées</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                98<span className="text-lg">%</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">remises à temps</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                4,8<span className="text-lg">/5</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">satisfaction</p>
            </div>
            <div>
              <p className="text-3xl font-bold">8</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">
                transporteurs utilisés
              </p>
            </div>
          </div>
          <div className="mt-9 border-t border-white/10 pt-5">
            <p className="text-xs leading-5 text-[#b5c7c4]">
              Votre réseau s’agrandit. Les trajets réguliers peuvent être
              enregistrés pour aller plus vite.
            </p>
            <button
              className="focus-ring mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#f4a261] hover:text-[#ffc08f]"
              onClick={() =>
                window.alert(
                  "Les trajets favoris seront disponibles prochainement.",
                )
              }
              data-testid="button-decouvrir-favoris"
            >
              Découvrir les favoris <ArrowRight size={14} />
            </button>
          </div>
        </section>
      </div>
      <section className="mt-7 rounded-[1.4rem] border border-[#e0e5e0] bg-[#eef3ef] p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-[#28645e]">
              <FileText size={18} />
            </span>
            <div>
              <p className="text-sm font-extrabold">
                Besoin d’un coup de main ?
              </p>
              <p className="mt-1 text-xs text-[#71828a]">
                Notre guide explique comment préparer une expédition sans oubli.
              </p>
            </div>
          </div>
          <button
            className="focus-ring w-fit rounded-lg border border-[#bfd2cb] bg-white px-3.5 py-2.5 text-xs font-bold text-[#28645e] transition hover:bg-[#e3f0ed]"
            onClick={() =>
              window.alert("Le guide de préparation est en cours de rédaction.")
            }
            data-testid="button-guide"
          >
            Lire le guide
          </button>
        </div>
      </section>
    </div>
  );
}

function WorkspaceSectionPage({
  role,
  section,
}: {
  role: "client" | "transporter";
  section: "messages" | "profil" | "mes-transports";
}) {
  const isTransporter = role === "transporter";
  const content =
    section === "messages"
      ? {
          eyebrow: "Échanges",
          title: "Messages",
          description: isTransporter
            ? "Retrouvez les échanges liés à vos propositions et à vos transports."
            : "Retrouvez les échanges liés à vos expéditions et aux transporteurs.",
        }
      : section === "profil"
        ? {
            eyebrow: "Votre espace",
            title: "Profil",
            description: isTransporter
              ? "Gérez les informations de Transport Martin."
              : "Gérez les informations de votre entreprise et vos préférences.",
          }
        : {
            eyebrow: "Votre activité",
            title: "Mes transports",
            description:
              "Retrouvez les trajets pour lesquels vous avez envoyé une proposition.",
          };
  return (
    <div className="mx-auto max-w-[980px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise max-w-[620px]">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          {content.eyebrow}
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          {content.title}
        </h1>
        <p className="mt-3 text-sm leading-6 text-[#71828a]">
          {content.description}
        </p>
      </div>
      <section className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-6 sm:p-8">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e8f0ed] text-[#28645e]">
          {section === "messages" ? (
            <MessageCircle size={22} />
          ) : section === "profil" ? (
            <UserRound size={22} />
          ) : (
            <Truck size={22} />
          )}
        </span>
        <h2 className="display-font mt-6 text-2xl font-bold tracking-[-.035em]">
          Cette vue sera bientôt disponible.
        </h2>
        <p className="mt-3 max-w-[560px] text-sm leading-6 text-[#71828a]">
          Le prototype garde votre espace{" "}
          {isTransporter ? "transporteur" : "client"} séparé. Les
          fonctionnalités principales restent accessibles depuis votre
          navigation.
        </p>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-extrabold text-[#526579]">
        {label}
        {required ? <span className="ml-1 text-[#df8550]">*</span> : null}
      </span>
      <input
        name={name}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        type={type}
        required={required}
        className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
        data-testid={`input-${name}`}
      />
    </label>
  );
}

function ShipmentPhotoPicker({
  photos,
  onAdd,
  onRemove,
}: {
  photos: ShipmentPhoto[];
  onAdd: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemove: (photoId: string) => void;
}) {
  return (
    <section
      className="mt-6 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7"
      aria-labelledby="photos-marchandise-title"
    >
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <p
            id="photos-marchandise-title"
            className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
          >
            Photos de la marchandise
          </p>
          <p className="mt-2 text-xs leading-5 text-[#819099]">
            Ajoutez plusieurs vues pour aider le transporteur à préparer son
            trajet.
          </p>
        </div>
        <label
          className="focus-ring inline-flex w-fit cursor-pointer items-center gap-2 rounded-xl border border-[#c8d8d3] bg-[#f7fbf8] px-4 py-3 text-sm font-extrabold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-ajouter-photo"
        >
          <Plus size={16} /> Ajouter une photo
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={onAdd}
            className="sr-only"
            data-testid="input-photos"
          />
        </label>
      </div>
      {photos.length ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1]"
            >
              <img
                src={photo.url}
                alt={photo.name}
                className="aspect-[4/3] w-full object-cover"
              />
              <button
                type="button"
                onClick={() => onRemove(photo.id)}
                className="focus-ring absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-[#17344f]/85 text-white opacity-100 transition hover:bg-[#17344f] sm:opacity-0 sm:group-hover:opacity-100"
                aria-label={`Supprimer ${photo.name}`}
                data-testid={`button-supprimer-photo-${photo.id}`}
              >
                <X size={15} />
              </button>
              <p className="truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                {photo.name}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-6 flex items-center gap-3 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-xs leading-5 text-[#71828a]">
          <Package size={17} className="shrink-0 text-[#6b8f8a]" /> Aucun
          fichier ajouté pour le moment.
        </div>
      )}
    </section>
  );
}

function NewShipmentPage({
  onPublish,
}: {
  onPublish: (shipment: Shipment) => void;
}) {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Shipment>({
    reference: "GL-240618-047",
    senderAddress: "",
    senderCity: "",
    senderPostalCode: "",
    receiverAddress: "",
    receiverCity: "",
    receiverPostalCode: "",
    date: "À convenir",
    goodsType: "",
    weight: "",
    packageCount: "",
    vehicleType: "",
    offeredPrice: "",
    photos: [],
  });
  const update = (key: keyof Shipment) => (value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
  };
  const addPhotos = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []).filter((file) =>
      file.type.startsWith("image/"),
    );
    if (!files.length) return;
    const newPhotos = files.map((file, index) => ({
      id: `${file.name}-${file.lastModified}-${index}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }));
    setForm((current) => ({
      ...current,
      photos: [...current.photos, ...newPhotos],
    }));
    event.target.value = "";
  };
  const removePhoto = (photoId: string) => {
    setForm((current) => {
      const photo = current.photos.find((item) => item.id === photoId);
      if (photo) URL.revokeObjectURL(photo.url);
      return {
        ...current,
        photos: current.photos.filter((item) => item.id !== photoId),
      };
    });
  };
  const nextStep = (event: FormEvent) => {
    event.preventDefault();
    if (
      !form.senderAddress ||
      !form.senderCity ||
      !form.senderPostalCode ||
      !form.receiverAddress ||
      !form.receiverCity ||
      !form.receiverPostalCode
    ) {
      setError("Renseignez toutes les informations du trajet pour continuer.");
      return;
    }
    setError("");
    setStep(2);
  };
  const submit = () => {
    if (
      !form.goodsType ||
      !form.weight ||
      !form.packageCount ||
      !form.vehicleType ||
      !form.offeredPrice
    ) {
      setError("Complétez les informations de la cargaison avant de publier.");
      return;
    }
    onPublish({
      ...form,
      weight: `${form.weight} kg`,
      offeredPrice: `${form.offeredPrice} €`,
    });
    setLocation("/expedition-publiee");
  };
  return (
    <div className="mx-auto max-w-[1020px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise">
        <Link
          href="/tableau-de-bord"
          className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
          data-testid="link-retour-dashboard"
        >
          <ArrowLeft size={14} /> Retour au tableau de bord
        </Link>
        <div className="mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              Nouvelle expédition
            </p>
            <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
              Préparons votre trajet.
            </h1>
            <p className="mt-2 text-sm text-[#71828a]">
              Décrivez votre besoin en deux étapes simples.
            </p>
          </div>
          <span className="mono-font text-xs text-[#71828a]">
            Réf. {form.reference}
          </span>
        </div>
      </div>
      <div className="mt-9 grid gap-8 lg:grid-cols-[1fr_280px]">
        <div>
          <div className="mb-7 flex items-center gap-2 sm:gap-4">
            {["Le trajet", "La cargaison"].map((label, index) => {
              const number = index + 1;
              return (
                <div
                  key={label}
                  className="flex flex-1 items-center gap-2 sm:gap-3"
                >
                  <span
                    className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-extrabold ${step >= number ? "bg-[#17344f] text-[#f7f5ef]" : "border border-[#d4dfda] bg-white text-[#9aa8aa]"}`}
                  >
                    {step > number ? <Check size={15} /> : number}
                  </span>
                  <span
                    className={`hidden text-xs font-bold sm:block ${step >= number ? "text-[#17344f]" : "text-[#9aa8aa]"}`}
                  >
                    {label}
                  </span>
                  {number < 2 ? (
                    <span
                      className={`h-px flex-1 ${step > number ? "bg-[#6da99d]" : "bg-[#dce3df]"}`}
                    />
                  ) : null}
                </div>
              );
            })}
          </div>
          <form
            onSubmit={nextStep}
            className="rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
            data-testid="form-nouvelle-expedition"
          >
            {step === 1 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
                    <RouteIcon size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">Le trajet</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Indiquez les deux points de votre expédition.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-8 md:grid-cols-2">
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de collecte
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de collecte"
                        name="adresse-collecte"
                        value={form.senderAddress}
                        onChange={update("senderAddress")}
                        placeholder="Ex. 18 rue de Charonne"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-collecte"
                        value={form.senderCity}
                        onChange={update("senderCity")}
                        placeholder="Ex. Paris"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-collecte"
                        value={form.senderPostalCode}
                        onChange={update("senderPostalCode")}
                        placeholder="Ex. 75011"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de livraison
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de livraison"
                        name="adresse-livraison"
                        value={form.receiverAddress}
                        onChange={update("receiverAddress")}
                        placeholder="Ex. 7 rue Mercière"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-livraison"
                        value={form.receiverCity}
                        onChange={update("receiverCity")}
                        placeholder="Ex. Lyon"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-livraison"
                        value={form.receiverPostalCode}
                        onChange={update("receiverPostalCode")}
                        placeholder="Ex. 69002"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
            {step === 2 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
                    <Box size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">La cargaison</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Donnez aux transporteurs les informations utiles pour
                      répondre.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-5 md:grid-cols-2">
                  <Field
                    label="Type de marchandise"
                    name="type-marchandise"
                    value={form.goodsType}
                    onChange={update("goodsType")}
                    placeholder="Ex. Mobilier professionnel"
                    required
                  />
                  <Field
                    label="Poids en kg"
                    name="poids"
                    value={form.weight}
                    onChange={update("weight")}
                    placeholder="Ex. 180"
                    type="number"
                    required
                  />
                  <Field
                    label="Nombre de colis"
                    name="nombre-colis"
                    value={form.packageCount}
                    onChange={update("packageCount")}
                    placeholder="Ex. 3"
                    type="number"
                    required
                  />
                  <label className="block">
                    <span className="mb-2 block text-xs font-extrabold text-[#526579]">
                      Type de véhicule
                      <span className="ml-1 text-[#df8550]">*</span>
                    </span>
                    <select
                      name="type-vehicule"
                      value={form.vehicleType}
                      onChange={(event) =>
                        update("vehicleType")(event.target.value)
                      }
                      required
                      className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition focus:border-[#6da99d] focus:bg-white"
                      data-testid="select-type-vehicule"
                    >
                      <option value="">Sélectionnez un véhicule</option>
                      <option>Fourgon</option>
                      <option>Camion porteur</option>
                      <option>Poids lourd</option>
                      <option>Véhicule avec hayon</option>
                    </select>
                  </label>
                  <Field
                    label="Prix proposé en €"
                    name="prix-propose"
                    value={form.offeredPrice}
                    onChange={update("offeredPrice")}
                    placeholder="Ex. 420"
                    type="number"
                    required
                  />
                </div>
                <div className="mt-6 flex items-start gap-2 rounded-xl bg-[#f1f5f1] p-3 text-xs leading-5 text-[#71828a]">
                  <Info size={15} className="mt-0.5 shrink-0 text-[#6b8f8a]" />{" "}
                  Votre prix proposé sera visible par les transporteurs
                  intéressés par ce trajet.
                </div>
              </div>
            ) : null}
            {error ? (
              <p
                className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
                role="alert"
                data-testid="text-form-error"
              >
                {error}
              </p>
            ) : null}
            <div className="mt-8 flex flex-col-reverse justify-between gap-3 border-t border-[#edf0eb] pt-6 sm:flex-row sm:items-center">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    setError("");
                    setStep(1);
                  }}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-bold text-[#71828a] transition hover:bg-[#f1f4f0] hover:text-[#17344f]"
                  data-testid="button-etape-precedente"
                >
                  <ArrowLeft size={16} /> Étape précédente
                </button>
              ) : (
                <span className="hidden sm:block text-xs text-[#98a4a6]">
                  * Champs obligatoires
                </span>
              )}
              {step === 1 ? (
                <button
                  type="submit"
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                  data-testid="button-continuer"
                >
                  Continuer <ArrowRight size={16} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={submit}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
                  data-testid="button-publier-cargaison"
                >
                  Publier la cargaison <ArrowRight size={16} />
                </button>
              )}
            </div>
          </form>
          {step === 2 ? (
            <ShipmentPhotoPicker
              photos={form.photos}
              onAdd={addPhotos}
              onRemove={removePhoto}
            />
          ) : null}
        </div>
        <aside className="hidden lg:block">
          <div className="sticky top-[105px] rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Bon à savoir
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Vous gardez le cap.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Votre annonce reste modifiable jusqu’à sa publication.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <MapPin size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Un trajet précis aide à obtenir des propositions adaptées.
                </p>
              </div>
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Les transporteurs voient les informations nécessaires avant de
                  répondre.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ShipmentPhotosSection({ photos }: { photos: ShipmentPhoto[] }) {
  const [selectedPhoto, setSelectedPhoto] = useState<ShipmentPhoto | null>(
    null,
  );

  return (
    <>
      <section
        className="border-t border-[#edf0eb] px-5 py-6 sm:px-7"
        aria-labelledby="photos-cargaison-title"
      >
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
            <Package size={18} />
          </span>
          <div>
            <p
              id="photos-cargaison-title"
              className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
            >
              Photos de la marchandise
            </p>
            <p className="mt-2 text-xs text-[#819099]">
              Consultez les photos ajoutées par le client avant de répondre.
            </p>
          </div>
        </div>
        {photos.length ? (
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {photos.map((photo) => (
              <button
                type="button"
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="focus-ring group overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1] text-left"
                aria-label={`Agrandir ${photo.name}`}
                data-testid={`button-agrandir-photo-${photo.id}`}
              >
                <img
                  src={photo.url}
                  alt={photo.name}
                  className="aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-[1.03]"
                />
                <span className="block truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                  {photo.name}
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div
            className="mt-5 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-sm font-semibold text-[#71828a]"
            data-testid="text-aucune-photo"
          >
            Aucune photo disponible
          </div>
        )}
      </section>
      {selectedPhoto ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#10263a]/80 p-5 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo agrandie : ${selectedPhoto.name}`}
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelectedPhoto(null);
          }}
        >
          <div className="relative max-h-[90vh] max-w-[min(900px,calc(100vw-2.5rem))] overflow-hidden rounded-2xl bg-white p-2 shadow-2xl">
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="focus-ring absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-[#17344f]/90 text-white transition hover:bg-[#17344f]"
              aria-label="Fermer la photo agrandie"
              data-testid="button-fermer-photo"
            >
              <X size={18} />
            </button>
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.name}
              className="max-h-[82vh] max-w-full rounded-xl object-contain"
            />
            <p className="px-2 pb-1 pt-2 text-xs font-semibold text-[#526579]">
              {selectedPhoto.name}
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}

function PublishedPage({ shipment }: { shipment: Shipment }) {
  const [, setLocation] = useLocation();
  return (
    <div className="mx-auto max-w-[980px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[720px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Expédition publiée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre expédition a été publiée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[540px] text-base leading-7 text-[#71828a]">
          Votre cargaison est maintenant visible par les transporteurs
          intéressés par ce trajet.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[820px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="flex flex-col justify-between gap-3 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Résumé de l’expédition
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.reference}</p>
          </div>
          <StatusBadge>Recherche de transporteur</StatusBadge>
        </div>
        <div className="grid gap-0 sm:grid-cols-[1fr_80px_1fr] sm:items-center">
          <div className="p-6 sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Collecte
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.senderCity} · {shipment.senderPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.senderAddress}
            </p>
          </div>
          <div className="hidden justify-center sm:flex">
            <div className="h-px w-10 bg-[#b9d2cc]" />
            <Truck size={18} className="mx-[-4px] text-[#df8550]" />
            <div className="h-px w-10 bg-[#b9d2cc]" />
          </div>
          <div className="border-t border-[#edf0eb] p-6 sm:border-t-0 sm:border-l sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Livraison
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.receiverCity} · {shipment.receiverPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.receiverAddress}
            </p>
          </div>
        </div>
        <div className="grid gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] p-5 sm:grid-cols-4 sm:px-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Marchandise
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.goodsType}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Poids
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.weight}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Colis
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.packageCount}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.offeredPrice}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
          <Truck size={15} className="text-[#6b8f8a]" /> Véhicule souhaité :{" "}
          <strong>{shipment.vehicleType}</strong>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[760px] gap-3 sm:grid-cols-2">
        <button
          onClick={() => setLocation("/tableau-de-bord")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-voir-tableau"
        >
          Voir mon tableau de bord <ArrowRight size={16} />
        </button>
        <button
          onClick={() => setLocation("/nouvelle-expedition")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-nouvelle-apres-publication"
        >
          <Plus size={16} /> Créer une autre expédition
        </button>
      </div>
      <div className="mx-auto mt-12 flex max-w-[600px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4">
        <Clock3 size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
        <p className="text-xs leading-5 text-[#71828a]">
          <strong className="text-[#526579]">Et maintenant ?</strong> Les
          transporteurs intéressés peuvent consulter votre annonce. Consultez
          votre tableau de bord pour suivre les réponses.
        </p>
      </div>
    </div>
  );
}

function TransporterDashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1240px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Espace transporteur · Aujourd’hui
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Thomas<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Des trajets qui correspondent à votre activité.
          </p>
        </div>
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-2 text-xs font-bold text-[#28645e]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" /> Profil
          transporteur actif
        </span>
      </div>

      <section className="animate-rise animate-rise-delay-1 mt-10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              À saisir
            </p>
            <h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em] sm:text-3xl">
              Cargaisons disponibles
            </h2>
            <p className="mt-2 max-w-[560px] text-sm leading-6 text-[#71828a]">
              Découvrez les expéditions à proximité et proposez un transport
              adapté.
            </p>
          </div>
          <span className="text-xs font-bold text-[#819099]">
            1 nouvelle cargaison
          </span>
        </div>

        <div className="mt-7 grid gap-6 xl:grid-cols-[1fr_280px]">
          <article className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
            <div className="flex flex-col justify-between gap-4 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge tone="orange">Nouvelle</StatusBadge>
                  <span className="mono-font text-[10px] tracking-[.12em] text-[#819099]">
                    {shipment.reference}
                  </span>
                </div>
                <p className="display-font mt-3 text-2xl font-bold tracking-[-.04em]">
                  {shipment.senderCity}{" "}
                  <span className="text-[#df8550]">→</span>{" "}
                  {shipment.receiverCity}
                </p>
              </div>
              <Link
                href="/transporteur/cargaison"
                className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#17344f] px-4 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                data-testid="button-voir-cargaison"
              >
                Voir la cargaison <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid gap-0 sm:grid-cols-2 lg:grid-cols-4">
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Date
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.date}</p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 lg:border-b-0 lg:border-r">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Marchandise
                </p>
                <p className="mt-2 text-sm font-extrabold">
                  {shipment.goodsType}
                </p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Poids
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.weight}</p>
              </div>
              <div className="p-5">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Prix proposé
                </p>
                <p className="mt-2 text-sm font-extrabold text-[#b7683c]">
                  {formatEuro(shipment.offeredPrice)}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
              <span className="flex items-center gap-2">
                <Truck size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.vehicleType}
              </span>
              <span className="flex items-center gap-2">
                <Box size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.packageCount} colis
              </span>
              <span className="flex items-center gap-2">
                <MapPin size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.senderPostalCode} → {shipment.receiverPostalCode}
              </span>
            </div>
          </article>

          <aside className="rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Votre activité
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Roulez utile.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Les cargaisons sont présentées avec les informations essentielles
              pour décider rapidement.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Des annonces structurées, sans détour.
                </p>
              </div>
              <div className="flex gap-3">
                <RouteIcon size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Une route claire avant de prendre la route.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function ShipmentDetailsPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1000px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/tableau-de-bord"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-cargaisons"
      >
        <ArrowLeft size={14} /> Retour aux cargaisons
      </Link>
      <div className="animate-rise mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Détail de la cargaison
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            {shipment.senderCity} <span className="text-[#df8550]">→</span>{" "}
            {shipment.receiverCity}
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Réf. {shipment.reference} · {shipment.date}
          </p>
        </div>
        <StatusBadge tone="orange">Recherche de transporteur</StatusBadge>
      </div>
      <div className="mt-9 grid gap-6 lg:grid-cols-[1fr_280px]">
        <section className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
          <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Informations du trajet
            </p>
            <p className="mt-2 text-sm font-extrabold">
              De la collecte à la livraison
            </p>
          </div>
          <div className="grid gap-0 sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de collecte
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.senderAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.senderCity} · {shipment.senderPostalCode}
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de livraison
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.receiverAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.receiverCity} · {shipment.receiverPostalCode}
              </p>
            </div>
          </div>
          <div className="grid gap-0 border-t border-[#edf0eb] sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Marchandise
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.goodsType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.weight} · {shipment.packageCount} colis
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Transport
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.vehicleType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                Date : {shipment.date}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] px-6 py-5 sm:px-7">
            <span className="text-sm font-bold text-[#526579]">
              Prix proposé par le client
            </span>
            <span className="display-font text-xl font-bold text-[#b7683c]">
              {formatEuro(shipment.offeredPrice)}
            </span>
          </div>
          <ShipmentPhotosSection photos={shipment.photos} />
        </section>
        <aside className="h-fit rounded-[1.4rem] border border-[#dfe7e2] bg-[#eef3ef] p-6">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre réponse
          </p>
          <h2 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
            Le trajet vous convient ?
          </h2>
          <p className="mt-3 text-xs leading-5 text-[#71828a]">
            Envoyez votre prix et un message au client pour vous positionner sur
            cette cargaison.
          </p>
          <Link
            href="/transporteur/proposition"
            className="focus-ring mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#df8550] px-4 py-3.5 text-sm font-extrabold text-[#17344f] transition hover:bg-[#eb9863]"
            data-testid="button-faire-proposition"
          >
            Faire une proposition <ArrowRight size={16} />
          </Link>
        </aside>
      </div>
    </div>
  );
}

function TransporterProposalPage({
  shipment,
  onSend,
}: {
  shipment: Shipment;
  onSend: (proposal: Proposal) => void;
}) {
  const [, setLocation] = useLocation();
  const [proposal, setProposal] = useState<Proposal>({
    price: "",
    message: "",
  });
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!proposal.price || !proposal.message) {
      setError("Renseignez votre prix et votre message avant d’envoyer.");
      return;
    }
    onSend({ ...proposal, price: `${proposal.price} €` });
    setLocation("/transporteur/proposition-envoyee");
  };
  return (
    <div className="mx-auto max-w-[820px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/cargaison"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-detail-cargaison"
      >
        <ArrowLeft size={14} /> Retour à la cargaison
      </Link>
      <div className="animate-rise mt-7">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Votre proposition
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          Faites avancer le trajet.
        </h1>
        <p className="mt-2 text-sm text-[#71828a]">
          {shipment.senderCity} → {shipment.receiverCity} · {shipment.goodsType}
        </p>
      </div>
      <form
        onSubmit={submit}
        className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
        data-testid="form-proposition"
      >
        <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
            <FileText size={18} />
          </span>
          <div>
            <h2 className="text-base font-extrabold">Répondez au client</h2>
            <p className="mt-1 text-xs text-[#819099]">
              Un prix clair et un message précis font la différence.
            </p>
          </div>
        </div>
        <div className="mt-7 space-y-5">
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Prix proposé par le client
            </span>
            <input
              value={formatEuro(shipment.offeredPrice)}
              readOnly
              className="h-12 w-full cursor-default rounded-xl border border-[#d8e0dc] bg-[#f1f5f1] px-3.5 text-sm font-bold text-[#71828a] outline-none"
              data-testid="input-prix-client"
            />
          </label>
          <Field
            label="Votre prix"
            name="votre-prix"
            value={proposal.price}
            onChange={(value) => {
              setProposal((current) => ({ ...current, price: value }));
              setError("");
            }}
            placeholder="Ex. 390"
            type="number"
            required
          />
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Message<span className="ml-1 text-[#df8550]">*</span>
            </span>
            <textarea
              name="message"
              value={proposal.message}
              onChange={(event) => {
                setProposal((current) => ({
                  ...current,
                  message: event.target.value,
                }));
                setError("");
              }}
              placeholder="Présentez votre disponibilité et vos conditions de transport…"
              className="focus-ring min-h-[140px] w-full resize-y rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 py-3 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
              data-testid="input-message"
            />
          </label>
        </div>
        {error ? (
          <p
            className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
            role="alert"
            data-testid="text-proposition-error"
          >
            {error}
          </p>
        ) : null}
        <div className="mt-8 flex justify-end border-t border-[#edf0eb] pt-6">
          <button
            type="submit"
            className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3.5 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
            data-testid="button-envoyer-proposition"
          >
            Envoyer la proposition <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </div>
  );
}

function ProposalSentPage({
  shipment,
  proposal,
}: {
  shipment: Shipment;
  proposal: Proposal;
}) {
  return (
    <div className="mx-auto max-w-[900px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[700px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Proposition envoyée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre proposition a été envoyée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[520px] text-base leading-7 text-[#71828a]">
          Le client pourra consulter votre offre et revenir vers vous au sujet
          de cette cargaison.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[720px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre offre
          </p>
          <p className="mt-1 text-sm font-extrabold">
            {shipment.senderCity} → {shipment.receiverCity} ·{" "}
            {shipment.reference}
          </p>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé par le client
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#71828a]">
              {formatEuro(shipment.offeredPrice)}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Votre prix
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#b7683c]">
              {proposal.price}
            </p>
          </div>
          <div className="sm:col-span-2">
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Message envoyé
            </p>
            <p className="mt-2 rounded-xl bg-[#fcfdfa] p-4 text-sm leading-6 text-[#526579]">
              {proposal.message}
            </p>
          </div>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[720px] gap-3 sm:grid-cols-2">
        <Link
          href="/transporteur/tableau-de-bord"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-retour-cargaisons"
        >
          Voir les cargaisons disponibles <ArrowRight size={16} />
        </Link>
        <Link
          href="/transporteur/cargaison"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-revoir-cargaison"
        >
          Revoir la cargaison <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}

function Router() {
  const [publishedShipment, setPublishedShipment] =
    useState<Shipment>(starterShipment);
  const [sentProposal, setSentProposal] = useState<Proposal>({
    price: "390 €",
    message:
      "Disponible pour ce trajet avec un fourgon équipé. Je peux prendre en charge les trois colis dans le créneau indiqué.",
  });
  return (
    <AppShell>
      <Switch>
        <Route path="/" component={WelcomePage} />
        <Route path="/choisir-profil" component={ProfilePage} />
        <Route path="/tableau-de-bord">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/mes-expeditions">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/nouvelle-expedition">
          <NewShipmentPage onPublish={setPublishedShipment} />
        </Route>
        <Route path="/expedition-publiee">
          <PublishedPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/tableau-de-bord">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/cargaisons">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/messages">
          <WorkspaceSectionPage role="client" section="messages" />
        </Route>
        <Route path="/profil">
          <WorkspaceSectionPage role="client" section="profil" />
        </Route>
        <Route path="/transporteur/mes-transports">
          <WorkspaceSectionPage role="transporter" section="mes-transports" />
        </Route>
        <Route path="/transporteur/messages">
          <WorkspaceSectionPage role="transporter" section="messages" />
        </Route>
        <Route path="/transporteur/profil">
          <WorkspaceSectionPage role="transporter" section="profil" />
        </Route>
        <Route path="/transporteur/cargaison">
          <ShipmentDetailsPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/proposition">
          <TransporterProposalPage
            shipment={publishedShipment}
            onSend={setSentProposal}
          />
        </Route>
        <Route path="/transporteur/proposition-envoyee">
          <ProposalSentPage
            shipment={publishedShipment}
            proposal={sentProposal}
          />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedErrorBoundary>
            <Router />
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
import {
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
  useState,
} from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  House,
  Info,
  MapPin,
  MessageCircle,
  Menu,
  Package,
  Plus,
  Route as RouteIcon,
  ShieldCheck,
  Sparkles,
  Truck,
  UserRound,
  X,
} from "lucide-react";
import {
  Link,
  Route,
  Switch,
  Router as WouterRouter,
  useLocation,
} from "wouter";

const queryClient = new QueryClient();

type Shipment = {
  id: string;
  reference: string;
  customerName: string;
  customerCompany: string;
  senderAddress: string;
  senderCity: string;
  senderPostalCode: string;
  receiverAddress: string;
  receiverCity: string;
  receiverPostalCode: string;
  date: string;
  pickupDate: string;
  deliveryDate: string;
  goodsType: string;
  weight: string;
  packageCount: string;
  vehicleType: string;
  offeredPrice: string;
  photos: ShipmentPhoto[];
  status: ShipmentStatus;
  transporterName?: string;
  transporterCompany?: string;
};

type ShipmentPhoto = {
  id: string;
  name: string;
  url: string;
};

type Proposal = {
  id: string;
  shipmentId: string;
  transporterName: string;
  transporterCompany: string;
  price: string;
  message: string;
  status: ProposalStatus;
};

type ShipmentStatus =
  | "Recherche de transporteur"
  | "Transporteur confirmé"
  | "En collecte"
  | "En transit"
  | "Livré";
type ProposalStatus = "En attente" | "Acceptée" | "Refusée";

const starterShipment: Shipment = {
  id: "shipment-starter-047",
  reference: "GL-240618-047",
  customerName: "Claire Renaud",
  customerCompany: "Atelier Rivoli",
  senderAddress: "18 rue de Charonne",
  senderCity: "Paris 11e",
  senderPostalCode: "75011",
  receiverAddress: "7 rue Mercière",
  receiverCity: "Lyon 2e",
  receiverPostalCode: "69002",
  date: "18 juin 2024",
  pickupDate: "18 juin 2024",
  deliveryDate: "19 juin 2024",
  goodsType: "Mobilier professionnel",
  weight: "180 kg",
  packageCount: "3",
  vehicleType: "Fourgon",
  offeredPrice: "420",
  photos: [],
  status: "Recherche de transporteur",
};

function createId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function BrandMark({ dark = false }: { dark?: boolean }) {
  return (
    <Link
      href="/"
      className="focus-ring inline-flex items-center gap-3"
      data-testid="link-brand-home"
    >
      <span
        className={`relative grid h-10 w-10 place-items-center rounded-xl ${dark ? "bg-[#f4a261] text-[#14263a]" : "bg-[#17344f] text-[#f8f4ea]"}`}
      >
        <span className="absolute left-[9px] top-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span className="absolute bottom-[9px] right-[9px] h-2.5 w-2.5 rounded-full bg-current" />
        <span
          className={`absolute h-[2px] w-5 rotate-45 ${dark ? "bg-[#14263a]" : "bg-[#f4a261]"}`}
        />
      </span>
      <span
        className={`display-font text-[1.45rem] font-bold tracking-[-.05em] ${dark ? "text-[#f8f4ea]" : "text-[#17344f]"}`}
      >
        GoLink <span className="text-[#df8550]">France</span>
      </span>
    </Link>
  );
}

function IconButton({
  label,
  children,
  onClick,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white/70 text-[#526579] transition hover:border-[#9cbbba] hover:bg-[#e7f0ee] hover:text-[#17344f]"
      data-testid={`button-${label.toLowerCase().replaceAll(" ", "-")}`}
    >
      {children}
    </button>
  );
}

function StatusBadge({
  children,
  tone = "teal",
}: {
  children: ReactNode;
  tone?: "teal" | "orange" | "muted";
}) {
  const classes =
    tone === "orange"
      ? "bg-[#fff0e5] text-[#a9582d]"
      : tone === "muted"
        ? "bg-[#eef0ef] text-[#63727e]"
        : "bg-[#e3f0ed] text-[#28645e]";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${classes}`}
      data-testid="status-badge"
    >
      {tone === "teal" ? (
        <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />
      ) : null}
      {children}
    </span>
  );
}

function formatEuro(value: string) {
  return value.includes("€") ? value : `${value} €`;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTransporter = location.startsWith("/transporteur/");
  const isDashboard =
    isTransporter ||
    [
      "/tableau-de-bord",
      "/mes-expeditions",
      "/nouvelle-expedition",
      "/expedition-publiee",
      "/messages",
      "/profil",
    ].includes(location);
  if (!isDashboard) return <>{children}</>;

  const nav = isTransporter
    ? [
        {
          href: "/transporteur/tableau-de-bord",
          label: "Accueil",
          icon: House,
        },
        { href: "/transporteur/cargaisons", label: "Cargaisons", icon: Box },
        {
          href: "/transporteur/mes-transports",
          label: "Mes transports",
          icon: Truck,
        },
        {
          href: "/transporteur/messages",
          label: "Messages",
          icon: MessageCircle,
        },
        { href: "/transporteur/profil", label: "Profil", icon: UserRound },
      ]
    : [
        { href: "/tableau-de-bord", label: "Accueil", icon: House },
        { href: "/mes-expeditions", label: "Mes expéditions", icon: Package },
        {
          href: "/nouvelle-expedition",
          label: "Créer une expédition",
          icon: Plus,
        },
        { href: "/messages", label: "Messages", icon: MessageCircle },
        { href: "/profil", label: "Profil", icon: UserRound },
      ];
  const sectionTitle = isTransporter
    ? location === "/transporteur/cargaison"
      ? "Détail de la cargaison"
      : location === "/transporteur/proposition"
        ? "Faire une proposition"
        : location === "/transporteur/proposition-envoyee"
          ? "Proposition envoyée"
          : (nav.find((item) => item.href === location)?.label ?? "Accueil")
    : location === "/nouvelle-expedition"
      ? "Créer une expédition"
      : location === "/expedition-publiee"
        ? "Expédition publiée"
        : (nav.find((item) => item.href === location)?.label ?? "Accueil");

  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[250px] flex-col bg-[#17344f] px-5 py-6 text-[#f7f5ef] lg:flex">
        <BrandMark dark />
        <div className="mt-12">
          <p className="mono-font mb-4 px-3 text-[10px] uppercase tracking-[.16em] text-[#96b5b5]">
            {isTransporter ? "Espace transporteur" : "Espace client"}
          </p>
          <nav className="space-y-1.5">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition ${active ? "bg-[#e0efeb] text-[#17344f]" : "text-[#b9c9c9] hover:bg-[#25445f] hover:text-white"}`}
                  data-testid={`link-nav-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  <Icon size={17} strokeWidth={active ? 2.5 : 1.8} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.07] p-4">
          <ShieldCheck size={19} className="text-[#8bc2b6]" />
          <p className="mt-3 text-sm font-bold">
            {isTransporter
              ? "Des trajets bien choisis."
              : "Vos envois, bien cadrés."}
          </p>
          <p className="mt-1 text-xs leading-5 text-[#a8bcbc]">
            {isTransporter
              ? "Trouvez les cargaisons qui correspondent à votre activité."
              : "Chaque étape est documentée et visible par votre équipe."}
          </p>
        </div>
        <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-5">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#f4a261] text-xs font-extrabold text-[#17344f]">
            {isTransporter ? "TM" : "CR"}
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-bold">
              {isTransporter ? "Thomas Martin" : "Claire Renaud"}
            </p>
            <p className="truncate text-[11px] text-[#a8bcbc]">
              {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
            </p>
          </div>
          <ChevronDown size={14} className="ml-auto text-[#a8bcbc]" />
        </div>
      </aside>

      <div className="lg:pl-[250px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#e1e3de] bg-[#f7f5ef]/90 px-5 backdrop-blur-md sm:px-8">
          <div className="flex items-center gap-3">
            <button
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl border border-[#d8dfdf] bg-white text-[#17344f] lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Ouvrir le menu"
              data-testid="button-open-menu"
            >
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
            <div className="lg:hidden">
              <BrandMark />
            </div>
            <span className="hidden text-sm text-[#7b8a92] sm:block">
              {sectionTitle}
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <IconButton label="Aide">
              <CircleHelp size={18} />
            </IconButton>
            <IconButton label="Notifications">
              <Bell size={18} />
            </IconButton>
            <span className="hidden h-6 w-px bg-[#d8dfdf] sm:block" />
            <span className="grid h-9 w-9 place-items-center rounded-full bg-[#d8e9e6] text-xs font-extrabold text-[#28645e] sm:hidden">
              {isTransporter ? "TM" : "CR"}
            </span>
            <span className="hidden text-right sm:block">
              <span className="block text-xs font-bold">
                {isTransporter ? "Thomas Martin" : "Claire Renaud"}
              </span>
              <span className="block text-[11px] text-[#819099]">
                {isTransporter ? "Transport Martin" : "Atelier Rivoli"}
              </span>
            </span>
          </div>
        </header>
        {mobileOpen ? (
          <div className="fixed inset-x-0 top-[76px] z-20 border-b border-[#dfe5e1] bg-[#f7f5ef] p-4 shadow-lg lg:hidden">
            <nav className="grid gap-2">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="focus-ring rounded-xl bg-white px-4 py-3 text-sm font-bold text-[#17344f]"
                  data-testid={`link-mobile-${item.label.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        ) : null}
        <main>{children}</main>
      </div>
    </div>
  );
}

function RouteDiagram() {
  return (
    <div className="relative h-[310px] overflow-hidden rounded-[2rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:h-[360px] sm:p-10">
      <div className="absolute inset-0 opacity-20 page-grid" />
      <div className="absolute -right-20 -top-16 h-64 w-64 rounded-full border border-[#9cc6bd]/30" />
      <div className="absolute -right-8 top-0 h-48 w-48 rounded-full border border-[#9cc6bd]/20" />
      <div className="absolute bottom-8 left-1/2 h-[1px] w-[72%] -translate-x-1/2 rotate-[22deg] bg-[#f4a261]/60 sm:w-[66%]" />
      <div className="absolute bottom-[102px] left-[21%] h-3 w-3 rounded-full bg-[#f4a261] ring-8 ring-[#f4a261]/15 sm:left-[24%]" />
      <div className="absolute right-[18%] top-[88px] h-3 w-3 rounded-full bg-[#9cc6bd] ring-8 ring-[#9cc6bd]/15 sm:right-[23%]" />
      <div className="absolute bottom-[64px] left-[17%] sm:left-[20%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Départ
        </p>
        <p className="mt-1 text-sm font-bold">Paris 11e</p>
      </div>
      <div className="absolute right-[10%] top-[48px] text-right sm:right-[15%]">
        <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
          Arrivée
        </p>
        <p className="mt-1 text-sm font-bold">Lyon 2e</p>
      </div>
      <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between sm:bottom-8 sm:left-10 sm:right-10">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Distance estimée
          </p>
          <p className="display-font mt-1 text-2xl font-bold">465 km</p>
        </div>
        <Truck
          className="route-pulse text-[#f4a261]"
          size={34}
          strokeWidth={1.3}
        />
        <div className="text-right">
          <p className="mono-font text-[10px] uppercase tracking-[.16em] text-[#a9c4c0]">
            Délai cible
          </p>
          <p className="display-font mt-1 text-2xl font-bold">J + 1</p>
        </div>
      </div>
    </div>
  );
}

function WelcomePage() {
  return (
    <div className="noise-overlay min-h-[100dvh] overflow-hidden bg-[#f7f5ef] text-[#17344f]">
      <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <span className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
          Le transport, côté confiance
        </span>
      </header>
      <main>
        <section className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 pb-20 pt-10 sm:px-8 md:grid-cols-[1.03fr_.97fr] md:gap-10 md:pb-28 md:pt-20">
          <div className="relative z-10">
            <div
              className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.11em] text-[#28645e]"
              data-testid="status-hero"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" />{" "}
              Transport professionnel, simplement
            </div>
            <h1 className="display-font animate-rise animate-rise-delay-1 mt-7 max-w-[660px] text-[3.45rem] font-bold leading-[.98] tracking-[-.065em] text-[#17344f] sm:text-[5.2rem] lg:text-[6.1rem]">
              Votre colis.
              <br />
              <span className="text-[#df8550]">Notre trajet.</span>
            </h1>
            <p className="animate-rise animate-rise-delay-2 mt-7 max-w-[500px] text-base leading-7 text-[#5d707a] sm:text-lg">
              GoLink France coordonne vos expéditions avec des transporteurs
              vérifiés, pour que chaque livraison avance avec clarté.
            </p>
            <div className="animate-rise animate-rise-delay-3 mt-9 grid gap-3 sm:grid-cols-2">
              <Link
                href="/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl bg-[#df8550] px-4 py-4 text-left text-[#17344f] shadow-[0_12px_26px_rgba(223,133,80,.22)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
                data-testid="link-choix-expediteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  📦
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je veux expédier
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#5d4b3d]">
                    Je cherche un transporteur
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="transition group-hover:translate-x-1"
                />
              </Link>
              <Link
                href="/transporteur/tableau-de-bord"
                className="focus-ring group flex items-center gap-3 rounded-2xl border border-[#cad8d5] bg-white/70 px-4 py-4 text-left text-[#17344f] transition hover:-translate-y-0.5 hover:border-[#9abdb4] hover:bg-[#e8f1ed]"
                data-testid="link-choix-transporteur"
              >
                <span className="text-2xl" aria-hidden="true">
                  🚛
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-extrabold">
                    Je suis transporteur
                  </span>
                  <span className="mt-1 block text-xs font-semibold text-[#71828a]">
                    Je cherche des cargaisons
                  </span>
                </span>
                <ArrowRight
                  size={17}
                  className="text-[#28645e] transition group-hover:translate-x-1"
                />
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap items-center gap-x-7 gap-y-3 text-xs font-semibold text-[#71828a]">
              <span className="flex items-center gap-2">
                <BadgeCheck size={16} className="text-[#4f9e91]" />{" "}
                Transporteurs vérifiés
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#4f9e91]" /> Suivi à
                chaque étape
              </span>
            </div>
          </div>
          <div className="animate-rise animate-rise-delay-2 relative md:pl-6">
            <div className="absolute -right-8 -top-7 hidden h-36 w-36 rounded-full border border-[#d2a17f]/50 md:block" />
            <RouteDiagram />
            <div className="card-shadow absolute -bottom-7 left-5 flex w-[calc(100%-40px)] items-center gap-3 rounded-2xl border border-[#e1e9e5] bg-white p-4 sm:left-10 sm:w-auto sm:min-w-[290px]">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e3f0ed] text-[#28645e]">
                <Check size={20} strokeWidth={2.5} />
              </span>
              <div>
                <p className="text-xs font-extrabold text-[#17344f]">
                  Une livraison qui se précise
                </p>
                <p className="mt-1 text-[11px] text-[#819099]">
                  Notification envoyée au destinataire
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="border-y border-[#e1e3de] bg-[#eef2ec]">
          <div className="mx-auto grid max-w-[1240px] gap-8 px-5 py-14 sm:px-8 md:grid-cols-[.85fr_1.15fr] md:items-center md:gap-16 md:py-20">
            <div>
              <p className="mono-font text-[10px] font-medium uppercase tracking-[.16em] text-[#6b8f8a]">
                Pensé pour le terrain
              </p>
              <h2 className="display-font mt-4 text-3xl font-bold tracking-[-.04em] text-[#17344f] sm:text-4xl">
                La logistique, sans la zone grise.
              </h2>
            </div>
            <div className="grid gap-7 sm:grid-cols-3">
              <div>
                <span className="mono-font text-2xl text-[#df8550]">01</span>
                <h3 className="mt-3 text-sm font-extrabold">Décrivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Votre besoin est cadré en quelques minutes.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">02</span>
                <h3 className="mt-3 text-sm font-extrabold">Choisissez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Des professionnels adaptés à votre trajet.
                </p>
              </div>
              <div>
                <span className="mono-font text-2xl text-[#df8550]">03</span>
                <h3 className="mt-3 text-sm font-extrabold">Suivez</h3>
                <p className="mt-2 text-sm leading-6 text-[#697a80]">
                  Une livraison documentée, jusqu’à la remise.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="mx-auto flex max-w-[1240px] flex-col justify-between gap-6 px-5 py-14 sm:flex-row sm:items-center sm:px-8 sm:py-16">
          <div>
            <p className="display-font text-xl font-bold tracking-[-.03em]">
              Une route plus lisible commence ici.
            </p>
            <p className="mt-2 text-sm text-[#71828a]">
              Expédiez ou transportez avec un espace conçu pour votre activité.
            </p>
          </div>
        </section>
      </main>
      <footer className="border-t border-[#e1e3de] px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-3 text-xs text-[#819099] sm:flex-row">
          <span>© 2024 GoLink France</span>
          <span>Le transport, côté confiance.</span>
        </div>
      </footer>
    </div>
  );
}

function ProfilePage() {
  const [hovered, setHovered] = useState<string | null>(null);
  const profiles = [
    {
      id: "client",
      href: "/tableau-de-bord",
      icon: Package,
      eyebrow: "Pour vos marchandises",
      title: "Je veux expédier",
      text: "Je cherche un transporteur",
      action: "Accéder à mon espace",
    },
    {
      id: "transporter",
      href: "/transporteur/tableau-de-bord",
      icon: Truck,
      eyebrow: "Pour votre activité",
      title: "Je suis transporteur",
      text: "Je cherche des cargaisons",
      action: "Accéder à mon espace",
    },
  ];
  return (
    <div className="noise-overlay min-h-[100dvh] bg-[#f7f5ef] text-[#17344f]">
      <header className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 sm:px-8 lg:py-8">
        <BrandMark />
        <Link
          href="/"
          className="focus-ring inline-flex items-center gap-2 text-sm font-bold text-[#687a82] transition hover:text-[#17344f]"
          data-testid="link-retour-accueil"
        >
          <ArrowLeft size={15} /> Retour à l’accueil
        </Link>
      </header>
      <main className="mx-auto max-w-[1000px] px-5 pb-16 pt-12 sm:px-8 sm:pt-20">
        <div className="mx-auto max-w-[650px] text-center">
          <span className="mono-font text-[10px] uppercase tracking-[.16em] text-[#6b8f8a]">
            Première étape
          </span>
          <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.055em] sm:text-6xl">
            Par où commence-t-on ?
          </h1>
          <p className="mt-5 text-base leading-7 text-[#6e7d83]">
            Choisissez votre parcours. GoLink France s’adapte à votre façon de
            travailler.
          </p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {profiles.map((profile) => {
            const Icon = profile.icon;
            const active = hovered === profile.id;
            return (
              <Link
                key={profile.id}
                href={profile.href}
                onMouseEnter={() => setHovered(profile.id)}
                onMouseLeave={() => setHovered(null)}
                className={`focus-ring group relative overflow-hidden rounded-[1.6rem] border p-7 transition duration-300 sm:p-9 ${active ? "border-[#6da99d] bg-[#e7f1ed] shadow-[0_18px_44px_rgba(40,100,94,.12)]" : "border-[#dbe3de] bg-white hover:border-[#a6c8c0]"}`}
                data-testid={`link-profil-${profile.id}`}
              >
                <span
                  className={`grid h-14 w-14 place-items-center rounded-2xl transition ${active ? "bg-[#17344f] text-[#f4a261]" : "bg-[#e7f1ed] text-[#28645e]"}`}
                >
                  <Icon size={26} strokeWidth={1.8} />
                </span>
                <p className="mono-font mt-10 text-[10px] uppercase tracking-[.15em] text-[#6b8f8a]">
                  {profile.eyebrow}
                </p>
                <h2 className="display-font mt-3 text-2xl font-bold tracking-[-.035em] sm:text-3xl">
                  {profile.title}
                </h2>
                <p className="mt-4 max-w-[380px] text-sm leading-6 text-[#6e7d83]">
                  {profile.text}
                </p>
                <span className="mt-8 inline-flex items-center gap-2 text-sm font-extrabold text-[#28645e]">
                  {profile.action}
                  <ArrowRight
                    size={16}
                    className={`transition ${active ? "translate-x-1" : ""}`}
                  />
                </span>
                <span className="absolute -bottom-12 -right-10 h-32 w-32 rounded-full border border-[#b6d4cd]" />
              </Link>
            );
          })}
        </div>
        <div className="mx-auto mt-12 flex max-w-[560px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4 text-left">
          <Info size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
          <p className="text-xs leading-5 text-[#71828a]">
            Chaque choix ouvre un espace dédié à votre activité. Ce prototype ne
            demande aucune inscription.
          </p>
        </div>
      </main>
    </div>
  );
}

function DashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Mardi 18 juin 2024 · Paris
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Claire<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Voici où en sont vos expéditions.
          </p>
        </div>
        <Link
          href="/nouvelle-expedition"
          className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#df8550] px-4 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_9px_20px_rgba(223,133,80,.18)] transition hover:-translate-y-0.5 hover:bg-[#eb9863]"
          data-testid="link-nouvelle-expedition"
        >
          <Plus size={18} /> Nouvelle expédition
        </Link>
      </div>
      <div className="animate-rise animate-rise-delay-1 mt-9 grid gap-4 sm:grid-cols-3">
        {[
          {
            label: "En cours",
            value: "03",
            note: "dont 1 à confirmer",
            accent: "teal",
          },
          {
            label: "Livrées ce mois",
            value: "12",
            note: "+ 3 vs. mai",
            accent: "orange",
          },
          {
            label: "Délai moyen",
            value: "1,4 j",
            note: "sur les 30 derniers jours",
            accent: "navy",
          },
        ].map((metric) => (
          <div
            key={metric.label}
            className="card-shadow rounded-2xl border border-[#e0e5e0] bg-white p-5"
          >
            <div className="flex items-start justify-between">
              <p className="text-xs font-bold text-[#71828a]">{metric.label}</p>
              <span
                className={`h-2 w-2 rounded-full ${metric.accent === "orange" ? "bg-[#df8550]" : metric.accent === "navy" ? "bg-[#17344f]" : "bg-[#6da99d]"}`}
              />
            </div>
            <p className="display-font mt-4 text-3xl font-bold tracking-[-.05em]">
              {metric.value}
            </p>
            <p className="mt-2 text-[11px] text-[#8a9699]">{metric.note}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <section className="animate-rise animate-rise-delay-2 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                À suivre
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Vos expéditions
              </h2>
            </div>
            <button
              className="focus-ring text-xs font-bold text-[#28645e] hover:underline"
              onClick={() =>
                window.alert(
                  "Dans la version complète, cette vue affiche tout l’historique.",
                )
              }
              data-testid="button-voir-tout"
            >
              Voir tout
            </button>
          </div>
          <div className="mt-7 divide-y divide-[#edf0eb]">
            {[
              {
                ref: shipment.reference,
                route: `${shipment.senderCity} → ${shipment.receiverCity}`,
                desc: shipment.goodsType,
                status: "Recherche en cours",
                tone: "orange" as const,
                date: "Créée il y a 12 min",
              },
              {
                ref: "GL-240616-038",
                route: "Boulogne → Lille",
                desc: "Pièces détachées · 420 kg",
                status: "Transport confirmé",
                tone: "teal" as const,
                date: "Livraison demain",
              },
              {
                ref: "GL-240612-021",
                route: "Nantes → Bordeaux",
                desc: "Mobilier · 2,1 m³",
                status: "Livrée",
                tone: "muted" as const,
                date: "12 juin 2024",
              },
            ].map((item, index) => (
              <div
                key={item.ref}
                className="group flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
                data-testid={`row-expedition-${index}`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${index === 0 ? "bg-[#fff0e5] text-[#b7683c]" : "bg-[#e8f0ed] text-[#477d75]"}`}
                  >
                    <RouteIcon size={17} />
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold">{item.route}</p>
                      <StatusBadge tone={item.tone}>{item.status}</StatusBadge>
                    </div>
                    <p className="mt-1 text-xs text-[#8a9699]">
                      {item.ref} · {item.desc}
                    </p>
                  </div>
                </div>
                <p className="pl-12 text-[11px] font-semibold text-[#8a9699] sm:pl-0">
                  {item.date}
                </p>
              </div>
            ))}
          </div>
        </section>
        <section className="animate-rise animate-rise-delay-3 rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef] sm:p-7">
          <div className="flex items-start justify-between">
            <div>
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
                Votre activité
              </p>
              <h2 className="display-font mt-2 text-xl font-bold tracking-[-.035em]">
                Ce mois-ci
              </h2>
            </div>
            <Sparkles size={19} className="text-[#f4a261]" />
          </div>
          <div className="mt-8 grid grid-cols-2 gap-y-7">
            <div>
              <p className="text-3xl font-bold">15</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">expéditions créées</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                98<span className="text-lg">%</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">remises à temps</p>
            </div>
            <div>
              <p className="text-3xl font-bold">
                4,8<span className="text-lg">/5</span>
              </p>
              <p className="mt-1 text-xs text-[#a8bcbc]">satisfaction</p>
            </div>
            <div>
              <p className="text-3xl font-bold">8</p>
              <p className="mt-1 text-xs text-[#a8bcbc]">
                transporteurs utilisés
              </p>
            </div>
          </div>
          <div className="mt-9 border-t border-white/10 pt-5">
            <p className="text-xs leading-5 text-[#b5c7c4]">
              Votre réseau s’agrandit. Les trajets réguliers peuvent être
              enregistrés pour aller plus vite.
            </p>
            <button
              className="focus-ring mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#f4a261] hover:text-[#ffc08f]"
              onClick={() =>
                window.alert(
                  "Les trajets favoris seront disponibles prochainement.",
                )
              }
              data-testid="button-decouvrir-favoris"
            >
              Découvrir les favoris <ArrowRight size={14} />
            </button>
          </div>
        </section>
      </div>
      <section className="mt-7 rounded-[1.4rem] border border-[#e0e5e0] bg-[#eef3ef] p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-[#28645e]">
              <FileText size={18} />
            </span>
            <div>
              <p className="text-sm font-extrabold">
                Besoin d’un coup de main ?
              </p>
              <p className="mt-1 text-xs text-[#71828a]">
                Notre guide explique comment préparer une expédition sans oubli.
              </p>
            </div>
          </div>
          <button
            className="focus-ring w-fit rounded-lg border border-[#bfd2cb] bg-white px-3.5 py-2.5 text-xs font-bold text-[#28645e] transition hover:bg-[#e3f0ed]"
            onClick={() =>
              window.alert("Le guide de préparation est en cours de rédaction.")
            }
            data-testid="button-guide"
          >
            Lire le guide
          </button>
        </div>
      </section>
    </div>
  );
}

function WorkspaceSectionPage({
  role,
  section,
}: {
  role: "client" | "transporter";
  section: "messages" | "profil" | "mes-transports";
}) {
  const isTransporter = role === "transporter";
  const content =
    section === "messages"
      ? {
          eyebrow: "Échanges",
          title: "Messages",
          description: isTransporter
            ? "Retrouvez les échanges liés à vos propositions et à vos transports."
            : "Retrouvez les échanges liés à vos expéditions et aux transporteurs.",
        }
      : section === "profil"
        ? {
            eyebrow: "Votre espace",
            title: "Profil",
            description: isTransporter
              ? "Gérez les informations de Transport Martin."
              : "Gérez les informations de votre entreprise et vos préférences.",
          }
        : {
            eyebrow: "Votre activité",
            title: "Mes transports",
            description:
              "Retrouvez les trajets pour lesquels vous avez envoyé une proposition.",
          };
  return (
    <div className="mx-auto max-w-[980px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise max-w-[620px]">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          {content.eyebrow}
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          {content.title}
        </h1>
        <p className="mt-3 text-sm leading-6 text-[#71828a]">
          {content.description}
        </p>
      </div>
      <section className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-6 sm:p-8">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e8f0ed] text-[#28645e]">
          {section === "messages" ? (
            <MessageCircle size={22} />
          ) : section === "profil" ? (
            <UserRound size={22} />
          ) : (
            <Truck size={22} />
          )}
        </span>
        <h2 className="display-font mt-6 text-2xl font-bold tracking-[-.035em]">
          Cette vue sera bientôt disponible.
        </h2>
        <p className="mt-3 max-w-[560px] text-sm leading-6 text-[#71828a]">
          Le prototype garde votre espace{" "}
          {isTransporter ? "transporteur" : "client"} séparé. Les
          fonctionnalités principales restent accessibles depuis votre
          navigation.
        </p>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-extrabold text-[#526579]">
        {label}
        {required ? <span className="ml-1 text-[#df8550]">*</span> : null}
      </span>
      <input
        name={name}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        type={type}
        required={required}
        className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
        data-testid={`input-${name}`}
      />
    </label>
  );
}

function ShipmentPhotoPicker({
  photos,
  onAdd,
  onRemove,
}: {
  photos: ShipmentPhoto[];
  onAdd: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemove: (photoId: string) => void;
}) {
  return (
    <section
      className="mt-6 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-7"
      aria-labelledby="photos-marchandise-title"
    >
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <p
            id="photos-marchandise-title"
            className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
          >
            Photos de la marchandise
          </p>
          <p className="mt-2 text-xs leading-5 text-[#819099]">
            Ajoutez plusieurs vues pour aider le transporteur à préparer son
            trajet.
          </p>
        </div>
        <label
          className="focus-ring inline-flex w-fit cursor-pointer items-center gap-2 rounded-xl border border-[#c8d8d3] bg-[#f7fbf8] px-4 py-3 text-sm font-extrabold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-ajouter-photo"
        >
          <Plus size={16} /> Ajouter une photo
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={onAdd}
            className="sr-only"
            data-testid="input-photos"
          />
        </label>
      </div>
      {photos.length ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="group relative overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1]"
            >
              <img
                src={photo.url}
                alt={photo.name}
                className="aspect-[4/3] w-full object-cover"
              />
              <button
                type="button"
                onClick={() => onRemove(photo.id)}
                className="focus-ring absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-[#17344f]/85 text-white opacity-100 transition hover:bg-[#17344f] sm:opacity-0 sm:group-hover:opacity-100"
                aria-label={`Supprimer ${photo.name}`}
                data-testid={`button-supprimer-photo-${photo.id}`}
              >
                <X size={15} />
              </button>
              <p className="truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                {photo.name}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-6 flex items-center gap-3 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-xs leading-5 text-[#71828a]">
          <Package size={17} className="shrink-0 text-[#6b8f8a]" /> Aucun
          fichier ajouté pour le moment.
        </div>
      )}
    </section>
  );
}

function NewShipmentPage({
  onPublish,
}: {
  onPublish: (shipment: Shipment) => void;
}) {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Shipment>({
    reference: "GL-240618-047",
    senderAddress: "",
    senderCity: "",
    senderPostalCode: "",
    receiverAddress: "",
    receiverCity: "",
    receiverPostalCode: "",
    date: "À convenir",
    goodsType: "",
    weight: "",
    packageCount: "",
    vehicleType: "",
    offeredPrice: "",
    photos: [],
  });
  const update = (key: keyof Shipment) => (value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
  };
  const addPhotos = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []).filter((file) =>
      file.type.startsWith("image/"),
    );
    if (!files.length) return;
    const newPhotos = files.map((file, index) => ({
      id: `${file.name}-${file.lastModified}-${index}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }));
    setForm((current) => ({
      ...current,
      photos: [...current.photos, ...newPhotos],
    }));
    event.target.value = "";
  };
  const removePhoto = (photoId: string) => {
    setForm((current) => {
      const photo = current.photos.find((item) => item.id === photoId);
      if (photo) URL.revokeObjectURL(photo.url);
      return {
        ...current,
        photos: current.photos.filter((item) => item.id !== photoId),
      };
    });
  };
  const nextStep = (event: FormEvent) => {
    event.preventDefault();
    if (
      !form.senderAddress ||
      !form.senderCity ||
      !form.senderPostalCode ||
      !form.receiverAddress ||
      !form.receiverCity ||
      !form.receiverPostalCode
    ) {
      setError("Renseignez toutes les informations du trajet pour continuer.");
      return;
    }
    setError("");
    setStep(2);
  };
  const submit = () => {
    if (
      !form.goodsType ||
      !form.weight ||
      !form.packageCount ||
      !form.vehicleType ||
      !form.offeredPrice
    ) {
      setError("Complétez les informations de la cargaison avant de publier.");
      return;
    }
    onPublish({
      ...form,
      weight: `${form.weight} kg`,
      offeredPrice: `${form.offeredPrice} €`,
    });
    setLocation("/expedition-publiee");
  };
  return (
    <div className="mx-auto max-w-[1020px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise">
        <Link
          href="/tableau-de-bord"
          className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
          data-testid="link-retour-dashboard"
        >
          <ArrowLeft size={14} /> Retour au tableau de bord
        </Link>
        <div className="mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              Nouvelle expédition
            </p>
            <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
              Préparons votre trajet.
            </h1>
            <p className="mt-2 text-sm text-[#71828a]">
              Décrivez votre besoin en deux étapes simples.
            </p>
          </div>
          <span className="mono-font text-xs text-[#71828a]">
            Réf. {form.reference}
          </span>
        </div>
      </div>
      <div className="mt-9 grid gap-8 lg:grid-cols-[1fr_280px]">
        <div>
          <div className="mb-7 flex items-center gap-2 sm:gap-4">
            {["Le trajet", "La cargaison"].map((label, index) => {
              const number = index + 1;
              return (
                <div
                  key={label}
                  className="flex flex-1 items-center gap-2 sm:gap-3"
                >
                  <span
                    className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-extrabold ${step >= number ? "bg-[#17344f] text-[#f7f5ef]" : "border border-[#d4dfda] bg-white text-[#9aa8aa]"}`}
                  >
                    {step > number ? <Check size={15} /> : number}
                  </span>
                  <span
                    className={`hidden text-xs font-bold sm:block ${step >= number ? "text-[#17344f]" : "text-[#9aa8aa]"}`}
                  >
                    {label}
                  </span>
                  {number < 2 ? (
                    <span
                      className={`h-px flex-1 ${step > number ? "bg-[#6da99d]" : "bg-[#dce3df]"}`}
                    />
                  ) : null}
                </div>
              );
            })}
          </div>
          <form
            onSubmit={nextStep}
            className="rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
            data-testid="form-nouvelle-expedition"
          >
            {step === 1 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
                    <RouteIcon size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">Le trajet</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Indiquez les deux points de votre expédition.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-8 md:grid-cols-2">
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de collecte
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de collecte"
                        name="adresse-collecte"
                        value={form.senderAddress}
                        onChange={update("senderAddress")}
                        placeholder="Ex. 18 rue de Charonne"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-collecte"
                        value={form.senderCity}
                        onChange={update("senderCity")}
                        placeholder="Ex. Paris"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-collecte"
                        value={form.senderPostalCode}
                        onChange={update("senderPostalCode")}
                        placeholder="Ex. 75011"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <p className="mono-font mb-4 text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
                      Adresse de livraison
                    </p>
                    <div className="space-y-4">
                      <Field
                        label="Adresse de livraison"
                        name="adresse-livraison"
                        value={form.receiverAddress}
                        onChange={update("receiverAddress")}
                        placeholder="Ex. 7 rue Mercière"
                        required
                      />
                      <Field
                        label="Ville"
                        name="ville-livraison"
                        value={form.receiverCity}
                        onChange={update("receiverCity")}
                        placeholder="Ex. Lyon"
                        required
                      />
                      <Field
                        label="Code postal"
                        name="code-postal-livraison"
                        value={form.receiverPostalCode}
                        onChange={update("receiverPostalCode")}
                        placeholder="Ex. 69002"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
            {step === 2 ? (
              <div className="animate-rise">
                <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
                    <Box size={18} />
                  </span>
                  <div>
                    <h2 className="text-base font-extrabold">La cargaison</h2>
                    <p className="mt-1 text-xs text-[#819099]">
                      Donnez aux transporteurs les informations utiles pour
                      répondre.
                    </p>
                  </div>
                </div>
                <div className="mt-7 grid gap-5 md:grid-cols-2">
                  <Field
                    label="Type de marchandise"
                    name="type-marchandise"
                    value={form.goodsType}
                    onChange={update("goodsType")}
                    placeholder="Ex. Mobilier professionnel"
                    required
                  />
                  <Field
                    label="Poids en kg"
                    name="poids"
                    value={form.weight}
                    onChange={update("weight")}
                    placeholder="Ex. 180"
                    type="number"
                    required
                  />
                  <Field
                    label="Nombre de colis"
                    name="nombre-colis"
                    value={form.packageCount}
                    onChange={update("packageCount")}
                    placeholder="Ex. 3"
                    type="number"
                    required
                  />
                  <label className="block">
                    <span className="mb-2 block text-xs font-extrabold text-[#526579]">
                      Type de véhicule
                      <span className="ml-1 text-[#df8550]">*</span>
                    </span>
                    <select
                      name="type-vehicule"
                      value={form.vehicleType}
                      onChange={(event) =>
                        update("vehicleType")(event.target.value)
                      }
                      required
                      className="focus-ring h-12 w-full rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 text-sm text-[#17344f] outline-none transition focus:border-[#6da99d] focus:bg-white"
                      data-testid="select-type-vehicule"
                    >
                      <option value="">Sélectionnez un véhicule</option>
                      <option>Fourgon</option>
                      <option>Camion porteur</option>
                      <option>Poids lourd</option>
                      <option>Véhicule avec hayon</option>
                    </select>
                  </label>
                  <Field
                    label="Prix proposé en €"
                    name="prix-propose"
                    value={form.offeredPrice}
                    onChange={update("offeredPrice")}
                    placeholder="Ex. 420"
                    type="number"
                    required
                  />
                </div>
                <div className="mt-6 flex items-start gap-2 rounded-xl bg-[#f1f5f1] p-3 text-xs leading-5 text-[#71828a]">
                  <Info size={15} className="mt-0.5 shrink-0 text-[#6b8f8a]" />{" "}
                  Votre prix proposé sera visible par les transporteurs
                  intéressés par ce trajet.
                </div>
              </div>
            ) : null}
            {error ? (
              <p
                className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
                role="alert"
                data-testid="text-form-error"
              >
                {error}
              </p>
            ) : null}
            <div className="mt-8 flex flex-col-reverse justify-between gap-3 border-t border-[#edf0eb] pt-6 sm:flex-row sm:items-center">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    setError("");
                    setStep(1);
                  }}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-bold text-[#71828a] transition hover:bg-[#f1f4f0] hover:text-[#17344f]"
                  data-testid="button-etape-precedente"
                >
                  <ArrowLeft size={16} /> Étape précédente
                </button>
              ) : (
                <span className="hidden sm:block text-xs text-[#98a4a6]">
                  * Champs obligatoires
                </span>
              )}
              {step === 1 ? (
                <button
                  type="submit"
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                  data-testid="button-continuer"
                >
                  Continuer <ArrowRight size={16} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={submit}
                  className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
                  data-testid="button-publier-cargaison"
                >
                  Publier la cargaison <ArrowRight size={16} />
                </button>
              )}
            </div>
          </form>
          {step === 2 ? (
            <ShipmentPhotoPicker
              photos={form.photos}
              onAdd={addPhotos}
              onRemove={removePhoto}
            />
          ) : null}
        </div>
        <aside className="hidden lg:block">
          <div className="sticky top-[105px] rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Bon à savoir
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Vous gardez le cap.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Votre annonce reste modifiable jusqu’à sa publication.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <MapPin size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Un trajet précis aide à obtenir des propositions adaptées.
                </p>
              </div>
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Les transporteurs voient les informations nécessaires avant de
                  répondre.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ShipmentPhotosSection({ photos }: { photos: ShipmentPhoto[] }) {
  const [selectedPhoto, setSelectedPhoto] = useState<ShipmentPhoto | null>(
    null,
  );

  return (
    <>
      <section
        className="border-t border-[#edf0eb] px-5 py-6 sm:px-7"
        aria-labelledby="photos-cargaison-title"
      >
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#fff0e5] text-[#b7683c]">
            <Package size={18} />
          </span>
          <div>
            <p
              id="photos-cargaison-title"
              className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]"
            >
              Photos de la marchandise
            </p>
            <p className="mt-2 text-xs text-[#819099]">
              Consultez les photos ajoutées par le client avant de répondre.
            </p>
          </div>
        </div>
        {photos.length ? (
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {photos.map((photo) => (
              <button
                type="button"
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="focus-ring group overflow-hidden rounded-xl border border-[#dfe7e2] bg-[#f1f5f1] text-left"
                aria-label={`Agrandir ${photo.name}`}
                data-testid={`button-agrandir-photo-${photo.id}`}
              >
                <img
                  src={photo.url}
                  alt={photo.name}
                  className="aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-[1.03]"
                />
                <span className="block truncate px-3 py-2 text-[11px] font-semibold text-[#71828a]">
                  {photo.name}
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div
            className="mt-5 rounded-xl border border-dashed border-[#cddbd5] bg-[#f7fbf8] px-4 py-4 text-sm font-semibold text-[#71828a]"
            data-testid="text-aucune-photo"
          >
            Aucune photo disponible
          </div>
        )}
      </section>
      {selectedPhoto ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#10263a]/80 p-5 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo agrandie : ${selectedPhoto.name}`}
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelectedPhoto(null);
          }}
        >
          <div className="relative max-h-[90vh] max-w-[min(900px,calc(100vw-2.5rem))] overflow-hidden rounded-2xl bg-white p-2 shadow-2xl">
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="focus-ring absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-[#17344f]/90 text-white transition hover:bg-[#17344f]"
              aria-label="Fermer la photo agrandie"
              data-testid="button-fermer-photo"
            >
              <X size={18} />
            </button>
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.name}
              className="max-h-[82vh] max-w-full rounded-xl object-contain"
            />
            <p className="px-2 pb-1 pt-2 text-xs font-semibold text-[#526579]">
              {selectedPhoto.name}
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}

function PublishedPage({ shipment }: { shipment: Shipment }) {
  const [, setLocation] = useLocation();
  return (
    <div className="mx-auto max-w-[980px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[720px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Expédition publiée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre expédition a été publiée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[540px] text-base leading-7 text-[#71828a]">
          Votre cargaison est maintenant visible par les transporteurs
          intéressés par ce trajet.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[820px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="flex flex-col justify-between gap-3 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Résumé de l’expédition
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.reference}</p>
          </div>
          <StatusBadge>Recherche de transporteur</StatusBadge>
        </div>
        <div className="grid gap-0 sm:grid-cols-[1fr_80px_1fr] sm:items-center">
          <div className="p-6 sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Collecte
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.senderCity} · {shipment.senderPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.senderAddress}
            </p>
          </div>
          <div className="hidden justify-center sm:flex">
            <div className="h-px w-10 bg-[#b9d2cc]" />
            <Truck size={18} className="mx-[-4px] text-[#df8550]" />
            <div className="h-px w-10 bg-[#b9d2cc]" />
          </div>
          <div className="border-t border-[#edf0eb] p-6 sm:border-t-0 sm:border-l sm:p-8">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
              Livraison
            </p>
            <p className="mt-2 text-base font-extrabold">
              {shipment.receiverCity} · {shipment.receiverPostalCode}
            </p>
            <p className="mt-1 text-xs text-[#71828a]">
              {shipment.receiverAddress}
            </p>
          </div>
        </div>
        <div className="grid gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] p-5 sm:grid-cols-4 sm:px-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Marchandise
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.goodsType}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Poids
            </p>
            <p className="mt-1 text-sm font-extrabold">{shipment.weight}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Colis
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.packageCount}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé
            </p>
            <p className="mt-1 text-sm font-extrabold">
              {shipment.offeredPrice}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
          <Truck size={15} className="text-[#6b8f8a]" /> Véhicule souhaité :{" "}
          <strong>{shipment.vehicleType}</strong>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[760px] gap-3 sm:grid-cols-2">
        <button
          onClick={() => setLocation("/tableau-de-bord")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-voir-tableau"
        >
          Voir mon tableau de bord <ArrowRight size={16} />
        </button>
        <button
          onClick={() => setLocation("/nouvelle-expedition")}
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-nouvelle-apres-publication"
        >
          <Plus size={16} /> Créer une autre expédition
        </button>
      </div>
      <div className="mx-auto mt-12 flex max-w-[600px] items-start gap-3 rounded-2xl border border-[#e1e5df] bg-[#f1f2ec] p-4">
        <Clock3 size={17} className="mt-0.5 shrink-0 text-[#6b8f8a]" />
        <p className="text-xs leading-5 text-[#71828a]">
          <strong className="text-[#526579]">Et maintenant ?</strong> Les
          transporteurs intéressés peuvent consulter votre annonce. Consultez
          votre tableau de bord pour suivre les réponses.
        </p>
      </div>
    </div>
  );
}

function TransporterDashboardPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1240px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Espace transporteur · Aujourd’hui
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            Bonjour Thomas<span className="text-[#df8550]">.</span>
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Des trajets qui correspondent à votre activité.
          </p>
        </div>
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[#c8dad4] bg-[#e8f1ed] px-3 py-2 text-xs font-bold text-[#28645e]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#5eaa9d]" /> Profil
          transporteur actif
        </span>
      </div>

      <section className="animate-rise animate-rise-delay-1 mt-10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
              À saisir
            </p>
            <h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em] sm:text-3xl">
              Cargaisons disponibles
            </h2>
            <p className="mt-2 max-w-[560px] text-sm leading-6 text-[#71828a]">
              Découvrez les expéditions à proximité et proposez un transport
              adapté.
            </p>
          </div>
          <span className="text-xs font-bold text-[#819099]">
            1 nouvelle cargaison
          </span>
        </div>

        <div className="mt-7 grid gap-6 xl:grid-cols-[1fr_280px]">
          <article className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
            <div className="flex flex-col justify-between gap-4 border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:flex-row sm:items-center sm:px-7">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge tone="orange">Nouvelle</StatusBadge>
                  <span className="mono-font text-[10px] tracking-[.12em] text-[#819099]">
                    {shipment.reference}
                  </span>
                </div>
                <p className="display-font mt-3 text-2xl font-bold tracking-[-.04em]">
                  {shipment.senderCity}{" "}
                  <span className="text-[#df8550]">→</span>{" "}
                  {shipment.receiverCity}
                </p>
              </div>
              <Link
                href="/transporteur/cargaison"
                className="focus-ring inline-flex w-fit items-center gap-2 rounded-xl bg-[#17344f] px-4 py-3 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
                data-testid="button-voir-cargaison"
              >
                Voir la cargaison <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid gap-0 sm:grid-cols-2 lg:grid-cols-4">
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Date
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.date}</p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 lg:border-b-0 lg:border-r">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Marchandise
                </p>
                <p className="mt-2 text-sm font-extrabold">
                  {shipment.goodsType}
                </p>
              </div>
              <div className="border-b border-[#edf0eb] p-5 sm:border-r lg:border-b-0">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Poids
                </p>
                <p className="mt-2 text-sm font-extrabold">{shipment.weight}</p>
              </div>
              <div className="p-5">
                <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
                  Prix proposé
                </p>
                <p className="mt-2 text-sm font-extrabold text-[#b7683c]">
                  {formatEuro(shipment.offeredPrice)}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-[#edf0eb] px-5 py-4 text-xs text-[#526579] sm:px-7">
              <span className="flex items-center gap-2">
                <Truck size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.vehicleType}
              </span>
              <span className="flex items-center gap-2">
                <Box size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.packageCount} colis
              </span>
              <span className="flex items-center gap-2">
                <MapPin size={15} className="text-[#6b8f8a]" />{" "}
                {shipment.senderPostalCode} → {shipment.receiverPostalCode}
              </span>
            </div>
          </article>

          <aside className="rounded-[1.4rem] bg-[#17344f] p-6 text-[#f7f5ef]">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#9fc1bc]">
              Votre activité
            </p>
            <h3 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
              Roulez utile.
            </h3>
            <p className="mt-3 text-xs leading-5 text-[#b5c7c4]">
              Les cargaisons sont présentées avec les informations essentielles
              pour décider rapidement.
            </p>
            <div className="mt-7 space-y-4 border-t border-white/10 pt-5">
              <div className="flex gap-3">
                <ShieldCheck size={16} className="shrink-0 text-[#8bc2b6]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Des annonces structurées, sans détour.
                </p>
              </div>
              <div className="flex gap-3">
                <RouteIcon size={16} className="shrink-0 text-[#f4a261]" />
                <p className="text-xs leading-5 text-[#d4dfdc]">
                  Une route claire avant de prendre la route.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

function ShipmentDetailsPage({ shipment }: { shipment: Shipment }) {
  return (
    <div className="mx-auto max-w-[1000px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/tableau-de-bord"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-cargaisons"
      >
        <ArrowLeft size={14} /> Retour aux cargaisons
      </Link>
      <div className="animate-rise mt-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
            Détail de la cargaison
          </p>
          <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
            {shipment.senderCity} <span className="text-[#df8550]">→</span>{" "}
            {shipment.receiverCity}
          </h1>
          <p className="mt-2 text-sm text-[#71828a]">
            Réf. {shipment.reference} · {shipment.date}
          </p>
        </div>
        <StatusBadge tone="orange">Recherche de transporteur</StatusBadge>
      </div>
      <div className="mt-9 grid gap-6 lg:grid-cols-[1fr_280px]">
        <section className="card-shadow overflow-hidden rounded-[1.4rem] border border-[#dfe7e2] bg-white">
          <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
            <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
              Informations du trajet
            </p>
            <p className="mt-2 text-sm font-extrabold">
              De la collecte à la livraison
            </p>
          </div>
          <div className="grid gap-0 sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de collecte
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.senderAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.senderCity} · {shipment.senderPostalCode}
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Adresse de livraison
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.receiverAddress}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.receiverCity} · {shipment.receiverPostalCode}
              </p>
            </div>
          </div>
          <div className="grid gap-0 border-t border-[#edf0eb] sm:grid-cols-2">
            <div className="p-6 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Marchandise
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.goodsType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                {shipment.weight} · {shipment.packageCount} colis
              </p>
            </div>
            <div className="border-t border-[#edf0eb] p-6 sm:border-l sm:border-t-0 sm:p-7">
              <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#819099]">
                Transport
              </p>
              <p className="mt-3 text-base font-extrabold">
                {shipment.vehicleType}
              </p>
              <p className="mt-1 text-sm text-[#71828a]">
                Date : {shipment.date}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-[#edf0eb] bg-[#fcfdfa] px-6 py-5 sm:px-7">
            <span className="text-sm font-bold text-[#526579]">
              Prix proposé par le client
            </span>
            <span className="display-font text-xl font-bold text-[#b7683c]">
              {formatEuro(shipment.offeredPrice)}
            </span>
          </div>
          <ShipmentPhotosSection photos={shipment.photos} />
        </section>
        <aside className="h-fit rounded-[1.4rem] border border-[#dfe7e2] bg-[#eef3ef] p-6">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre réponse
          </p>
          <h2 className="display-font mt-3 text-xl font-bold tracking-[-.035em]">
            Le trajet vous convient ?
          </h2>
          <p className="mt-3 text-xs leading-5 text-[#71828a]">
            Envoyez votre prix et un message au client pour vous positionner sur
            cette cargaison.
          </p>
          <Link
            href="/transporteur/proposition"
            className="focus-ring mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#df8550] px-4 py-3.5 text-sm font-extrabold text-[#17344f] transition hover:bg-[#eb9863]"
            data-testid="button-faire-proposition"
          >
            Faire une proposition <ArrowRight size={16} />
          </Link>
        </aside>
      </div>
    </div>
  );
}

function TransporterProposalPage({
  shipment,
  onSend,
}: {
  shipment: Shipment;
  onSend: (proposal: Proposal) => void;
}) {
  const [, setLocation] = useLocation();
  const [proposal, setProposal] = useState<Proposal>({
    price: "",
    message: "",
  });
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!proposal.price || !proposal.message) {
      setError("Renseignez votre prix et votre message avant d’envoyer.");
      return;
    }
    onSend({ ...proposal, price: `${proposal.price} €` });
    setLocation("/transporteur/proposition-envoyee");
  };
  return (
    <div className="mx-auto max-w-[820px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
      <Link
        href="/transporteur/cargaison"
        className="focus-ring inline-flex items-center gap-2 text-xs font-bold text-[#71828a] transition hover:text-[#17344f]"
        data-testid="link-retour-detail-cargaison"
      >
        <ArrowLeft size={14} /> Retour à la cargaison
      </Link>
      <div className="animate-rise mt-7">
        <p className="mono-font text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Votre proposition
        </p>
        <h1 className="display-font mt-3 text-3xl font-bold tracking-[-.05em] sm:text-4xl">
          Faites avancer le trajet.
        </h1>
        <p className="mt-2 text-sm text-[#71828a]">
          {shipment.senderCity} → {shipment.receiverCity} · {shipment.goodsType}
        </p>
      </div>
      <form
        onSubmit={submit}
        className="animate-rise animate-rise-delay-1 mt-9 rounded-[1.4rem] border border-[#e0e5e0] bg-white p-5 sm:p-8"
        data-testid="form-proposition"
      >
        <div className="flex items-start gap-3 border-b border-[#edf0eb] pb-6">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e8f0ed] text-[#28645e]">
            <FileText size={18} />
          </span>
          <div>
            <h2 className="text-base font-extrabold">Répondez au client</h2>
            <p className="mt-1 text-xs text-[#819099]">
              Un prix clair et un message précis font la différence.
            </p>
          </div>
        </div>
        <div className="mt-7 space-y-5">
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Prix proposé par le client
            </span>
            <input
              value={formatEuro(shipment.offeredPrice)}
              readOnly
              className="h-12 w-full cursor-default rounded-xl border border-[#d8e0dc] bg-[#f1f5f1] px-3.5 text-sm font-bold text-[#71828a] outline-none"
              data-testid="input-prix-client"
            />
          </label>
          <Field
            label="Votre prix"
            name="votre-prix"
            value={proposal.price}
            onChange={(value) => {
              setProposal((current) => ({ ...current, price: value }));
              setError("");
            }}
            placeholder="Ex. 390"
            type="number"
            required
          />
          <label className="block">
            <span className="mb-2 block text-xs font-extrabold text-[#526579]">
              Message<span className="ml-1 text-[#df8550]">*</span>
            </span>
            <textarea
              name="message"
              value={proposal.message}
              onChange={(event) => {
                setProposal((current) => ({
                  ...current,
                  message: event.target.value,
                }));
                setError("");
              }}
              placeholder="Présentez votre disponibilité et vos conditions de transport…"
              className="focus-ring min-h-[140px] w-full resize-y rounded-xl border border-[#d8e0dc] bg-[#fbfcfa] px-3.5 py-3 text-sm text-[#17344f] outline-none transition placeholder:text-[#aab4b5] focus:border-[#6da99d] focus:bg-white"
              data-testid="input-message"
            />
          </label>
        </div>
        {error ? (
          <p
            className="mt-5 rounded-xl bg-[#fff0e5] px-3 py-2.5 text-xs font-bold text-[#a9582d]"
            role="alert"
            data-testid="text-proposition-error"
          >
            {error}
          </p>
        ) : null}
        <div className="mt-8 flex justify-end border-t border-[#edf0eb] pt-6">
          <button
            type="submit"
            className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#df8550] px-5 py-3.5 text-sm font-extrabold text-[#17344f] shadow-[0_8px_18px_rgba(223,133,80,.2)] transition hover:bg-[#eb9863]"
            data-testid="button-envoyer-proposition"
          >
            Envoyer la proposition <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </div>
  );
}

function ProposalSentPage({
  shipment,
  proposal,
}: {
  shipment: Shipment;
  proposal: Proposal;
}) {
  return (
    <div className="mx-auto max-w-[900px] px-5 py-10 sm:px-8 lg:px-10 lg:py-16">
      <div className="animate-rise mx-auto max-w-[700px] text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#dceee9] text-[#28645e]">
          <Check size={30} strokeWidth={2.5} />
        </span>
        <p className="mono-font mt-7 text-[10px] uppercase tracking-[.17em] text-[#6b8f8a]">
          Proposition envoyée
        </p>
        <h1 className="display-font mt-4 text-4xl font-bold tracking-[-.06em] sm:text-6xl">
          Votre proposition a été envoyée
          <span className="text-[#df8550]"> !</span>
        </h1>
        <p className="mx-auto mt-5 max-w-[520px] text-base leading-7 text-[#71828a]">
          Le client pourra consulter votre offre et revenir vers vous au sujet
          de cette cargaison.
        </p>
      </div>
      <div className="animate-rise animate-rise-delay-2 card-shadow mx-auto mt-12 max-w-[720px] overflow-hidden rounded-[1.5rem] border border-[#dfe7e2] bg-white">
        <div className="border-b border-[#edf0eb] bg-[#f1f6f2] px-5 py-5 sm:px-7">
          <p className="mono-font text-[10px] uppercase tracking-[.14em] text-[#6b8f8a]">
            Votre offre
          </p>
          <p className="mt-1 text-sm font-extrabold">
            {shipment.senderCity} → {shipment.receiverCity} ·{" "}
            {shipment.reference}
          </p>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-7">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Prix proposé par le client
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#71828a]">
              {formatEuro(shipment.offeredPrice)}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Votre prix
            </p>
            <p className="mt-2 text-lg font-extrabold text-[#b7683c]">
              {proposal.price}
            </p>
          </div>
          <div className="sm:col-span-2">
            <p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#819099]">
              Message envoyé
            </p>
            <p className="mt-2 rounded-xl bg-[#fcfdfa] p-4 text-sm leading-6 text-[#526579]">
              {proposal.message}
            </p>
          </div>
        </div>
      </div>
      <div className="animate-rise animate-rise-delay-3 mx-auto mt-8 grid max-w-[720px] gap-3 sm:grid-cols-2">
        <Link
          href="/transporteur/tableau-de-bord"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[#17344f] px-5 py-3.5 text-sm font-extrabold text-[#f7f5ef] transition hover:bg-[#254b69]"
          data-testid="button-retour-cargaisons"
        >
          Voir les cargaisons disponibles <ArrowRight size={16} />
        </Link>
        <Link
          href="/transporteur/cargaison"
          className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl border border-[#c8d8d3] bg-white px-5 py-3.5 text-sm font-bold text-[#28645e] transition hover:bg-[#e8f1ed]"
          data-testid="button-revoir-cargaison"
        >
          Revoir la cargaison <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}

function Router() {
  const [publishedShipment, setPublishedShipment] =
    useState<Shipment>(starterShipment);
  const [sentProposal, setSentProposal] = useState<Proposal>({
    price: "390 €",
    message:
      "Disponible pour ce trajet avec un fourgon équipé. Je peux prendre en charge les trois colis dans le créneau indiqué.",
  });
  return (
    <AppShell>
      <Switch>
        <Route path="/" component={WelcomePage} />
        <Route path="/choisir-profil" component={ProfilePage} />
        <Route path="/tableau-de-bord">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/mes-expeditions">
          <DashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/nouvelle-expedition">
          <NewShipmentPage onPublish={setPublishedShipment} />
        </Route>
        <Route path="/expedition-publiee">
          <PublishedPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/tableau-de-bord">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/cargaisons">
          <TransporterDashboardPage shipment={publishedShipment} />
        </Route>
        <Route path="/messages">
          <WorkspaceSectionPage role="client" section="messages" />
        </Route>
        <Route path="/profil">
          <WorkspaceSectionPage role="client" section="profil" />
        </Route>
        <Route path="/transporteur/mes-transports">
          <WorkspaceSectionPage role="transporter" section="mes-transports" />
        </Route>
        <Route path="/transporteur/messages">
          <WorkspaceSectionPage role="transporter" section="messages" />
        </Route>
        <Route path="/transporteur/profil">
          <WorkspaceSectionPage role="transporter" section="profil" />
        </Route>
        <Route path="/transporteur/cargaison">
          <ShipmentDetailsPage shipment={publishedShipment} />
        </Route>
        <Route path="/transporteur/proposition">
          <TransporterProposalPage
            shipment={publishedShipment}
            onSend={setSentProposal}
          />
        </Route>
        <Route path="/transporteur/proposition-envoyee">
          <ProposalSentPage
            shipment={publishedShipment}
            proposal={sentProposal}
          />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedErrorBoundary>
            <Router />
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
